package hir_test

import (
	"fmt"
	"github.com/minz/minzc/pkg/emulator"
	"github.com/minz/minzc/pkg/hir"
	"github.com/minz/minzc/pkg/lir"
	"github.com/minz/minzc/pkg/mir2"
	"github.com/minz/minzc/pkg/pipeline"
	"github.com/minz/minzc/pkg/z80asm"
	"strings"
	"testing"
)

// Assemble once and reset memory for each case, using the production allocation
// for parameters and the production return contract for results.
func sweepCodegenJudge(t *testing.T, funcs []*hir.Func, name string, cases int, inputs func(int) []int64, model func([]int64) int64, research ...bool) (int, string) {
	t.Helper()
	opts := pipeline.DefaultOptions()
	steps, err := pipeline.CompileHIRSteps(&hir.Module{Name: "allowlist_judge", Funcs: funcs}, opts)
	if err != nil {
		t.Fatal(err)
	}
	if len(research) > 0 && research[0] {
		steps.Assembly, err = lir.LIRCodegenFunc(steps.MIR2Module.FuncByName(name), steps.MIR2Module, researchHints(steps))
		if err != nil {
			t.Fatal(err)
		}
		t.Logf("direct native LIR assembly:\n%s", steps.Assembly)
	}
	mf := steps.MIR2Module.FuncByName(name)
	if len(mf.Blocks) != 1 {
		t.Fatalf("%s must exercise the single-block bridge", name)
	}
	boot := fmt.Sprintf("ORG 0x%04X\n CALL %s\n DI\n HALT\n", testLoadAddr, name)
	res, err := z80asm.NewAssembler().AssembleString(boot + steps.Assembly)
	if err != nil || len(res.Errors) > 0 {
		t.Fatalf("assemble: %v %v", err, res.Errors)
	}
	// Validate the ABI before starting workers: Fatal must run on the test goroutine.
	for _, p := range mf.Contract.Params {
		if p.Ty.Width() == 16 {
			loc := steps.Allocation.Locs[p.Reg]
			if loc.Name != "HL" && loc.Name != "DE" && loc.Name != "BC" {
				t.Fatalf("word ABI: %+v", loc)
			}
		}
	}
	results := make([]string, cases)
	judgeWorkers(cases, res.Binary, func(z *emulator.RemogattoZ80, image []byte, i int) {
		args := inputs(i)
		z.Reset()
		if err := z.LoadMemory(testLoadAddr, image); err != nil {
			results[i] = fmt.Sprintf("load image: %v", err)
			return
		}
		regs := emulator.Registers{PC: testLoadAddr, SP: 0xFF00}
		for k, p := range mf.Contract.Params {
			if p.Ty.Width() != 16 {
				continue
			}
			loc := steps.Allocation.Locs[p.Reg]
			switch loc.Name {
			case "HL":
				regs.HL = uint16(args[k])
			case "DE":
				regs.DE = uint16(args[k])
			case "BC":
				regs.BC = uint16(args[k])
			}
		}
		z.SetRegisters(regs)
		for k, p := range mf.Contract.Params {
			if p.Ty.Width() == 8 {
				if err := z.SetRegister8(steps.Allocation.Locs[p.Reg].Name, uint8(args[k])); err != nil {
					results[i] = fmt.Sprintf("byte ABI: %v", err)
					return
				}
			}
		}
		n := 0
		for ; !z.IsHalted() && n < judgeStepBudget; n++ {
			z.Step()
		}
		got, err := hirReturnValue(mf, z.GetRegisters())
		want := model(args)
		if err != nil || n == judgeStepBudget || got != want {
			results[i] = fmt.Sprintf("%s%v got %d want %d err %v steps %d", name, args, got, want, err, n)
		}
	})
	bad, first := 0, ""
	for _, result := range results {
		if result != "" {
			bad++
			if first == "" {
				first = result
			}
		}
	}
	return bad, first
}

func TestExhaustiveJudgeNativeLoweringCases(t *testing.T) {
	t.Parallel()
	u8, u16 := mir2.TyU8, mir2.TyU16
	v := func(n string, ty mir2.Ty) hir.Expr { return hir.Var(n, ty) }
	k := func(n int64, ty mir2.Ty) hir.Expr { return &hir.IntLitExpr{Val: n, Ty: ty} }
	bin := func(op string, a, b hir.Expr, ty mir2.Ty) hir.Expr { return &hir.BinExpr{Op: op, L: a, R: b, Ty: ty} }
	cast := func(a hir.Expr, ty mir2.Ty) hir.Expr { return &hir.CastExpr{X: a, Ty: ty} }
	fn := func(name string, tys []mir2.Ty, ret mir2.Ty, expr hir.Expr) *hir.Func {
		ps := []hir.Param{}
		for i, ty := range tys {
			ps = append(ps, hir.Param{Name: []string{"a", "b", "c"}[i], Ty: ty})
		}
		return &hir.Func{Name: name, Params: ps, RetTy: ret, Body: hir.Blk(hir.Ret(expr))}
	}
	type fixture struct {
		name     string
		funcs    []*hir.Func
		count    int
		inputs   func(int) []int64
		model    func([]int64) int64
		knownBad int
	}
	pair := func(i int) []int64 { return []int64{int64(i >> 8), int64(i & 255)} }
	unary := func(i int) []int64 { return []int64{int64(i)} }
	fixtures := []fixture{}
	add := func(name string, tys []mir2.Ty, ret mir2.Ty, expr hir.Expr, count int, in func(int) []int64, model func([]int64) int64) {
		fixtures = append(fixtures, fixture{name, []*hir.Func{fn(name, tys, ret, expr)}, count, in, model, 0})
	}
	add("mul8", []mir2.Ty{u8, u8}, u8, bin("*", v("a", u8), v("b", u8), u8), 65536, pair, func(a []int64) int64 { return (a[0] * a[1]) & 255 })
	add("mul3", []mir2.Ty{u8}, u8, bin("*", v("a", u8), k(3, u8), u8), 256, unary, func(a []int64) int64 { return (a[0] * 3) & 255 })
	for _, factor := range []int64{2, 3, 10} {
		name := fmt.Sprintf("mul16_%d", factor)
		add(name, []mir2.Ty{u16}, u16, bin("*", v("a", u16), k(factor, u16), u16), 65536, unary, func(a []int64) int64 { return (a[0] * factor) & 65535 })
	}
	add("ext", []mir2.Ty{u8}, u16, cast(v("a", u8), u16), 256, unary, func(a []int64) int64 { return a[0] })
	add("ext2", []mir2.Ty{u8, u8}, u16, bin("+", cast(v("a", u8), u16), cast(v("b", u8), u16), u16), 65536, pair, func(a []int64) int64 { return a[0] + a[1] })
	add("trunc", []mir2.Ty{u16}, u8, cast(v("a", u16), u8), 65536, unary, func(a []int64) int64 { return a[0] & 255 })
	for _, op := range []string{"&", "|", "^"} {
		for _, ty := range []mir2.Ty{u8, u16} {
			name := fmt.Sprintf("logic%d_%d", ty.Width(), len(fixtures))
			in := pair
			count := 65536
			if ty.Width() == 16 {
				count = 65536 * 8
				in = func(i int) []int64 {
					return []int64{int64(i & 65535), []int64{0, 1, 255, 256, 0x1234, 0x8001, 0xFF00, 0xFFFF}[i>>16]}
				}
			}
			add(name, []mir2.Ty{ty, ty}, ty, bin(op, v("a", ty), v("b", ty), ty), count, in, func(a []int64) int64 {
				switch op {
				case "&":
					return a[0] & a[1]
				case "|":
					return a[0] | a[1]
				default:
					return a[0] ^ a[1]
				}
			})
		}
	}
	// fc keeps the first call result and a parameter live across the second call.
	sub := fn("call_sub", []mir2.Ty{u8, u8}, u8, bin("-", v("a", u8), v("b", u8), u8))
	sub.Body = hir.Blk(hir.If(bin("==", v("a", u8), v("b", u8), mir2.TyBool), hir.Blk(hir.Ret(k(0, u8))), nil), hir.Ret(bin("-", v("a", u8), v("b", u8), u8)))
	call := func(name string, args []hir.Expr, ty mir2.Ty) hir.Expr {
		return &hir.CallExpr{Fn: name, Args: args, Ty: ty}
	}
	fc := fn("fc", []mir2.Ty{u8, u8}, u8, bin("+", bin("+", call("call_sub", []hir.Expr{v("a", u8), v("b", u8)}, u8), call("call_sub", []hir.Expr{v("b", u8), v("a", u8)}, u8), u8), v("a", u8), u8))
	fixtures = append(fixtures, fixture{"fc", []*hir.Func{sub, fc}, 65536, pair, func(a []int64) int64 { return a[0] }, 0})
	mn := fn("mn", []mir2.Ty{u8, u8, u8}, u8, v("c", u8))
	mn.Body = hir.Blk(hir.If(bin("<", v("a", u8), v("b", u8), mir2.TyBool), hir.Blk(hir.Ret(bin("-", v("c", u8), v("a", u8), u8))), nil), hir.Ret(bin("-", v("c", u8), v("b", u8), u8)))
	c1 := fn("h_c1", []mir2.Ty{u8, u8, u8}, u8, call("mn", []hir.Expr{v("c", u8), v("a", u8), v("b", u8)}, u8))
	fixtures = append(fixtures, fixture{"h_c1", []*hir.Func{mn, c1}, 65536, func(i int) []int64 { return []int64{int64(i >> 8), 50, int64(i & 255)} }, func(a []int64) int64 {
		m := a[0]
		if a[2] < m {
			m = a[2]
		}
		return (a[1] - m) & 255
	}, 0})
	w := fn("w", []mir2.Ty{u16, u16}, u16, v("a", u16))
	w.Body = hir.Blk(hir.If(bin("<", v("a", u16), v("b", u16), mir2.TyBool), hir.Blk(hir.Ret(bin("-", v("b", u16), v("a", u16), u16))), nil), hir.Ret(bin("-", v("a", u16), v("b", u16), u16)))
	c4 := fn("h_c4", []mir2.Ty{u16, u16}, u16, bin("+", call("w", []hir.Expr{v("a", u16), k(1000, u16)}, u16), v("b", u16), u16))
	fixtures = append(fixtures, fixture{"h_c4", []*hir.Func{w, c4}, 65536, func(i int) []int64 { return []int64{int64(i), 7} }, func(a []int64) int64 {
		d := a[0] - 1000
		if d < 0 {
			d = -d
		}
		return (d + a[1]) & 65535
	}, 0})
	// Re-measured on deterministic origin/main ed55c1c7, 2026-10-02:
	// mul16_10, ext2 and h_c1 now require zero mismatches in both modes.
	// P7 call preservation also fixes fc and h_c4; both now require zero.
	for _, tc := range fixtures {
		t.Run(tc.name, func(t *testing.T) {
			bad, first := sweepCodegenJudge(t, tc.funcs, tc.name, tc.count, tc.inputs, tc.model)
			t.Logf("native %d/%d mismatches", bad, tc.count)
			if tc.knownBad > 0 {
				if bad != tc.knownBad {
					t.Fatalf("known native count changed: got %d, recorded %d", bad, tc.knownBad)
				}
				t.Skipf("2026-10-02: known production %s: %d/%d mismatches (%s)", tc.name, bad, tc.count, first)
			}
			if bad != 0 {
				t.Fatalf("native %d/%d mismatches: %s", bad, tc.count, first)
			}
		})
	}
}

func TestCodegenJudgeMismatchOrdering(t *testing.T) {
	t.Parallel()
	f := &hir.Func{
		Name: "identity", Params: []hir.Param{{Name: "a", Ty: mir2.TyU8}}, RetTy: mir2.TyU8,
		Body: hir.Blk(hir.Ret(hir.Var("a", mir2.TyU8))),
	}
	inputs := func(i int) []int64 { return []int64{int64(i)} }
	// Every case deliberately disagrees, so the first diagnostic must always
	// refer to input zero even when a later worker finishes first.
	model := func(args []int64) int64 { return args[0] + 1 }
	bad, first := sweepCodegenJudge(t, []*hir.Func{f}, "identity", 256, inputs, model)
	secondBad, second := sweepCodegenJudge(t, []*hir.Func{f}, "identity", 256, inputs, model)
	if bad != 256 || secondBad != bad || first != second || !strings.HasPrefix(first, "identity[0] got 0 want 1 err <nil>") {
		t.Fatalf("unordered mismatches: %d %q / %d %q", bad, first, secondBad, second)
	}
	bad, first = sweepCodegenJudge(t, []*hir.Func{f}, "identity", 0, inputs, model)
	if bad != 0 || first != "" {
		t.Fatalf("empty domain: %d %q", bad, first)
	}
}
