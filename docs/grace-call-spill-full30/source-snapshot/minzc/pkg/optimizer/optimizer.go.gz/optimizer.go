package optimizer

import (
	"fmt"

	"github.com/minz/minzc/pkg/ir"
	"github.com/minz/minzc/pkg/trace"
)

// OptimizationLevel represents different optimization levels
type OptimizationLevel int

const (
	OptLevelNone OptimizationLevel = 0
	OptLevelBasic OptimizationLevel = 1
	OptLevelFull OptimizationLevel = 2
)

// Pass represents an optimization pass
type Pass interface {
	Name() string
	Run(module *ir.Module) (bool, error)
}

// Optimizer manages and runs optimization passes
type Optimizer struct {
	level  OptimizationLevel
	passes []Pass
	tracer *trace.Tracer
}

// SetTracer sets the structured compilation trace writer.
func (o *Optimizer) SetTracer(t *trace.Tracer) {
	o.tracer = t
}

// NewOptimizer creates a new optimizer with the specified level
func NewOptimizer(level OptimizationLevel) *Optimizer {
	return NewOptimizerWithOptions(level, false)
}

// OptimizerOptions holds configuration for individual optimization passes
type OptimizerOptions struct {
	EnableTrueSMC  bool
	DisableReroll  bool
}

// NewOptimizerWithOptions creates a new optimizer with options
func NewOptimizerWithOptions(level OptimizationLevel, enableTrueSMC bool) *Optimizer {
	return NewOptimizerWithOpts(level, OptimizerOptions{EnableTrueSMC: enableTrueSMC})
}

// NewOptimizerWithOpts creates a new optimizer with full options control
func NewOptimizerWithOpts(level OptimizationLevel, opts OptimizerOptions) *Optimizer {
	opt := &Optimizer{
		level: level,
	}

	// Configure passes based on optimization level
	if level >= OptLevelBasic {
		// Basic optimizations - always run register analysis first
		if !opts.DisableReroll {
			opt.passes = append(opt.passes,
				NewLoopRerollPass(),   // Re-roll BEFORE inlining (detect repeated calls)
			)
		}
		opt.passes = append(opt.passes,
			NewRegisterAnalysisPass(),
			NewConstantFoldingPass(),
			NewMIRValueTrackingPass(), // Track values and set codegen hints (INC/DEC/XOR)
			NewDeadCodeEliminationPass(),
			NewStringIntentPass(), // Detect putchar sequences → string prints
		)
	}
	
	if level >= OptLevelFull {
		// Advanced optimizations - reorder before peephole for maximum pattern exposure
		opt.passes = append(opt.passes,
			NewIteratorFusionPass(),             // Fuse iterator chains before codegen
			NewSmartPeepholeOptimizationPass(),   // Smart peephole with integrated reordering
			NewRegisterAllocationPass(),
			NewInliningPass(),
		)
		
		// Use TRUE SMC if enabled (default behavior)
		// When SMC is disabled (enableTrueSMC=false), we skip ALL SMC passes
		if opts.EnableTrueSMC {
			opt.passes = append(opt.passes, NewTrueSMCPass(false)) // false = no diagnostics in production
			// Add TSMC pattern optimization after TRUE SMC
			opt.passes = append(opt.passes, &tsmcPatternAdapter{NewTSMCPatternOptimizer(false)})
		}
		// Note: When enableTrueSMC is false, we intentionally add NO SMC passes
		
		opt.passes = append(opt.passes,
			NewTailRecursionPass(),  // Add tail recursion optimization
			// NewCallReturnOptimizationPass(),  // Temporarily disabled due to crash
		)
	}
	
	return opt
}

// Optimize runs all configured optimization passes on the module
func (o *Optimizer) Optimize(module *ir.Module) error {
	if o.level == OptLevelNone {
		return nil
	}
	
	// First, detect recursive functions
	recursionDetector := NewRecursionDetector()
	recursionDetector.AnalyzeModule(module)
	
	// Apply tail recursion optimization
	for _, fn := range module.Functions {
		if fn.IsRecursive {
			OptimizeTailRecursion(fn)
		}
	}
	
	// Keep running passes until no more changes
	maxIterations := 10
	iterations := 0
	for iteration := 0; iteration < maxIterations; iteration++ {
		iterations = iteration + 1
		changed := false

		for _, pass := range o.passes {
			passChanged, err := pass.Run(module)
			if err != nil {
				return fmt.Errorf("optimization pass %s failed: %w", pass.Name(), err)
			}

			if passChanged {
				changed = true
				o.tracer.Log("optimizer", "%s: changed=true", pass.Name())
			}
		}

		// If no pass made changes, we're done
		if !changed {
			break
		}
	}
	o.tracer.Log("optimizer", "Completed in %d iterations", iterations)

	return nil
}

// Helper functions for common optimization tasks

// IsConstant checks if an instruction produces a constant value
func IsConstant(inst *ir.Instruction) bool {
	return inst.Op == ir.OpLoadConst
}

// GetConstantValue returns the constant value from a load constant instruction
func GetConstantValue(inst *ir.Instruction) (int64, bool) {
	if inst.Op == ir.OpLoadConst {
		return inst.Imm, true
	}
	return 0, false
}

// IsDeadStore checks if a store instruction is dead (value never used)
func IsDeadStore(inst *ir.Instruction, uses map[ir.Register]int) bool {
	if inst.Op == ir.OpStoreVar || inst.Op == ir.OpStoreField {
		return uses[inst.Dest] == 0
	}
	return false
}

// ReplaceRegister replaces all uses of oldReg with newReg in the instruction
func ReplaceRegister(inst *ir.Instruction, oldReg, newReg ir.Register) {
	if inst.Src1 == oldReg {
		inst.Src1 = newReg
	}
	if inst.Src2 == oldReg {
		inst.Src2 = newReg
	}
	if inst.Dest == oldReg {
		inst.Dest = newReg
	}
}

// tsmcPatternAdapter adapts TSMCPatternOptimizer to the Pass interface
type tsmcPatternAdapter struct {
	optimizer *TSMCPatternOptimizer
}

func (a *tsmcPatternAdapter) Name() string {
	return a.optimizer.GetName()
}

func (a *tsmcPatternAdapter) Run(module *ir.Module) (bool, error) {
	// Track initial state (simplified - just counts instructions)
	initialInstrCount := 0
	for _, f := range module.Functions {
		initialInstrCount += len(f.Instructions)
	}
	
	// Run optimization
	err := a.optimizer.OptimizeModule(module)
	if err != nil {
		return false, err
	}
	
	// Check if anything changed
	finalInstrCount := 0
	for _, f := range module.Functions {
		finalInstrCount += len(f.Instructions)
	}
	
	return initialInstrCount != finalInstrCount, nil
}