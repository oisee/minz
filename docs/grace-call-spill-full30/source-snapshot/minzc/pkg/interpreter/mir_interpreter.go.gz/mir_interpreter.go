package interpreter

import (
	"fmt"
	"strings"
	"strconv"
	
	"github.com/minz/minzc/pkg/ir"
)

// Deprecated: MIRInterpreter is superseded by mirvm.VM which is register-based
// and passes 75+ tests. Use mirvm.VM directly or via ctie.CompileTimeExecutor.
// This interpreter is kept for reference only — no new features should be added.
type MIRInterpreter struct {
	registers  map[ir.Register]int64     // Virtual register values
	memory     map[int64]byte            // Simulated memory space
	stack      []int64                   // Execution stack
	callStack  []CallFrame               // Function call stack
	pc         int                       // Program counter
	flags      ProcessorFlags            // Z80-like flags
	functions  map[string]*ir.Function   // Available functions
	labels     map[string]int            // Label to instruction mapping
	
	// String management for metaprogramming
	strings    map[int64]string          // String heap
	nextStringID int64                   // String allocation counter
	
	// Metaprogramming output
	output     strings.Builder           // Generated MinZ code
	symbolGen  int                       // Symbol generator counter
	
	// Execution limits
	maxInstructions int64                // Prevent infinite loops
	instructionCount int64               // Current instruction count
}

// ProcessorFlags simulates Z80 flags for conditional operations
type ProcessorFlags struct {
	Zero    bool
	Carry   bool  
	Sign    bool
	Parity  bool
}

// CallFrame represents a function call context
type CallFrame struct {
	function    *ir.Function
	returnPC    int
	localRegs   map[ir.Register]int64
}

// Deprecated: Use mirvm.New() instead. See MIRInterpreter doc comment.
func NewMIRInterpreter() *MIRInterpreter {
	return &MIRInterpreter{
		registers:       make(map[ir.Register]int64),
		memory:          make(map[int64]byte),
		stack:           make([]int64, 0, 256),
		callStack:       make([]CallFrame, 0, 32),
		functions:       make(map[string]*ir.Function),
		labels:          make(map[string]int),
		strings:         make(map[int64]string),
		nextStringID:    1000, // Start string IDs at 1000
		maxInstructions: 10000, // Reasonable limit for metaprogramming
	}
}

// Execute runs a MIR function with given arguments
func (interp *MIRInterpreter) Execute(function *ir.Function, args []int64) (int64, error) {
	// Reset interpreter state
	interp.pc = 0
	interp.instructionCount = 0
	interp.output.Reset()
	
	// Set up function context
	err := interp.setupFunction(function, args)
	if err != nil {
		return 0, err
	}
	
	// Build label map
	interp.buildLabelMap(function)
	
	// Execute instructions
	for interp.pc < len(function.Instructions) {
		// Check execution limits
		interp.instructionCount++
		if interp.instructionCount > interp.maxInstructions {
			return 0, fmt.Errorf("execution limit exceeded (%d instructions)", interp.maxInstructions)
		}
		
		inst := &function.Instructions[interp.pc]
		err := interp.executeInstruction(inst)
		if err != nil {
			return 0, fmt.Errorf("execution error at PC=%d: %v", interp.pc, err)
		}
		
		interp.pc++
	}
	
	// Return result (convention: return value in RegRet)
	return interp.registers[ir.RegRet], nil
}

// setupFunction initializes the function execution context
func (interp *MIRInterpreter) setupFunction(function *ir.Function, args []int64) error {
	// Clear registers
	for k := range interp.registers {
		delete(interp.registers, k)
	}
	
	// Set up parameters — use args length directly since Params is often
	// not populated by the IR builder. Arguments are loaded positionally.
	if len(function.Params) > 0 && len(args) > len(function.Params) {
		return fmt.Errorf("too many arguments: got %d, expected %d", len(args), len(function.Params))
	}

	// Load arguments into parameter registers
	for i, arg := range args {
		paramReg := ir.Register(i + 1) // Params start at register 1
		interp.registers[paramReg] = arg
	}
	
	return nil
}

// buildLabelMap creates mapping from labels to instruction indices
func (interp *MIRInterpreter) buildLabelMap(function *ir.Function) {
	// Clear existing labels
	for k := range interp.labels {
		delete(interp.labels, k)
	}
	
	// Map labels to instruction indices
	for i, inst := range function.Instructions {
		if inst.Op == ir.OpLabel && inst.Label != "" {
			interp.labels[inst.Label] = i
		}
	}
}

// executeInstruction executes a single MIR instruction
func (interp *MIRInterpreter) executeInstruction(inst *ir.Instruction) error {
	switch inst.Op {
	// Control flow
	case ir.OpNop:
		// Do nothing
		
	case ir.OpLabel:
		// Labels are handled by buildLabelMap
		
	case ir.OpJump:
		return interp.executeJump(inst.Label)
		
	case ir.OpJumpIf:
		if interp.flags.Zero {
			return interp.executeJump(inst.Label)
		}
		
	case ir.OpJumpIfNot:
		if !interp.flags.Zero {
			return interp.executeJump(inst.Label)
		}
		
	case ir.OpCall:
		return interp.executeCall(inst)
		
	case ir.OpReturn:
		val := interp.registers[inst.Src1]
		interp.registers[ir.RegRet] = val
		// Force exit by setting pc past the end of instructions
		// The Execute loop will exit when pc >= len(instructions)
		interp.pc = 1000000 // Large value to force exit
		
	// Data movement
	case ir.OpLoadConst:
		interp.registers[inst.Dest] = inst.Imm
		
	case ir.OpMove:
		interp.registers[inst.Dest] = interp.registers[inst.Src1]
		
	// Arithmetic
	case ir.OpAdd:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		result := val1 + val2
		interp.registers[inst.Dest] = result
		interp.updateFlags(result)
		
	case ir.OpSub:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		result := val1 - val2
		interp.registers[inst.Dest] = result
		interp.updateFlags(result)
		
	case ir.OpMul:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		result := val1 * val2
		interp.registers[inst.Dest] = result
		interp.updateFlags(result)
		
	case ir.OpDiv:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val2 == 0 {
			return fmt.Errorf("division by zero")
		}
		result := val1 / val2
		interp.registers[inst.Dest] = result
		interp.updateFlags(result)
		
	// Comparison
	case ir.OpCmp:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		result := val1 - val2
		interp.updateFlags(result)
		
	case ir.OpEq:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 == val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpNe:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 != val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpLt:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 < val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpGt:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 > val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpLe:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 <= val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpGe:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		if val1 >= val2 {
			interp.registers[inst.Dest] = 1
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	// Bitwise operations
	case ir.OpAnd:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		interp.registers[inst.Dest] = val1 & val2
		
	case ir.OpOr:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		interp.registers[inst.Dest] = val1 | val2
		
	case ir.OpXor:
		val1 := interp.registers[inst.Src1]
		val2 := interp.registers[inst.Src2]
		interp.registers[inst.Dest] = val1 ^ val2
		
	case ir.OpNot:
		val := interp.registers[inst.Src1]
		interp.registers[inst.Dest] = ^val
		
	case ir.OpShl:
		val := interp.registers[inst.Src1]
		shift := interp.registers[inst.Src2]
		interp.registers[inst.Dest] = val << uint(shift)
		
	case ir.OpShr:
		val := interp.registers[inst.Src1]
		shift := interp.registers[inst.Src2]
		interp.registers[inst.Dest] = val >> uint(shift)
		
	// Memory operations (simulated)
	case ir.OpLoad:
		addr := interp.registers[inst.Src1]
		if val, exists := interp.memory[addr]; exists {
			interp.registers[inst.Dest] = int64(val)
		} else {
			interp.registers[inst.Dest] = 0
		}
		
	case ir.OpStore:
		addr := interp.registers[inst.Dest]
		val := byte(interp.registers[inst.Src1] & 0xFF)
		interp.memory[addr] = val
		
	case ir.OpLoadString:
		// Load a string constant
		if inst.Symbol != "" {
			id := interp.storeString(inst.Symbol)
			interp.registers[inst.Dest] = id
		}

	// Array operations
	case ir.OpLoadIndex:
		// r0 = r1[r2] - load from array with dynamic index
		baseAddr := interp.registers[inst.Src1]
		index := interp.registers[inst.Src2]
		addr := baseAddr + index
		if val, exists := interp.memory[addr]; exists {
			interp.registers[inst.Dest] = int64(val)
		} else {
			interp.registers[inst.Dest] = 0
		}

	case ir.OpStoreIndex:
		// r1[r2] = r0 - store to array with dynamic index
		baseAddr := interp.registers[inst.Src1]
		index := interp.registers[inst.Src2]
		addr := baseAddr + index
		val := byte(interp.registers[inst.Dest] & 0xFF)
		interp.memory[addr] = val

	case ir.OpLoadElement:
		// r0 = r1[imm] - load from array with constant index
		baseAddr := interp.registers[inst.Src1]
		addr := baseAddr + inst.Imm
		if val, exists := interp.memory[addr]; exists {
			interp.registers[inst.Dest] = int64(val)
		} else {
			interp.registers[inst.Dest] = 0
		}

	case ir.OpStoreElement:
		// r1[imm] = r0 - store to array with constant index
		baseAddr := interp.registers[inst.Src1]
		addr := baseAddr + inst.Imm
		val := byte(interp.registers[inst.Dest] & 0xFF)
		interp.memory[addr] = val

	// Struct field operations
	case ir.OpLoadField:
		// r0 = r1.field[offset] - load struct field
		baseAddr := interp.registers[inst.Src1]
		addr := baseAddr + inst.Imm
		if val, exists := interp.memory[addr]; exists {
			interp.registers[inst.Dest] = int64(val)
		} else {
			interp.registers[inst.Dest] = 0
		}

	case ir.OpStoreField:
		// r1.field[offset] = r0 - store struct field
		baseAddr := interp.registers[inst.Src1]
		addr := baseAddr + inst.Imm
		val := byte(interp.registers[inst.Src2] & 0xFF)
		interp.memory[addr] = val

	// Parameter loading
	case ir.OpLoadParam:
		// r0 = param name - load function parameter by name
		// Find parameter by name and copy its value
		paramFound := false
		for _, fn := range interp.functions {
			for i, param := range fn.Params {
				if param.Name == inst.Symbol {
					paramReg := ir.Register(i + 1) // Params start at register 1
					interp.registers[inst.Dest] = interp.registers[paramReg]
					paramFound = true
					break
				}
			}
			if paramFound {
				break
			}
		}
		if !paramFound {
			// Try to use Symbol as direct register reference
			interp.registers[inst.Dest] = 0
		}

	// Variable operations
	case ir.OpLoadVar:
		// Load from named variable - for now, treat as memory load from symbol address
		// In full implementation, would look up variable in symbol table
		interp.registers[inst.Dest] = 0

	case ir.OpStoreVar:
		// Store to named variable - for now, no-op
		// In full implementation, would store to symbol table location

	default:
		return fmt.Errorf("unimplemented opcode: %v", inst.Op)
	}
	
	return nil
}

// executeJump performs a jump to a label
func (interp *MIRInterpreter) executeJump(label string) error {
	if label == "" {
		return fmt.Errorf("empty jump label")
	}
	
	targetPC, exists := interp.labels[label]
	if !exists {
		return fmt.Errorf("undefined label: %s", label)
	}
	
	interp.pc = targetPC - 1 // -1 because pc will be incremented
	return nil
}

// executeCall handles function calls (built-ins for now)
func (interp *MIRInterpreter) executeCall(inst *ir.Instruction) error {
	switch inst.Symbol {
	case "string_concat":
		return interp.builtinStringConcat(inst)
	case "string_format":
		return interp.builtinStringFormat(inst)
	case "to_string":
		return interp.builtinToString(inst)
	case "print_code":
		return interp.builtinPrintCode(inst)
	default:
		return fmt.Errorf("unknown function: %s", inst.Symbol)
	}
}

// updateFlags updates processor flags based on result
func (interp *MIRInterpreter) updateFlags(result int64) {
	interp.flags.Zero = (result == 0)
	interp.flags.Sign = (result < 0)
	interp.flags.Carry = false // Simplified for now
	interp.flags.Parity = false // Simplified for now
}

// String management functions

// storeString stores a string and returns its ID
func (interp *MIRInterpreter) storeString(s string) int64 {
	id := interp.nextStringID
	interp.nextStringID++
	interp.strings[id] = s
	return id
}

// getString retrieves a string by ID
func (interp *MIRInterpreter) getString(id int64) string {
	if str, exists := interp.strings[id]; exists {
		return str
	}
	return ""
}

// Built-in functions for metaprogramming

// builtinStringConcat concatenates two strings
func (interp *MIRInterpreter) builtinStringConcat(inst *ir.Instruction) error {
	str1ID := interp.registers[inst.Args[0]]
	str2ID := interp.registers[inst.Args[1]]
	
	str1 := interp.getString(str1ID)
	str2 := interp.getString(str2ID)
	
	result := str1 + str2
	resultID := interp.storeString(result)
	
	interp.registers[inst.Dest] = resultID
	return nil
}

// builtinStringFormat formats a string with arguments
func (interp *MIRInterpreter) builtinStringFormat(inst *ir.Instruction) error {
	formatID := interp.registers[inst.Args[0]]
	formatStr := interp.getString(formatID)
	
	// Simple template substitution - replace {0}, {1}, etc.
	result := formatStr
	for i := 1; i < len(inst.Args); i++ {
		placeholder := fmt.Sprintf("{%d}", i-1)
		value := fmt.Sprintf("%d", interp.registers[inst.Args[i]])
		result = strings.ReplaceAll(result, placeholder, value)
	}
	
	resultID := interp.storeString(result)
	interp.registers[inst.Dest] = resultID
	return nil
}

// builtinToString converts a number to string
func (interp *MIRInterpreter) builtinToString(inst *ir.Instruction) error {
	value := interp.registers[inst.Args[0]]
	str := strconv.FormatInt(value, 10)
	resultID := interp.storeString(str)
	interp.registers[inst.Dest] = resultID
	return nil
}

// builtinPrintCode adds code to the output
func (interp *MIRInterpreter) builtinPrintCode(inst *ir.Instruction) error {
	codeID := interp.registers[inst.Args[0]]
	code := interp.getString(codeID)
	interp.output.WriteString(code)
	return nil
}

// GetGeneratedCode returns the generated MinZ code
func (interp *MIRInterpreter) GetGeneratedCode() string {
	return interp.output.String()
}

// ExecuteMinzCode executes MinZ code string with full template substitution
func (interp *MIRInterpreter) ExecuteMinzCode(code string, args []interface{}) (string, error) {
	// Enhanced template substitution supporting strings and numbers
	result := code
	for i, arg := range args {
		placeholder := fmt.Sprintf("{%d}", i)
		var value string
		
		switch v := arg.(type) {
		case int64:
			value = fmt.Sprintf("%d", v)
		case string:
			value = v
		case bool:
			if v {
				value = "true"
			} else {
				value = "false"
			}
		default:
			value = fmt.Sprintf("%v", v)
		}
		
		result = strings.ReplaceAll(result, placeholder, value)
	}
	
	return result, nil
}

// ExecuteMinzMetafunction processes @minz metafunction calls
func (interp *MIRInterpreter) ExecuteMinzMetafunction(template string, args []interface{}) (string, error) {
	// Validate template
	if template == "" {
		return "", fmt.Errorf("empty @minz template")
	}
	
	// Count expected placeholders
	maxPlaceholder := -1
	for i := 0; i < len(args); i++ {
		placeholder := fmt.Sprintf("{%d}", i)
		if strings.Contains(template, placeholder) {
			maxPlaceholder = i
		}
	}
	
	// Verify all arguments are used
	if maxPlaceholder >= len(args) {
		return "", fmt.Errorf("template expects %d arguments, got %d", maxPlaceholder+1, len(args))
	}
	
	// Generate code
	return interp.ExecuteMinzCode(template, args)
}

// ValidateTemplate checks template syntax and placeholders
func (interp *MIRInterpreter) ValidateTemplate(template string, expectedArgs int) error {
	// Check for balanced braces
	openBraces := strings.Count(template, "{")
	closeBraces := strings.Count(template, "}")
	if openBraces != closeBraces {
		return fmt.Errorf("unbalanced braces in template: %d open, %d close", openBraces, closeBraces)
	}
	
	// Check placeholder sequence
	for i := 0; i < expectedArgs; i++ {
		placeholder := fmt.Sprintf("{%d}", i)
		if !strings.Contains(template, placeholder) {
			return fmt.Errorf("missing placeholder {%d} in template", i)
		}
	}
	
	return nil
}