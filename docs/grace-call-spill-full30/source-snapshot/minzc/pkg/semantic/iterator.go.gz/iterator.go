package semantic

import (
	"fmt"
	"github.com/minz/minzc/pkg/ast"
	"github.com/minz/minzc/pkg/ir"
)

// Iterator support for semantic analysis

// typesEqual checks if two types are equal
func typesEqual(a, b ir.Type) bool {
	// Simple string comparison for now
	// TODO: Implement proper structural equality
	return a.String() == b.String()
}

// analyzeIteratorChainExpr analyzes an iterator chain and generates optimized code
func (a *Analyzer) analyzeIteratorChainExpr(chain *ast.IteratorChainExpr, irFunc *ir.Function) (ir.Register, error) {
	// Track source position from the chain expression for debug info
	a.trackSourcePos(chain)

	// Get the source type to determine iteration strategy
	sourceType, err := a.inferType(chain.Source)
	if err != nil {
		return 0, fmt.Errorf("failed to infer source type: %w", err)
	}
	
	// Get element type
	elementType := a.getIterableElementType(sourceType)
	if elementType == nil {
		return 0, fmt.Errorf("cannot iterate over type %s", sourceType)
	}
	
	// Analyze the source to get its address
	sourceReg, err := a.analyzeExpression(chain.Source, irFunc)
	if err != nil {
		return 0, fmt.Errorf("failed to analyze iterator source: %w", err)
	}
	
	// Generate iteration code based on source type
	switch st := sourceType.(type) {
	case *ir.ArrayType:
		return a.generateArrayIteration(chain, sourceReg, st, elementType, irFunc)
	case *ir.PointerType:
		// String iteration
		if basicType, ok := st.Base.(*ir.BasicType); ok && basicType.Kind == ir.TypeU8 {
			return a.generateStringIteration(chain, sourceReg, irFunc)
		}
		return 0, fmt.Errorf("cannot iterate over pointer type %s", sourceType)
	default:
		return 0, fmt.Errorf("cannot iterate over type %s", sourceType)
	}
}

// analyzeIteratorChainType analyzes the type of an iterator chain expression
func (a *Analyzer) analyzeIteratorChainType(chain *ast.IteratorChainExpr) (ir.Type, error) {
	// Infer the type of the source collection
	sourceType, err := a.inferType(chain.Source)
	if err != nil {
		return nil, err
	}
	
	// Verify source is iterable
	elementType := a.getIterableElementType(sourceType)
	if elementType == nil {
		return nil, fmt.Errorf("type %s is not iterable", sourceType)
	}
	
	// Track the current type through the chain
	currentType := elementType
	
	for _, op := range chain.Operations {
		newType, err := a.analyzeIteratorOpType(op, currentType)
		if err != nil {
			return nil, err
		}
		currentType = newType
	}
	
	// The final type depends on the last operation
	if len(chain.Operations) > 0 {
		lastOp := chain.Operations[len(chain.Operations)-1]
		switch lastOp.Type {
		case ast.IterOpCollect:
			// Collect returns an array of the current type
			return &ir.ArrayType{
				Element: currentType,
				Length:  -1, // Dynamic size
			}, nil
		case ast.IterOpForEach:
			// forEach returns void
			return &ir.BasicType{Kind: ir.TypeVoid}, nil
		case ast.IterOpReduce:
			// Reduce returns the accumulator type
			// This would need more analysis of the reduce function
			return currentType, nil
		default:
			// Most operations return an iterator of currentType
			return &ir.IteratorType{
				ElementType: currentType,
			}, nil
		}
	}
	
	return &ir.IteratorType{
		ElementType: currentType,
	}, nil
}

// getIterableElementType returns the element type if the type is iterable
func (a *Analyzer) getIterableElementType(t ir.Type) ir.Type {
	switch typ := t.(type) {
	case *ir.ArrayType:
		return typ.Element
	case *ir.PointerType:
		// Strings are *u8 and are iterable
		if basicType, ok := typ.Base.(*ir.BasicType); ok && basicType.Kind == ir.TypeU8 {
			return &ir.BasicType{Kind: ir.TypeU8} // Characters
		}
	case *ir.IteratorType:
		return typ.ElementType
	}
	return nil
}

// analyzeIteratorOpType analyzes the result type of a single iterator operation
func (a *Analyzer) analyzeIteratorOpType(op ast.IteratorOp, inputType ir.Type) (ir.Type, error) {
	switch op.Type {
	case ast.IterOpMap:
		// Map transforms elements
		// The function should be: fn(T) -> U
		fnType, err := a.inferType(op.Function)
		if err != nil {
			return nil, err
		}
		
		if funcType, ok := fnType.(*ir.FunctionType); ok {
			// Verify input type matches
			if len(funcType.Params) != 1 {
				return nil, fmt.Errorf("map function must take exactly one parameter")
			}
			if !typesEqual(funcType.Params[0], inputType) {
				return nil, fmt.Errorf("map function parameter type %s doesn't match element type %s",
					funcType.Params[0], inputType)
			}
			// Return the output type
			return funcType.Return, nil
		}
		return nil, fmt.Errorf("map requires a function, got %s", fnType)
		
	case ast.IterOpFilter:
		// Filter keeps/removes elements based on predicate
		// The function should be: fn(T) -> bool
		fnType, err := a.inferType(op.Function)
		if err != nil {
			return nil, err
		}
		
		if funcType, ok := fnType.(*ir.FunctionType); ok {
			if len(funcType.Params) != 1 {
				return nil, fmt.Errorf("filter function must take exactly one parameter")
			}
			if !typesEqual(funcType.Params[0], inputType) {
				return nil, fmt.Errorf("filter function parameter type %s doesn't match element type %s",
					funcType.Params[0], inputType)
			}
			if basicType, ok := funcType.Return.(*ir.BasicType); !ok || basicType.Kind != ir.TypeBool {
				return nil, fmt.Errorf("filter function must return bool, got %s", funcType.Return)
			}
			// Filter doesn't change the type
			return inputType, nil
		}
		return nil, fmt.Errorf("filter requires a function, got %s", fnType)
		
	case ast.IterOpForEach:
		// forEach applies a function to each element
		// The function should be: fn(T) -> void
		fnType, err := a.inferType(op.Function)
		if err != nil {
			return nil, err
		}
		
		if funcType, ok := fnType.(*ir.FunctionType); ok {
			if len(funcType.Params) != 1 {
				return nil, fmt.Errorf("forEach function must take exactly one parameter")
			}
			if !typesEqual(funcType.Params[0], inputType) {
				return nil, fmt.Errorf("forEach function parameter type %s doesn't match element type %s",
					funcType.Params[0], inputType)
			}
			// forEach consumes the iterator
			return &ir.BasicType{Kind: ir.TypeVoid}, nil
		}
		return nil, fmt.Errorf("forEach requires a function, got %s", fnType)
		
	case ast.IterOpTake:
		// Take n elements - type stays the same
		return inputType, nil
		
	case ast.IterOpSkip:
		// Skip n elements - type stays the same
		return inputType, nil
		
	case ast.IterOpCollect:
		// Collect into array - handled by caller
		return inputType, nil
		
	case ast.IterOpEnumerate:
		// Enumerate returns tuples of (index, element)
		// For now, we'll keep the element type (tuples not yet supported)
		return inputType, nil
		
	case ast.IterOpChain:
		// Chain concatenates iterators - type stays the same
		return inputType, nil
		
	case ast.IterOpFlatMap:
		// FlatMap transforms and flattens
		// The function should be: fn(T) -> [U]
		// Result type is U (the element type of the returned array)
		fnType, err := a.inferType(op.Function)
		if err != nil {
			return nil, err
		}
		
		if funcType, ok := fnType.(*ir.FunctionType); ok {
			if len(funcType.Params) != 1 {
				return nil, fmt.Errorf("flatMap function must take exactly one parameter")
			}
			// Return type should be an array
			if arrayType, ok := funcType.Return.(*ir.ArrayType); ok {
				return arrayType.Element, nil
			}
			return nil, fmt.Errorf("flatMap function must return an array, got %s", funcType.Return)
		}
		return nil, fmt.Errorf("flatMap requires a function, got %s", fnType)
		
	case ast.IterOpTakeWhile, ast.IterOpSkipWhile:
		// These take predicates and don't change the type
		return inputType, nil
		
	case ast.IterOpPeek, ast.IterOpInspect:
		// These are side-effect operations that don't change the type
		return inputType, nil
		
	default:
		return nil, fmt.Errorf("unsupported iterator operation: %v", op.Type)
	}
}

// isIteratorMethod checks if a method name is an iterator method
func isIteratorMethod(name string) bool {
	switch name {
	case "iter", "map", "filter", "forEach", "reduce", "collect", 
	     "take", "skip", "zip", "enumerate", "chain", "flatMap",
	     "takeWhile", "skipWhile", "peek", "inspect":
		return true
	}
	return false
}

// generateArrayIteration generates code for iterating over an array
func (a *Analyzer) generateArrayIteration(chain *ast.IteratorChainExpr, sourceReg ir.Register, 
	arrayType *ir.ArrayType, elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {
	
	// Check if we have enhanced operations that require special handling
	hasEnhancedOps := false
	for _, op := range chain.Operations {
		switch op.Type {
		case ast.IterOpSkip, ast.IterOpTake, ast.IterOpEnumerate,
		     ast.IterOpChain, ast.IterOpFlatMap, ast.IterOpTakeWhile,
		     ast.IterOpSkipWhile, ast.IterOpPeek, ast.IterOpInspect,
		     ast.IterOpReduce:
			hasEnhancedOps = true
		}
		if hasEnhancedOps {
			break
		}
	}
	
	// Check if we can use DJNZ optimization (arrays ≤255 elements)
	useDJNZ := arrayType.Length > 0 && arrayType.Length <= 255
	
	if useDJNZ && hasEnhancedOps {
		// Use enhanced DJNZ generation for complex operations
		a.tracer.Log("semantic", "DJNZ loop (enhanced): array[%d] (≤255 threshold)", arrayType.Length)
		return a.generateEnhancedDJNZIteration(chain, sourceReg, arrayType, elementType, irFunc)
	} else if useDJNZ {
		// Use standard DJNZ for simple operations
		a.tracer.Log("semantic", "DJNZ loop: array[%d] (≤255 threshold)", arrayType.Length)
		return a.generateDJNZIteration(chain, sourceReg, arrayType, elementType, irFunc)
	}
	
	// Fall back to standard indexed iteration for large arrays
	return a.generateIndexedIteration(chain, sourceReg, arrayType, elementType, irFunc)
}

// generateDJNZIteration generates optimized DJNZ loop for arrays ≤255 elements
// This uses pointer arithmetic and DJNZ instruction for 3x performance
func (a *Analyzer) generateDJNZIteration(chain *ast.IteratorChainExpr, sourceReg ir.Register,
	arrayType *ir.ArrayType, elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {
	
	// Add debug comment
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:      ir.OpNop,
		Comment: fmt.Sprintf("DJNZ OPTIMIZED LOOP for array[%d]", arrayType.Length),
	})
	
	// Generate labels for the loop
	loopLabel := a.generateLabel("djnz_loop")
	
	// Allocate registers for DJNZ pattern
	counterReg := irFunc.AllocReg()  // B register for DJNZ
	ptrReg := irFunc.AllocReg()      // HL register for pointer
	elementReg := irFunc.AllocReg()  // A register for element
	
	// Initialize counter (B register) with array length
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoadConst,
		Dest: counterReg,
		Imm:  int64(arrayType.Length),
		Type: &ir.BasicType{Kind: ir.TypeU8},
		Hint: ir.RegHintB, // Hint to use B register for DJNZ
		Comment: fmt.Sprintf("DJNZ counter = %d", arrayType.Length),
	})
	
	// Initialize pointer to array start
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpMove,
		Dest: ptrReg,
		Src1: sourceReg,
		Type: &ir.PointerType{Base: elementType},
		Hint: ir.RegHintHL, // Hint to use HL register pair
		Comment: "Pointer to array start",
	})
	
	// Loop start
	irFunc.EmitLabel(loopLabel)
	
	// Load element through pointer
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoad,
		Dest: elementReg,
		Src1: ptrReg,
		Type: elementType,
		Hint: ir.RegHintA, // Prefer A register for element (accumulator operations)
		Comment: "Load element via pointer",
	})
	
	// Apply iterator operations
	// Operations may call functions (map, filter, forEach) which clobber HL.
	// We PUSH/POP the array pointer around the operation block to preserve it.
	currentReg := elementReg
	var continueLabels []string

	// Check if any operation calls a function (needs pointer save/restore)
	hasCallOps := false
	for _, op := range chain.Operations {
		switch op.Type {
		case ast.IterOpMap, ast.IterOpForEach, ast.IterOpPeek, ast.IterOpInspect:
			if op.Function != nil {
				hasCallOps = true
			}
		case ast.IterOpFilter:
			// Inline filters don't need save, but complex ones do
			if op.Function != nil {
				hasCallOps = true
			}
		case ast.IterOpReduce, ast.IterOpEnumerate:
			hasCallOps = true
		}
	}

	if hasCallOps {
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:      ir.OpPush,
			Src1:    ptrReg,
			Comment: "Save array pointer before operations",
		})
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:      ir.OpPush,
			Src1:    counterReg,
			Hint:    ir.RegHintB,
			Comment: "Save DJNZ counter before operations (BC preserved across CALL)",
		})
	}

	for _, op := range chain.Operations {
		// Handle filter operations specially - they need continue labels
		if op.Type == ast.IterOpFilter {
			// Try inline optimization for simple comparison lambdas
			if lambda, ok := op.Function.(*ast.LambdaExpr); ok {
				if flagCond, constVal, isSimple := isSimpleComparisonLambda(lambda); isSimple {
					a.tracer.Log("semantic", "Inline filter: CP %d + JR %s (saved ~27 T-states/iter)", constVal, flagCond)
					// Inline: emit OpJumpIfFlag directly (no lambda, no OpCall)
					constReg := irFunc.AllocReg()
					irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
						Op:   ir.OpLoadConst,
						Dest: constReg,
						Imm:  constVal,
						Type: &ir.BasicType{Kind: ir.TypeU8},
						Comment: fmt.Sprintf("Inline filter constant = %d", constVal),
					})

					continueLabel := a.generateLabel("filter_continue")
					continueLabels = append(continueLabels, continueLabel)

					irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
						Op:    ir.OpJumpIfFlag,
						Src1:  currentReg,
						Src2:  constReg,
						Imm:   int64(flagCond),
						Label: continueLabel,
						Comment: fmt.Sprintf("Inline filter: CP %d + JR %s", constVal, flagCond),
					})
					continue
				}
			}

			// Fallback: call the filter predicate as a function
			a.tracer.Log("semantic", "Filter via lambda call: %T (not inlineable)", op.Function)
			predicateResult, err := a.applyIteratorFunction(op.Function, currentReg, elementType, irFunc)
			if err != nil {
				return 0, fmt.Errorf("failed to apply filter predicate: %w", err)
			}

			// Generate continue label for this filter
			continueLabel := a.generateLabel("filter_continue")
			continueLabels = append(continueLabels, continueLabel)

			// Jump to continue if predicate is false
			irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
				Op:    ir.OpJumpIfNot,
				Src1:  predicateResult,
				Label: continueLabel,
				Comment: "Skip if filter predicate is false",
			})
			// Filter doesn't change the element value
		} else {
			// Apply other operations normally
			newReg, err := a.applyIteratorOperation(op, currentReg, elementType, irFunc)
			if err != nil {
				return 0, fmt.Errorf("failed to apply iterator operation: %w", err)
			}
			currentReg = newReg
		}
	}

	// Emit continue labels for filters (right before loop increment)
	for _, label := range continueLabels {
		irFunc.EmitLabel(label)
	}

	// Restore counter and array pointer after operations (before increment)
	if hasCallOps {
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:      ir.OpPop,
			Dest:    counterReg,
			Hint:    ir.RegHintB,
			Comment: "Restore DJNZ counter after operations (BC preserved across CALL)",
		})
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:      ir.OpPop,
			Dest:    ptrReg,
			Comment: "Restore array pointer after operations",
		})
	}

	// Increment pointer to next element
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpInc,
		Dest: ptrReg,
		Src1: ptrReg,
		Type: &ir.PointerType{Base: elementType},
		Hint: ir.RegHintHL,
		Comment: "Advance to next element",
	})

	// DJNZ instruction - decrement counter and jump if not zero
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:    ir.OpDJNZ,
		Src1:  counterReg,
		Label: loopLabel,
		Hint:  ir.RegHintB,
		Comment: "DJNZ - decrement and loop",
	})
	
	// No end label needed - DJNZ handles the exit condition
	
	// Return void register (iterators don't return values)
	return 0, nil
}

// generateIndexedIteration generates standard indexed loop for large arrays
func (a *Analyzer) generateIndexedIteration(chain *ast.IteratorChainExpr, sourceReg ir.Register,
	arrayType *ir.ArrayType, elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {
	
	// Generate labels for the loop
	loopLabel := a.generateLabel("iter_loop")
	endLabel := a.generateLabel("iter_end")
	
	// Allocate registers for iteration
	indexReg := irFunc.AllocReg()
	elementPtrReg := irFunc.AllocReg()
	elementReg := irFunc.AllocReg()
	lengthReg := irFunc.AllocReg()
	
	// Initialize index to 0
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoadConst,
		Dest: indexReg,
		Imm:  0,
		Type: &ir.BasicType{Kind: ir.TypeU8},
		Comment: "Iterator index = 0",
	})
	
	// Load array length
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoadConst,
		Dest: lengthReg,
		Imm:  int64(arrayType.Length),
		Type: &ir.BasicType{Kind: ir.TypeU8},
		Comment: fmt.Sprintf("Array length = %d", arrayType.Length),
	})
	
	// Loop start
	irFunc.EmitLabel(loopLabel)
	
	// Check if index < length
	condReg := irFunc.AllocReg()
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLt,
		Dest: condReg,
		Src1: indexReg,
		Src2: lengthReg,
		Type: &ir.BasicType{Kind: ir.TypeBool},
		Comment: "Check index < length",
	})
	
	// Jump to end if done
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:    ir.OpJumpIfNot,
		Src1:  condReg,
		Label: endLabel,
	})
	
	// Calculate element address: base + index * element_size
	// For u8 arrays, element_size = 1
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpAdd,
		Dest: elementPtrReg,
		Src1: sourceReg,
		Src2: indexReg,
		Type: &ir.PointerType{Base: elementType},
		Comment: "Calculate element address",
	})
	
	// Load element value
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoad,
		Dest: elementReg,
		Src1: elementPtrReg,
		Type: elementType,
		Comment: "Load array element",
	})
	
	// Apply iterator operations
	currentReg := elementReg
	var continueLabels []string
	
	for _, op := range chain.Operations {
		// Handle filter operations specially - they need continue labels
		if op.Type == ast.IterOpFilter {
			// Call the filter predicate
			predicateResult, err := a.applyIteratorFunction(op.Function, currentReg, elementType, irFunc)
			if err != nil {
				return 0, fmt.Errorf("failed to apply filter predicate: %w", err)
			}
			
			// Generate continue label for this filter
			continueLabel := a.generateLabel("filter_continue")
			continueLabels = append(continueLabels, continueLabel)
			
			// Jump to continue if predicate is false
			irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
				Op:    ir.OpJumpIfNot,
				Src1:  predicateResult,
				Label: continueLabel,
				Comment: "Skip if filter predicate is false",
			})
			// Filter doesn't change the element value
		} else {
			// Apply other operations normally
			newReg, err := a.applyIteratorOperation(op, currentReg, elementType, irFunc)
			if err != nil {
				return 0, fmt.Errorf("failed to apply iterator operation: %w", err)
			}
			currentReg = newReg
		}
	}
	
	// Emit continue labels for filters (right before loop increment)
	for _, label := range continueLabels {
		irFunc.EmitLabel(label)
	}
	
	// Increment index
	oneReg := irFunc.AllocReg()
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpLoadConst,
		Dest: oneReg,
		Imm:  1,
		Type: &ir.BasicType{Kind: ir.TypeU8},
	})
	
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:   ir.OpAdd,
		Dest: indexReg,
		Src1: indexReg,
		Src2: oneReg,
		Type: &ir.BasicType{Kind: ir.TypeU8},
		Comment: "Increment index",
	})
	
	// Jump back to loop start
	irFunc.EmitJump(loopLabel)
	
	// End label
	irFunc.EmitLabel(endLabel)
	
	// Return void register (iterators don't return values)
	return 0, nil
}

// generateStringIteration generates code for iterating over a string
func (a *Analyzer) generateStringIteration(chain *ast.IteratorChainExpr, sourceReg ir.Register, 
	irFunc *ir.Function) (ir.Register, error) {
	// TODO: Implement string iteration with u8/u16 length support
	return 0, fmt.Errorf("string iteration not yet implemented")
}

// applyIteratorOperation applies a single iterator operation to the current element
func (a *Analyzer) applyIteratorOperation(op ast.IteratorOp, elementReg ir.Register, 
	elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {
	
	switch op.Type {
	case ast.IterOpMap:
		// Apply transformation function
		if op.Function == nil {
			return 0, fmt.Errorf("map requires a function")
		}
		return a.applyIteratorFunction(op.Function, elementReg, elementType, irFunc)
		
	case ast.IterOpFilter:
		// Apply predicate and skip if false
		if op.Function == nil {
			return 0, fmt.Errorf("filter requires a predicate function")
		}
		
		// Call the predicate function
		predicateResult, err := a.applyIteratorFunction(op.Function, elementReg, elementType, irFunc)
		if err != nil {
			return 0, fmt.Errorf("failed to apply filter predicate: %w", err)
		}
		
		// Generate continue label for this filter
		continueLabel := a.generateLabel("filter_continue")
		
		// Jump to continue (skip rest of operations) if predicate is false
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:    ir.OpJumpIfNot,
			Src1:  predicateResult,
			Label: continueLabel,
			Comment: "Skip if filter predicate is false",
		})
		
		// Note: We need to emit the continue label at the end of the loop body
		// For now, we'll store it and the caller will handle it
		// This is a limitation - we need better control flow handling
		
		// Return the element register unchanged (filter doesn't transform the value)
		return elementReg, nil
		
	case ast.IterOpForEach:
		// Apply function to each element
		if op.Function == nil {
			return 0, fmt.Errorf("forEach requires a function")
		}
		_, err := a.applyIteratorFunction(op.Function, elementReg, elementType, irFunc)
		return elementReg, err
		
	case ast.IterOpTake, ast.IterOpSkip:
		// These operations are handled at the loop level, not per-element
		// Just pass through the element unchanged
		return elementReg, nil
		
	case ast.IterOpEnumerate:
		// Enumerate adds index tracking - handled at loop level
		return elementReg, nil
		
	case ast.IterOpPeek, ast.IterOpInspect:
		// Call function but don't change element
		if op.Function == nil {
			return 0, fmt.Errorf("%v requires a function", op.Type)
		}
		_, err := a.applyIteratorFunction(op.Function, elementReg, elementType, irFunc)
		return elementReg, err
		
	default:
		return 0, fmt.Errorf("iterator operation %v not yet implemented", op.Type)
	}
}

// applyIteratorFunction applies a function to an element in an iterator chain
func (a *Analyzer) applyIteratorFunction(function ast.Expression, elementReg ir.Register,
	elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {

	if function == nil {
		return elementReg, nil // No function to apply (e.g., take/skip/enumerate)
	}

	// Handle different function types
	switch function.(type) {
	case *ast.Identifier:
		// Use the new overload resolver
		funcSym, err := a.resolveIteratorFunction(function, elementType, irFunc)
		if err != nil {
			// Fallback for built-in functions
			if ident, ok := function.(*ast.Identifier); ok {
				funcName := ident.Name
				if funcName == "print_u8" || funcName == "print_u16" {
					// Handle built-in print functions
					irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
						Op:      ir.OpCall,
						Symbol:  funcName,
						Args:    []ir.Register{elementReg},
						Comment: fmt.Sprintf("Call %s", funcName),
					})
					return 0, nil // print functions return void
				}
			}
			
			return 0, fmt.Errorf("cannot resolve function in iterator: %w", err)
		}
		
		// Create call instruction
		resultReg := irFunc.AllocReg()
		irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
			Op:      ir.OpCall,
			Dest:    resultReg,
			Symbol:  funcSym.Name,
			Args:    []ir.Register{elementReg},
			Type:    funcSym.ReturnType,
			Comment: fmt.Sprintf("Call %s", funcSym.Name),
		})
		
		return resultReg, nil
		
	case *ast.LambdaExpr:
		// Lambda expression - generate as separate function and call it
		return a.generateIteratorLambda(function.(*ast.LambdaExpr), elementReg, elementType, irFunc)
		
	default:
		return 0, fmt.Errorf("unsupported function type in iterator: %T", function)
	}
}

// transformIteratorMethodCall transforms method calls into iterator chains
// This is called during expression analysis when we see patterns like array.map(f)
func (a *Analyzer) transformIteratorMethodCall(object ast.Expression, method string, 
	args []ast.Expression) (*ast.IteratorChainExpr, error) {
	
	// Check if this is an iterator method
	if !isIteratorMethod(method) {
		return nil, nil // Not an iterator method
	}
	
	// Build the iterator chain
	chain := &ast.IteratorChainExpr{
		Source:   object,
		StartPos: object.Pos(),
	}
	
	// Add the operation
	var opType ast.IteratorOpType
	switch method {
	case "iter":
		// Just start the chain, no operation needed
		return chain, nil
	case "map":
		opType = ast.IterOpMap
	case "filter":
		opType = ast.IterOpFilter
	case "forEach":
		opType = ast.IterOpForEach
	case "reduce":
		opType = ast.IterOpReduce
	case "collect":
		opType = ast.IterOpCollect
	case "take":
		opType = ast.IterOpTake
	case "skip":
		opType = ast.IterOpSkip
	case "zip":
		opType = ast.IterOpZip
	case "enumerate":
		opType = ast.IterOpEnumerate
	case "chain":
		opType = ast.IterOpChain
	case "flatMap":
		opType = ast.IterOpFlatMap
	case "takeWhile":
		opType = ast.IterOpTakeWhile
	case "skipWhile":
		opType = ast.IterOpSkipWhile
	case "peek":
		opType = ast.IterOpPeek
	case "inspect":
		opType = ast.IterOpInspect
	default:
		return nil, fmt.Errorf("unknown iterator method: %s", method)
	}
	
	// Most iterator methods take a function argument
	var function ast.Expression
	if len(args) > 0 {
		function = args[0]
	}
	
	chain.Operations = append(chain.Operations, ast.IteratorOp{
		Type:     opType,
		Function: function,
	})
	
	return chain, nil
}

// generateIteratorLambda converts a lambda expression to a function and calls it
// This enables zero-cost lambda abstractions in iterator chains
func (a *Analyzer) generateIteratorLambda(lambda *ast.LambdaExpr, elementReg ir.Register, 
	elementType ir.Type, irFunc *ir.Function) (ir.Register, error) {
	
	// Generate unique lambda name specific to iterator context
	lambdaName := fmt.Sprintf("iter_lambda_%s_%d", irFunc.Name, a.lambdaCounter)
	a.lambdaCounter++
	a.tracer.Log("semantic", "Lambda extracted: %s", lambdaName)
	
	// Validate lambda parameter count
	if len(lambda.Params) != 1 {
		return 0, fmt.Errorf("iterator lambda must take exactly one parameter, got %d", len(lambda.Params))
	}
	
	// Create a new function for the lambda
	lambdaFunc := &ir.Function{
		Name:         lambdaName,
		Params:       []ir.Parameter{},
		Instructions: []ir.Instruction{},
		IsSMCDefault: false,  // Disable SMC temporarily to test basic functionality
		IsSMCEnabled: false,
		CallingConvention: "registers", // Use registers for maximum performance
	}
	
	// Add the single parameter
	param := lambda.Params[0]
	var paramType ir.Type = elementType // Use the inferred element type
	
	// Override with explicit type if provided
	if param.Type != nil {
		var err error
		paramType, err = a.convertType(param.Type)
		if err != nil {
			return 0, fmt.Errorf("failed to convert lambda parameter type: %w", err)
		}
		
		// Verify type compatibility with element type
		if !a.typesCompatible(elementType, paramType) {
			return 0, fmt.Errorf("lambda parameter type %s incompatible with element type %s", 
				paramType, elementType)
		}
	}
	
	paramReg := lambdaFunc.AddParamWithRegister(param.Name, paramType, "")
	_ = paramReg // Used by the body analysis through the scope system

	// Determine return type
	var returnType ir.Type = &ir.BasicType{Kind: ir.TypeU8} // Default
	if lambda.ReturnType != nil {
		var err error
		returnType, err = a.convertType(lambda.ReturnType)
		if err != nil {
			return 0, fmt.Errorf("failed to convert lambda return type: %w", err)
		}
	} else {
		// Try to infer return type from body
		if inferredType, err := a.inferIteratorLambdaReturnType(lambda.Body); err == nil {
			returnType = inferredType
		}
	}
	lambdaFunc.ReturnType = returnType
	
	// Create new scope for lambda analysis
	lambdaScope := NewScope(a.currentScope)
	prevScope := a.currentScope
	prevFunc := a.currentFunc
	a.currentScope = lambdaScope
	a.currentFunc = lambdaFunc
	
	// Add parameter to lambda scope
	paramSymbol := &VarSymbol{
		Name: param.Name,
		Type: paramType,
	}
	lambdaScope.Define(param.Name, paramSymbol)
	
	// Analyze lambda body
	var bodyReg ir.Register
	var err error
	
	switch body := lambda.Body.(type) {
	case ast.Expression:
		// Expression body - analyze and return result
		bodyReg, err = a.analyzeExpression(body, lambdaFunc)
		if err != nil {
			a.currentScope = prevScope
			a.currentFunc = prevFunc
			return 0, fmt.Errorf("failed to analyze iterator lambda expression: %w", err)
		}
		
		// Add return instruction
		lambdaFunc.Instructions = append(lambdaFunc.Instructions, ir.Instruction{
			Op:   ir.OpReturn,
			Src1: bodyReg,
			Comment: "Return lambda result",
		})
		
	case *ast.BlockStmt:
		// Block body - analyze block
		err = a.analyzeBlock(body, lambdaFunc)
		if err != nil {
			a.currentScope = prevScope  
			a.currentFunc = prevFunc
			return 0, fmt.Errorf("failed to analyze iterator lambda block: %w", err)
		}
		
		// Ensure block has a return (this should be handled by analyzeBlock)
		
	default:
		a.currentScope = prevScope
		a.currentFunc = prevFunc
		return 0, fmt.Errorf("unsupported lambda body type: %T", body)
	}
	
	// Restore previous context
	a.currentScope = prevScope
	a.currentFunc = prevFunc
	
	// Add the lambda function to the module
	a.module.Functions = append(a.module.Functions, lambdaFunc)
	
	// Generate call to the lambda function
	resultReg := irFunc.AllocReg()
	irFunc.Instructions = append(irFunc.Instructions, ir.Instruction{
		Op:      ir.OpCall,
		Dest:    resultReg,
		Symbol:  lambdaName,
		Args:    []ir.Register{elementReg},
		Type:    returnType,
		Comment: fmt.Sprintf("Call iterator lambda: %s", lambdaName),
	})
	
	return resultReg, nil
}

// inferIteratorLambdaReturnType attempts to infer the return type of a lambda body
func (a *Analyzer) inferIteratorLambdaReturnType(body ast.Node) (ir.Type, error) {
	switch body := body.(type) {
	case ast.Expression:
		// Try to infer the expression type
		return a.inferType(body)
	case *ast.BlockStmt:
		// Look for return statements or final expression
		if len(body.Statements) > 0 {
			lastStmt := body.Statements[len(body.Statements)-1]
			if returnStmt, ok := lastStmt.(*ast.ReturnStmt); ok && returnStmt.Value != nil {
				return a.inferType(returnStmt.Value)
			}
			if exprStmt, ok := lastStmt.(*ast.ExpressionStmt); ok {
				return a.inferType(exprStmt.Expression)
			}
		}
		// Default to void for blocks without explicit return
		return &ir.BasicType{Kind: ir.TypeVoid}, nil
	default:
		return nil, fmt.Errorf("cannot infer return type for lambda body type %T", body)
	}
}

// isSimpleComparisonLambda detects lambdas of the form |x| x OP N or |x| N OP x
// where OP is a comparison operator and N is a numeric constant.
// Returns the comparison operator, constant value (adjusted for CP semantics),
// the flag condition to jump on when the predicate is FALSE, and whether it matched.
func isSimpleComparisonLambda(lambda *ast.LambdaExpr) (flagCond ir.FlagCondition, constVal int64, ok bool) {
	// Must have exactly one parameter
	if len(lambda.Params) != 1 {
		return 0, 0, false
	}
	paramName := lambda.Params[0].Name

	// Get the body expression — handle both direct expression and block with single expression/return
	// Note: *ast.BlockStmt implements ast.Expression, so check it first (more specific)
	var bodyExpr ast.Expression
	switch body := lambda.Body.(type) {
	case *ast.BlockStmt:
		if len(body.Statements) == 1 {
			if retStmt, ok := body.Statements[0].(*ast.ReturnStmt); ok && retStmt.Value != nil {
				bodyExpr = retStmt.Value
			} else if exprStmt, ok := body.Statements[0].(*ast.ExpressionStmt); ok {
				bodyExpr = exprStmt.Expression
			}
		}
	case ast.Expression:
		bodyExpr = body
	}
	if bodyExpr == nil {
		return 0, 0, false
	}

	// Must be a binary expression
	binExpr, isBin := bodyExpr.(*ast.BinaryExpr)
	if !isBin {
		return 0, 0, false
	}

	// Check operator is a comparison
	op := binExpr.Operator
	switch op {
	case ">", "<", ">=", "<=", "==", "!=":
		// ok
	default:
		return 0, 0, false
	}

	// Determine which side is the param and which is the constant
	var numVal int64
	paramOnLeft := false

	if ident, ok := binExpr.Left.(*ast.Identifier); ok && ident.Name == paramName {
		if num, ok := binExpr.Right.(*ast.NumberLiteral); ok {
			paramOnLeft = true
			numVal = num.Value
		} else {
			return 0, 0, false
		}
	} else if ident, ok := binExpr.Right.(*ast.Identifier); ok && ident.Name == paramName {
		if num, ok := binExpr.Left.(*ast.NumberLiteral); ok {
			paramOnLeft = false
			numVal = num.Value
		} else {
			return 0, 0, false
		}
	} else {
		return 0, 0, false
	}

	// Normalize: if param is on the right, flip the operator
	// e.g., "5 > x" becomes "x < 5"
	if !paramOnLeft {
		switch op {
		case ">":
			op = "<"
		case "<":
			op = ">"
		case ">=":
			op = "<="
		case "<=":
			op = ">="
		// == and != are symmetric
		}
	}

	// Now we have: x OP numVal (param always on left)
	// Compute the inverted flag condition (jump when predicate is FALSE)
	// and adjust the constant for CP semantics.
	//
	// Z80 CP N: sets CY if A < N, sets Z if A == N
	//
	// | Predicate   | True when         | False when        | CP arg | Jump on false |
	// |-------------|-------------------|-------------------|--------|---------------|
	// | x > N       | A >= N+1          | A < N+1 (CY=1)   | N+1    | CY            |
	// | x >= N      | A >= N            | A < N (CY=1)     | N      | CY            |
	// | x < N       | A < N (CY=1)     | A >= N (CY=0)    | N      | NC            |
	// | x <= N      | A < N+1 (CY=1)  | A >= N+1 (CY=0)  | N+1    | NC            |
	// | x == N      | A == N (ZF=1)    | A != N (ZF=0)    | N      | NZ            |
	// | x != N      | A != N (ZF=0)   | A == N (ZF=1)    | N      | Z             |
	flagCond, constVal = invertedFlagForComparison(op, numVal)
	return flagCond, constVal, true
}

// invertedFlagForComparison returns the flag condition to jump on when
// the comparison "x OP N" is FALSE, and the adjusted constant for CP.
func invertedFlagForComparison(op string, numVal int64) (ir.FlagCondition, int64) {
	switch op {
	case ">":
		return ir.FlagCY, numVal + 1 // x > N → CP N+1, jump if CY (A < N+1)
	case ">=":
		return ir.FlagCY, numVal // x >= N → CP N, jump if CY (A < N)
	case "<":
		return ir.FlagNC, numVal // x < N → CP N, jump if NC (A >= N)
	case "<=":
		return ir.FlagNC, numVal + 1 // x <= N → CP N+1, jump if NC (A >= N+1)
	case "==":
		return ir.FlagNZ, numVal // x == N → CP N, jump if NZ (A != N)
	case "!=":
		return ir.FlagZ, numVal // x != N → CP N, jump if Z (A == N)
	default:
		return ir.FlagNZ, numVal // shouldn't happen
	}
}