// bridge.go — MIR2 → VIR conversion.
//
// Straightforward 1:1 translation of MIR2 instructions to VIROps.
// No pattern selection, no register assignment — just opcode mapping.
// The unified solver handles everything else.
package vir

import (
	"fmt"
	"strings"

	"github.com/minz/minzc/pkg/mir2"
)

func joinLines(lines []string) string { return strings.Join(lines, "\n") }

// LowerBlock converts one MIR2 basic block into VIROps.
// The optional func parameter enables return-value ABI enforcement.
func LowerBlock(b *mir2.Block, desc *MachineDesc, mod *mir2.Module, fn ...*mir2.Func) ([]VIROp, error) {
	var ops []VIROp

	// Pre-scan: collect MIR2 constants for strength reduction
	mirConsts := make(map[mir2.Reg]int64)
	for _, inst := range b.Insts {
		if inst.Op == mir2.OpConst {
			mirConsts[inst.Dst] = inst.Imm
		}
	}

	for _, inst := range b.Insts {
		if inst.Op == mir2.OpSDiv || inst.Op == mir2.OpSMod {
			return nil, fmt.Errorf("vir: unsupported %s in %s", inst.Op, b.Label)
		}
		// Strength reduce div/mod by power-of-2 BEFORE translation
		if (inst.Op == mir2.OpDiv || inst.Op == mir2.OpSDiv) && inst.Imm == 0 {
			if k, ok := mirConsts[inst.Src[1]]; ok && k > 0 && isPow2(k) {
				inst.Imm = k // propagate const into Imm for bridge
			}
		}
		if inst.Op == mir2.OpMod && inst.Imm == 0 {
			if k, ok := mirConsts[inst.Src[1]]; ok && k > 0 && isPow2(k) {
				inst.Imm = k
			}
		}
		// Propagate constant into inst.Imm for mul — enables:
		//   8-bit:  GPU table lookup in tryConstMul (currently NEVER fires without this!)
		//   16-bit: shift+add strength reduction in tryStrengthReduceMul16
		// Convention: Src[0]=variable, Src[1]=constant (swap if needed).
		if inst.Op == mir2.OpMul && inst.Imm == 0 {
			if k, ok := mirConsts[inst.Src[1]]; ok && k > 0 {
				inst.Imm = k
			} else if k, ok := mirConsts[inst.Src[0]]; ok && k > 0 {
				inst.Imm = k
				inst.Src[0], inst.Src[1] = inst.Src[1], inst.Src[0]
			}
		}
		// Propagate constant into inst.Imm for xor — enables 16-bit XorImm lowering
		// via tryXorImm16 (emits LD A,H / XOR $hi / LD H,A sequence instead of OpXor
		// which has no native 16-bit Z80 encoding and causes Z3 unsat → PBQP fallback).
		// Convention: Src[0]=variable operand, Src[1]=constant (swap if needed).
		if inst.Op == mir2.OpXor && inst.Imm == 0 {
			if k, ok := mirConsts[inst.Src[1]]; ok && k != 0 {
				inst.Imm = k
			} else if k, ok := mirConsts[inst.Src[0]]; ok && k != 0 {
				inst.Imm = k
				inst.Src[0], inst.Src[1] = inst.Src[1], inst.Src[0]
			}
		}

		translated, err := translateInst(inst, desc, mod)
		if err != nil {
			return nil, fmt.Errorf("block %s: %w", b.Label, err)
		}
		ops = append(ops, translated...)
	}

	// Fuse addr_of + store/load → direct global access
	ops = fuseGlobalAccess(ops)

	// Fold const + ALU → immediate ALU (enables INC/DEC patterns)
	ops = foldConstIntoALU(ops)

	// Fuse bit_get + cmp(eq/ne, 0) → flag-only bit_test
	ops = fuseBitTests(ops)

	// ISLE combining: identity elimination, dead const removal
	ops = ISLECombine(ops)

	// NOTE: Parameter register pinning (injectParamPins) is available but disabled.
	// It breaks more cases than it fixes because DstHint creates hard Z3 constraints
	// that conflict with tied ALU patterns. Needs softer approach (cost penalty, not hard).
	// See: abs_diff(b-a) case in verify_test.go.

	// Return-value ABI: if block ends with TermRet or TermCondRet,
	// move result to A (u8) or HL (u16) before the return.
	// Only if the result vreg isn't already guaranteed to be in A/HL
	// (e.g., from a tied ALU pattern like ADD A, r).
	if len(fn) > 0 {
		ops = appendReturnMove(ops, b, desc, fn[0])
	} else {
		ops = appendReturnMove(ops, b, desc)
	}

	// Dead const elimination — safe here because return move has been appended.
	// Terminator args (block arguments on outgoing edges) must be treated as
	// uses so their defining OpConst is not eliminated.  Without this, a
	// constant like `i = 0` that is only consumed as a TermJmp arg gets
	// removed and the loop header never receives its initial value.
	var termArgVRegs []int
	if b.Term != nil {
		switch t := b.Term.(type) {
		case *mir2.TermJmp:
			for _, a := range t.Args {
				termArgVRegs = append(termArgVRegs, int(a))
			}
		case *mir2.TermBrIf:
			for _, a := range t.ThenArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
			for _, a := range t.ElseArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
		case *mir2.TermBrIf2:
			for _, a := range t.EqArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
			for _, a := range t.LtArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
			for _, a := range t.GtArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
		case *mir2.TermDJNZ:
			for _, a := range t.BodyArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
			for _, a := range t.ExitArgs {
				termArgVRegs = append(termArgVRegs, int(a))
			}
		}
	}
	ops = EliminateDeadConsts(ops, termArgVRegs...)

	return ops, nil
}

// EliminateDeadConsts removes dead pure defs whose dst vreg is never used.
// extraUsed contains additional vreg IDs that should be considered live
// (e.g. terminator block-argument vregs that are not visible in VIR ops).
func EliminateDeadConsts(ops []VIROp, extraUsed ...int) []VIROp {
	used := make(map[int]bool)
	for _, op := range ops {
		for _, s := range op.Src {
			if s > 0 {
				used[s] = true
			}
		}
	}
	for _, v := range extraUsed {
		if v > 0 {
			used[v] = true
		}
	}
	var result []VIROp
	for _, op := range ops {
		if op.Dst > 0 && !used[op.Dst] {
			switch op.Op {
			case OpConst:
				if op.Sym == "" {
					continue
				}
			case OpBitGet:
				continue
			}
		}
		result = append(result, op)
	}
	return result
}

func fuseBitTests(ops []VIROp) []VIROp {
	uses := make(map[int]int)
	defIdx := make(map[int]int)
	for i, op := range ops {
		if op.Dst > 0 {
			defIdx[op.Dst] = i
		}
		for _, s := range op.Src {
			if s > 0 {
				uses[s]++
			}
		}
	}

	skip := make(map[int]bool)
	var result []VIROp
	for i, op := range ops {
		if skip[i] {
			continue
		}
		if op.Op == OpCmpImm && op.Imm == 0 && op.Src[0] > 0 {
			if di, ok := defIdx[op.Src[0]]; ok {
				def := ops[di]
				if def.Op == OpBitGet && uses[def.Dst] == 1 {
					result = append(result, VIROp{
						Op:    OpBitTest,
						Dst:   op.Dst,
						Src:   [2]int{def.Src[0], -1},
						Imm:   def.Imm,
						Width: def.Width,
					})
					skip[di] = true
					continue
				}
			}
		}
		result = append(result, op)
	}
	return result
}

// LowerFunc converts an entire MIR2 function into VIR blocks.
func LowerFunc(f *mir2.Func, desc *MachineDesc, mod *mir2.Module) (*Func, error) {
	vf := &Func{Name: f.Name, MIRFunc: f}

	for _, b := range f.Blocks {
		ops, err := LowerBlock(b, desc, mod, f)
		if err != nil {
			return nil, fmt.Errorf("func %s: %w", f.Name, err)
		}
		// Extract block parameter vreg IDs (PHI destinations)
		var params []int
		for _, p := range b.Params {
			params = append(params, int(p.Dst))
		}
		vf.Blocks = append(vf.Blocks, Block{
			Label:  b.Label,
			Ops:    ops,
			Params: params,
		})
	}

	return vf, nil
}

// mirWidth extracts bit width from a MIR2 instruction's Ty field.
func mirWidth(inst *mir2.Inst, desc *MachineDesc) int {
	w := 8
	if inst.Ty != nil {
		if tw := inst.Ty.Width(); tw > 0 {
			w = tw
		}
	}
	if w < 8 {
		w = 8
	}
	maxW := 16
	if desc.WordSize > maxW {
		maxW = desc.WordSize
	}
	if w > maxW {
		w = maxW
	}
	return w
}

// isPow2 returns true if n is a power of 2 (1, 2, 4, 8, ...).
func isPow2(n int64) bool {
	return n > 0 && (n&(n-1)) == 0
}

// log2 returns the base-2 logarithm of a power of 2.
func log2(n int64) int {
	r := 0
	for n > 1 {
		n >>= 1
		r++
	}
	return r
}

// translateInst maps a single MIR2 instruction to one or more VIROps.
func translateInst(inst *mir2.Inst, desc *MachineDesc, mod *mir2.Module) ([]VIROp, error) {
	w := mirWidth(inst, desc)

	switch inst.Op {
	case mir2.OpConst:
		return []VIROp{{
			Op: OpConst, Dst: int(inst.Dst), Imm: inst.Imm,
			Width: w, Sym: inst.Sym,
		}}, nil

	case mir2.OpMove:
		return []VIROp{{
			Op: OpMove, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
			Width: w,
		}}, nil

	case mir2.OpAdd:
		return []VIROp{{
			Op: OpAdd, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpSub:
		return []VIROp{{
			Op: OpSub, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpMul:
		return translateMul(inst, desc)

	case mir2.OpAnd:
		return []VIROp{{
			Op: OpAnd, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpOr:
		return []VIROp{{
			Op: OpOr, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpXor:
		// 16-bit XOR with immediate constant: no native Z80 opcode — lower to
		// two 8-bit XOR A,n instructions (LD A,H / XOR hi / LD H,A / LD A,L / XOR lo / LD L,A).
		// This runs before foldConstIntoALU so we check mirConsts directly.
		if w > 8 && inst.Imm != 0 {
			if ops := tryXorImm16(inst, desc); ops != nil {
				return ops, nil
			}
		}
		return []VIROp{{
			Op: OpXor, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpCmp:
		// CmpSubCarry: the carry flag was already set by the preceding SUB.
		// No CP instruction needed — the branch will use the existing flags.
		if inst.Cond == mir2.CmpSubCarry || inst.Cond == mir2.CmpSubCarryNot {
			return nil, nil // no-op: flags already set by SUB
		}
		return []VIROp{{
			Op: OpCmp, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpLoad:
		return []VIROp{{
			Op: OpLoad, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), -1}, Width: w,
		}}, nil

	case mir2.OpStore:
		return []VIROp{{
			Op: OpStore, Dst: -1,
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpCall, mir2.OpCallIndirect:
		return translateCall(inst, desc, mod)

	case mir2.OpShl:
		return []VIROp{{
			Op: OpShl, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpShr:
		return []VIROp{{
			Op: OpShr, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: w,
		}}, nil

	case mir2.OpNeg:
		return []VIROp{{
			Op: OpNeg, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), -1}, Width: w,
		}}, nil

	case mir2.OpBitGet:
		return []VIROp{{
			Op:      OpBitGet,
			Dst:     int(inst.Dst),
			Src:     [2]int{int(inst.Src[0]), -1},
			Imm:     inst.Imm,
			Width:   w,
			DstHint: desc.LocSetByNames("A"),
		}}, nil

	case mir2.OpBitSet:
		return []VIROp{{
			Op:    OpBitSet,
			Dst:   int(inst.Dst),
			Src:   [2]int{int(inst.Src[0]), -1},
			Imm:   inst.Imm,
			Width: w,
		}}, nil

	case mir2.OpBitReset:
		return []VIROp{{
			Op:    OpBitReset,
			Dst:   int(inst.Dst),
			Src:   [2]int{int(inst.Src[0]), -1},
			Imm:   inst.Imm,
			Width: w,
		}}, nil

	case mir2.OpNot:
		// Bitwise NOT: XOR A, 0xFF (complement)
		// Implemented as XOR with immediate 0xFF
		return []VIROp{{
			Op: OpXorImm, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
			Imm: 0xFF, Width: w,
		}}, nil

	case mir2.OpDiv, mir2.OpSDiv:
		// Power-of-2 division → shift right
		if inst.Imm > 0 && isPow2(inst.Imm) {
			shift := log2(inst.Imm)
			if w <= 8 {
				// u8 div-by-pow2: shift right by N bits.
				//
				// All cases use "LD A, {src0}" + shift sequence, result in A.
				// SrcHint EXCLUDES A: this ensures src0 stays in a non-A register
				// so that "LD A, {src0}" is a real copy and the source vreg is
				// preserved for any subsequent uses (e.g. sh is live after sh/128).
				// If src0 were allowed in A, RLCA/SRL would destroy it.
				//
				// shift=1: LD A, {src0} + SRL A  (12T)
				// shift=2-3: LD A, {src0} + N×SRL A  (4+8N T)
				// shift=4-7: LD A, {src0} + (8-N)×RLCA + AND mask  (much cheaper)
				//   RLCA rotates left: bit7→bit0; N left-rotates extracts bit(7) at bit(N-1).
				//   AND mask isolates the result (mask = 2^(8-shift)-1).
				//   e.g. shift=7: LD A,{src} + RLCA + AND 1 = 15T vs 4+56=60T for SRL chain.
				gpr8NoA := desc.LocSetByNames("B", "C", "D", "E", "H", "L")
				aSet := desc.LocSetByNames("A")
				var lines []string
				lines = append(lines, "LD A, {src0}")
				if shift >= 4 {
					rotates := 8 - shift
					mask := (1 << (8 - shift)) - 1
					for i := 0; i < rotates; i++ {
						lines = append(lines, "RLCA")
					}
					lines = append(lines, fmt.Sprintf("AND %d", mask))
				} else {
					for i := 0; i < shift; i++ {
						lines = append(lines, "SRL A")
					}
				}
				return []VIROp{{
					Op: OpAsmBlock, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
					AsmTemplate: strings.Join(lines, "\n    "),
					Clobbers:    desc.LocSetByNames("A", "F"),
					DstHint:     aSet,
					SrcHint:     [2]LocSet{gpr8NoA},
					Width:       8,
				}}, nil
			}
			// u16: for shift >= 8, the result fits in a single byte — use high-byte
			// extraction instead of SRL H; RR L chains.
			// div256 (shift=8): LD L, H / LD H, 0 (11T, 2 insts vs 64T, 16 insts)
			// div512 (shift=9): LD A, H / SRL A / LD L, A / LD H, 0 (17T vs 72T)
			hlSet := desc.LocSetByNames("HL")
			var asmLines []string
			if shift >= 8 {
				extraShift := shift - 8
				if extraShift == 0 {
					// div256: high byte → low byte, clear high
					asmLines = append(asmLines, "LD L, H", "LD H, 0")
				} else {
					// div512..div32768: extract high byte, shift right by (shift-8), clear high
					asmLines = append(asmLines, "LD A, H")
					for i := 0; i < extraShift; i++ {
						asmLines = append(asmLines, "SRL A")
					}
					asmLines = append(asmLines, "LD L, A", "LD H, 0")
				}
				return []VIROp{{
					Op: OpAsmBlock, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
					AsmTemplate: joinLines(asmLines),
					Clobbers:    desc.LocSetByNames("A", "H", "L", "HL", "F"),
					DstHint:     hlSet,
					SrcHint:     [2]LocSet{hlSet},
					Width:       16,
				}}, nil
			}
			// shift < 8: SRL H; RR L chain
			for i := 0; i < shift; i++ {
				asmLines = append(asmLines, "SRL H", "RR L")
			}
			return []VIROp{{
				Op: OpAsmBlock, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
				AsmTemplate: joinLines(asmLines),
				Clobbers:    desc.LocSetByNames("H", "L", "HL", "F"),
				DstHint:     hlSet,
				SrcHint:     [2]LocSet{hlSet},
				Width:       16,
			}}, nil
		}
		// Try GPU-optimal constant division (carry_compare for K≥128, etc.)
		if w <= 8 && inst.Imm > 0 {
			if ops := tryConstDiv(inst, desc, w); ops != nil {
				return ops, nil
			}
		}
		return translateDivMod(inst, desc, w, false)

	case mir2.OpMod:
		// Power-of-2 modulo → AND (K-1)
		if inst.Imm > 0 && isPow2(inst.Imm) {
			mask := inst.Imm - 1
			if w <= 8 {
				return []VIROp{{
					Op: OpAndImm, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
					Imm: mask, Width: 8,
				}}, nil
			}
			// u16: AND mask on low byte only (mask < 256 for power-of-2 ≤ 256)
			if mask < 256 {
				return []VIROp{{
					Op: OpAsmBlock, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
					Sym:   fmt.Sprintf("; mod%d (u16, strength reduced)\n    LD H, 0\n    LD A, L\n    AND %d\n    LD L, A", inst.Imm, mask),
					Width: 16,
				}}, nil
			}
			return []VIROp{{
				Op: OpAndImm, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
				Imm: mask, Width: w,
			}}, nil
		}
		// Try GPU-optimal constant mod (u8 only)
		if w <= 8 && inst.Imm > 0 {
			if ops := tryConstMod(inst, desc, w); ops != nil {
				return ops, nil
			}
		}
		return translateDivMod(inst, desc, w, true)

	case mir2.OpAddrOf:
		return []VIROp{{
			Op: OpConst, Dst: int(inst.Dst), Sym: inst.Sym, Width: 16,
		}}, nil

	case mir2.OpExt, mir2.OpTrunc:
		return []VIROp{{
			Op: OpMove, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
			Width: w,
		}}, nil

	case mir2.OpPtrAdd:
		// ptr_add base, offset → ADD HL, DE (16-bit pointer arithmetic)
		return []VIROp{{
			Op: OpAdd, Dst: int(inst.Dst),
			Src: [2]int{int(inst.Src[0]), int(inst.Src[1])}, Width: 16,
		}}, nil

	case mir2.OpField:
		// field base, imm=byte_offset → base + offset
		if inst.Imm == 0 {
			// Zero offset: just a copy
			return []VIROp{{
				Op: OpMove, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
				Width: 16,
			}}, nil
		}
		// Non-zero offset: add immediate
		return []VIROp{{
			Op: OpAddImm, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
			Imm: inst.Imm, Width: 16,
		}}, nil

	case mir2.OpPtrBump:
		// Same as OpField semantically
		if inst.Imm == 0 {
			return []VIROp{{
				Op: OpMove, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
				Width: 16,
			}}, nil
		}
		return []VIROp{{
			Op: OpAddImm, Dst: int(inst.Dst), Src: [2]int{int(inst.Src[0]), -1},
			Imm: inst.Imm, Width: 16,
		}}, nil

	case mir2.OpAlloca:
		// alloca N → SP adjustment, return pointer
		// For now, treat as const (frame address will be resolved later)
		return []VIROp{{
			Op: OpConst, Dst: int(inst.Dst), Imm: inst.Imm, Width: 16,
		}}, nil

	case mir2.OpAsm:
		return translateAsm(inst, desc)

	default:
		// Skip side-effect-free ops with no result
		if inst.Dst == mir2.NoReg {
			return nil, nil
		}
		return nil, fmt.Errorf("unsupported MIR2 op: %v", inst.Op)
	}
}

// translateMul converts OpMul to runtime call with proper arg setup.
// For 8-bit constant multipliers, checks the GPU-precomputed multiply table
// and emits inline shift/add sequences instead of CALL __mul8 (~80T).
// For 16-bit constant multipliers, emits shift+add inline asm (saves ~150T vs __mul16).
// __mul8: A × B → A.  __mul16: HL × DE → HL.
func translateMul(inst *mir2.Inst, desc *MachineDesc) ([]VIROp, error) {
	w := mirWidth(inst, desc)

	// Try constant multiply optimization (8-bit only, GPU table)
	if w <= 8 {
		if ops := tryConstMul(inst, desc, w); ops != nil {
			return ops, nil
		}
	}

	// 16-bit: strength reduce small constant multipliers (saves ~150T vs __mul16)
	if w > 8 && inst.Imm != 0 {
		if ops := tryStrengthReduceMul16(inst, desc); ops != nil {
			return ops, nil
		}
	}

	return translateRuntimeCall(inst, desc, w, true)
}

// tryStrengthReduceMul16 emits inline asm for 16-bit constant multiplication.
// Handles k=2..12 (common array indexing) and powers of 2 up to 256.
// All sequences assume input/output in HL. Returns nil if not applicable.
//
// T-state costs vs __mul16 (~200T):
//
//	×2:  11T (ADD HL,HL)
//	×3:  30T (copy+double+add)
//	×4:  22T (double twice)
//	×5:  41T
//	×6:  41T
//	×8:  33T (double thrice)
//	×10: 52T
//	×12: 52T
//	×16: 44T, ×32: 55T, ×64: 66T (powers of 2 via ADD HL,HL chain)
//
// tryXorImm16 lowers a 16-bit XOR with immediate constant to an OpAsmBlock.
// Z80 has no native 16-bit XOR; we emit two 8-bit XOR A,n sequences:
//
//	LD A, H / XOR hi / LD H, A / LD A, L / XOR lo / LD L, A  (28T, 6 insts)
//
// Special cases: hi=0 or lo=0 skip that byte (21T or 14T).
func tryXorImm16(inst *mir2.Inst, desc *MachineDesc) []VIROp {
	k := inst.Imm
	if k == 0 {
		return nil // XOR 0 = identity, eliminateIdentityOps handles it
	}
	hi := (k >> 8) & 0xFF
	lo := k & 0xFF

	var lines []string
	if hi != 0 {
		lines = append(lines, fmt.Sprintf("LD A, H\n    XOR $%02X\n    LD H, A", hi))
	}
	if lo != 0 {
		lines = append(lines, fmt.Sprintf("LD A, L\n    XOR $%02X\n    LD L, A", lo))
	}
	if len(lines) == 0 {
		return nil
	}

	asm := joinLines(lines)
	hlSet := desc.LocSetByNames("HL")
	clobbers := desc.LocSetByNames("A", "H", "L", "HL", "F")

	return []VIROp{{
		Op:          OpAsmBlock,
		Dst:         int(inst.Dst),
		Src:         [2]int{int(inst.Src[0]), -1},
		Width:       16,
		AsmTemplate: asm,
		Clobbers:    clobbers,
		DstHint:     hlSet,
		SrcHint:     [2]LocSet{hlSet},
	}}
}

func tryStrengthReduceMul16(inst *mir2.Inst, desc *MachineDesc) []VIROp {
	k := inst.Imm
	srcVreg := int(inst.Src[0])
	dstVreg := int(inst.Dst)

	hlSet := desc.LocSetByNames("HL")
	// Clobbers for ops that only use HL (no scratch)
	clobHL := desc.LocSetByNames("H", "L", "HL", "F")
	// Clobbers for ops that use BC as scratch
	clobHLBC := desc.LocSetByNames("B", "C", "BC", "H", "L", "HL", "F")
	// Clobbers for ops that use DE as scratch
	clobHLDE := desc.LocSetByNames("D", "E", "DE", "H", "L", "HL", "F")

	var asm string
	var clobbers LocSet

	switch k {
	case 256:
		// u8 × 256 → u16: place the byte in H, zero L.
		// "LD H, {src0}; LD L, 0" works when src0 is a GPR8 (A,B,C,D,E,H,L).
		// This is 8T/2B — 11× cheaper than 8× ADD HL,HL (88T).
		// SrcHint is GPR8 (not HL) so Z3 keeps the vreg in a byte register.
		gpr8 := desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L")
		clobHLonly := desc.LocSetByNames("H", "L", "HL")
		return []VIROp{{
			Op:          OpAsmBlock,
			Dst:         dstVreg,
			Src:         [2]int{srcVreg, -1},
			Width:       16,
			AsmTemplate: "LD H, {src0}\n    LD L, 0",
			Clobbers:    clobHLonly,
			DstHint:     hlSet,
			SrcHint:     [2]LocSet{gpr8},
		}}
	case 2:
		asm = "ADD HL, HL"
		clobbers = clobHL
	case 3:
		// BC=x, HL=x*2, HL=x*2+x=x*3
		asm = "LD B, H\n    LD C, L\n    ADD HL, HL\n    ADD HL, BC"
		clobbers = clobHLBC
	case 4:
		asm = "ADD HL, HL\n    ADD HL, HL"
		clobbers = clobHL
	case 5:
		// BC=x, HL=x*2, HL=x*4, HL=x*4+x=x*5
		asm = "LD B, H\n    LD C, L\n    ADD HL, HL\n    ADD HL, HL\n    ADD HL, BC"
		clobbers = clobHLBC
	case 6:
		// HL=x*2, DE=x*2, HL=x*4, HL=x*4+x*2=x*6
		asm = "ADD HL, HL\n    LD D, H\n    LD E, L\n    ADD HL, HL\n    ADD HL, DE"
		clobbers = clobHLDE
	case 8:
		asm = "ADD HL, HL\n    ADD HL, HL\n    ADD HL, HL"
		clobbers = clobHL
	case 10:
		// HL=x*2, BC=x*2, HL=x*4, HL=x*8, HL=x*8+x*2=x*10
		asm = "ADD HL, HL\n    LD B, H\n    LD C, L\n    ADD HL, HL\n    ADD HL, HL\n    ADD HL, BC"
		clobbers = clobHLBC
	case 12:
		// HL=x*2, HL=x*4, BC=x*4, HL=x*8, HL=x*8+x*4=x*12
		asm = "ADD HL, HL\n    ADD HL, HL\n    LD B, H\n    LD C, L\n    ADD HL, HL\n    ADD HL, BC"
		clobbers = clobHLBC
	default:
		// Powers of 2 via repeated ADD HL, HL (×16 through ×32768 = 2^4..2^15)
		// ADD HL, HL = 11T, so k×2048 (11 shifts) = 121T vs __mul16 ~380T
		if isPow2(k) && k >= 16 {
			shift := log2(k)
			var lines []string
			for i := 0; i < shift; i++ {
				lines = append(lines, "ADD HL, HL")
			}
			asm = joinLines(lines)
			clobbers = clobHL
		} else {
			return nil
		}
	}

	return []VIROp{{
		Op:          OpAsmBlock,
		Dst:         dstVreg,
		Src:         [2]int{srcVreg, -1},
		Width:       16,
		AsmTemplate: asm,
		Clobbers:    clobbers,
		DstHint:     hlSet,
		SrcHint:     [2]LocSet{hlSet},
	}}
}

// translateRuntimeCall emits arg setup moves + CALL for runtime routines.
// Runtime ABI:  8-bit: arg0→A, arg1→B, result→A
//
//	16-bit: arg0→HL, arg1→DE, result→HL
func translateRuntimeCall(inst *mir2.Inst, desc *MachineDesc, w int, isMul bool) ([]VIROp, error) {
	var ops []VIROp
	var sym string

	if isMul {
		if w <= 8 {
			sym = "__mul8"
		} else {
			sym = "__mul16"
		}
	} else {
		// div/mod determined by caller
		return nil, fmt.Errorf("use translateDiv/translateMod")
	}

	if w <= 8 {
		// 8-bit: arg0 → A, arg1 → B
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[0]) + 7000,
			Src: [2]int{int(inst.Src[0]), -1}, Width: 8,
			DstHint: desc.LocSetByNames("A"),
		})
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[1]) + 7100,
			Src: [2]int{int(inst.Src[1]), -1}, Width: 8,
			DstHint: desc.LocSetByNames("B"),
		})
	} else {
		// 16-bit: arg0 → HL, arg1 → DE
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[0]) + 7000,
			Src: [2]int{int(inst.Src[0]), -1}, Width: 16,
			DstHint: desc.LocSetByNames("HL"),
		})
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[1]) + 7100,
			Src: [2]int{int(inst.Src[1]), -1}, Width: 16,
			DstHint: desc.LocSetByNames("DE"),
		})
	}

	// Clobbers: all GPR + flags
	clobbers := desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L", "F")
	if desc.Name == "z80" {
		clobbers = clobbers.Or(desc.LocSetByNames("BC", "DE", "HL"))
	}

	// Return value hint
	var retHint LocSet
	if w <= 8 {
		retHint = desc.LocSetByNames("A")
	} else {
		retHint = desc.LocSetByNames("HL")
	}

	ops = append(ops, VIROp{
		Op: OpCall, Dst: int(inst.Dst),
		Src: [2]int{-1, -1}, Sym: sym, Width: w,
		Clobbers: clobbers, DstHint: retHint,
	})

	return ops, nil
}

// translateDivMod emits arg setup + CALL for __div8/__mod8/__div16/__mod16 runtime.
// 8-bit ABI: A=dividend, B=divisor → A=quotient (div) or A=remainder (mod).
// 16-bit ABI: HL=dividend, DE=divisor → HL=quotient (div) or HL=remainder (mod).
func translateDivMod(inst *mir2.Inst, desc *MachineDesc, w int, isMod bool) ([]VIROp, error) {
	var sym string
	if w <= 8 {
		sym = "__div8"
		if isMod {
			sym = "__mod8"
		}
	} else {
		sym = "__div16"
		if isMod {
			sym = "__mod16"
		}
	}

	var ops []VIROp

	if w <= 8 {
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[0]) + 7000,
			Src: [2]int{int(inst.Src[0]), -1}, Width: 8,
			DstHint: desc.LocSetByNames("A"),
		})
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[1]) + 7100,
			Src: [2]int{int(inst.Src[1]), -1}, Width: 8,
			DstHint: desc.LocSetByNames("B"),
		})
	} else {
		// 16-bit: arg0 → HL, arg1 → DE
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[0]) + 7000,
			Src: [2]int{int(inst.Src[0]), -1}, Width: 16,
			DstHint: desc.LocSetByNames("HL"),
		})
		ops = append(ops, VIROp{
			Op: OpMove, Dst: int(inst.Src[1]) + 7100,
			Src: [2]int{int(inst.Src[1]), -1}, Width: 16,
			DstHint: desc.LocSetByNames("DE"),
		})
	}

	clobbers := desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L", "F")
	if desc.Name == "z80" {
		clobbers = clobbers.Or(desc.LocSetByNames("BC", "DE", "HL"))
	}

	var retHint LocSet
	if w <= 8 {
		retHint = desc.LocSetByNames("A")
	} else {
		retHint = desc.LocSetByNames("HL")
	}

	ops = append(ops, VIROp{
		Op: OpCall, Dst: int(inst.Dst),
		Src: [2]int{-1, -1}, Sym: sym, Width: w,
		Clobbers: clobbers, DstHint: retHint,
	})

	return ops, nil
}

// translateCall converts OpCall to VIROps: arg setup moves + CALL + result move.
func translateCall(inst *mir2.Inst, desc *MachineDesc, mod *mir2.Module) ([]VIROp, error) {
	clobbers := desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L", "F")
	if desc.Name == "z80" {
		clobbers = clobbers.Or(desc.LocSetByNames("BC", "DE", "HL"))
	}

	var ops []VIROp

	// Emit argument setup moves: each arg vreg → register matching callee convention.
	// IMPORTANT: Use fresh vreg IDs (8000+i) for destinations to avoid collision
	// with the caller's vreg namespace. cp.Reg is the callee's vreg and may
	// collide with caller vregs, breaking liveness analysis in the solver.
	if mod != nil && inst.Sym != "" {
		callee := mod.FuncByName(inst.Sym)
		if callee != nil && len(callee.Contract.Params) > 0 {
			for i, argReg := range inst.Args {
				if i >= len(callee.Contract.Params) {
					break
				}
				cp := callee.Contract.Params[i]
				w := 8
				if cp.Ty != nil {
					if tw := cp.Ty.Width(); tw > 0 {
						w = tw
					}
				}
				if w < 8 {
					w = 8
				}
				// Move arg vreg to the callee's expected register.
				// DstHint from callee's contract class — ensures @z80_ pins
				// are respected (e.g., @z80_b → B, @z80_c → C).
				hint := regClassToLocSet(desc, cp.Class, w)
				// Use 8000 + argReg offset for unique dst vreg (same pattern as translateRuntimeCall).
				dstVReg := int(argReg) + 8000 + i*100
				ops = append(ops, VIROp{
					Op: OpMove, Dst: dstVReg,
					Src: [2]int{int(argReg), -1}, Width: w,
					DstHint: hint,
				})
			}
		}
	}

	// The CALL itself
	callOp := VIROp{
		Op:       OpCall,
		Dst:      int(inst.Dst),
		Src:      [2]int{-1, -1},
		Sym:      inst.Sym,
		Width:    mirWidth(inst, desc),
		Clobbers: clobbers,
	}
	// Return value hint: u8→A, u16→HL
	w := mirWidth(inst, desc)
	if inst.Dst != mir2.NoReg {
		if w <= 8 {
			callOp.DstHint = desc.LocSetByNames("A")
		} else {
			callOp.DstHint = desc.LocSetByNames("HL")
		}
	}
	// Flag materialization: if the callee returns ClassFlag, the result
	// is in the carry flag (F register). Immediately materialize to A
	// via SBC A,A (A = 0xFF if CY=1, 0x00 if CY=0). This prevents
	// Z3 from needing F as a general allocation location.
	if inst.Dst != mir2.NoReg && mod != nil && inst.Sym != "" {
		callee := mod.FuncByName(inst.Sym)
		if callee != nil && len(callee.Contract.Returns) > 0 &&
			callee.Contract.Returns[0].Class == mir2.ClassFlag {
			// Override: result goes to A (not F), via SBC A,A post-call
			callOp.DstHint = desc.LocSetByNames("A")
			ops = append(ops, callOp)
			// Insert SBC A,A to materialize carry → A
			ops = append(ops, VIROp{
				Op:          OpAsmBlock,
				Dst:         int(inst.Dst),
				Src:         [2]int{-1, -1},
				Width:       8,
				AsmTemplate: "SBC A, A",
				DstHint:     desc.LocSetByNames("A"),
				Clobbers:    desc.LocSetByNames("F"),
			})
			return ops, nil
		}
	}

	ops = append(ops, callOp)
	return ops, nil
}

// translateAsm converts MIR2 OpAsm to VIR OpAsmBlock.
// The asm template is emitted verbatim. Input vregs are pinned to their
// contract-assigned physical registers via SrcHint. The block clobbers
// all GPR conservatively (inline asm may touch anything).
func translateAsm(inst *mir2.Inst, desc *MachineDesc) ([]VIROp, error) {
	if inst.Asm == nil {
		return nil, nil
	}

	// Conservative clobbers: all GPR + flags
	clobbers := desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L", "F")
	if desc.Name == "z80" {
		clobbers = clobbers.Or(desc.LocSetByNames("BC", "DE", "HL"))
	}

	// Collect input vregs
	var asmIns []int
	for _, r := range inst.Asm.Ins {
		if r != mir2.NoReg {
			asmIns = append(asmIns, int(r))
		}
	}

	// Collect output vregs
	var asmOuts []int
	for _, r := range inst.Asm.Outs {
		if r != mir2.NoReg {
			asmOuts = append(asmOuts, int(r))
		}
	}

	// Build the VIROp
	op := VIROp{
		Op:          OpAsmBlock,
		Dst:         int(inst.Dst),
		Src:         [2]int{-1, -1},
		Width:       8,
		Clobbers:    clobbers,
		AsmTemplate: inst.Asm.Template,
		AsmIns:      asmIns,
		AsmOuts:     asmOuts,
	}

	// Pin first two inputs to Src slots for solver visibility
	if len(asmIns) > 0 {
		op.Src[0] = asmIns[0]
	}
	if len(asmIns) > 1 {
		op.Src[1] = asmIns[1]
	}

	// If there's a result, use the instruction's class for DstHint
	if inst.Dst != mir2.NoReg && inst.Cls != 0 {
		op.DstHint = regClassToLocSet(desc, inst.Cls, 8)
	}

	return []VIROp{op}, nil
}

// regClassToLocSet maps a MIR2 RegClass to a VIR LocSet.
func regClassToLocSet(desc *MachineDesc, cls mir2.RegClass, width int) LocSet {
	switch cls {
	case mir2.ClassAcc:
		if width <= 8 {
			return desc.LocSetByNames("A")
		}
		return desc.LocSetByNames("HL")
	case mir2.ClassCounter:
		return desc.LocSetByNames("B")
	case mir2.ClassRegC:
		return desc.LocSetByNames("C")
	case mir2.ClassRegD:
		return desc.LocSetByNames("D")
	case mir2.ClassRegE:
		return desc.LocSetByNames("E")
	case mir2.ClassRegH:
		return desc.LocSetByNames("H")
	case mir2.ClassRegL:
		return desc.LocSetByNames("L")
	case mir2.ClassPointer:
		return desc.LocSetByNames("HL")
	case mir2.ClassIndex:
		return desc.LocSetByNames("DE")
	case mir2.ClassGeneral:
		if width <= 8 {
			return desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L")
		}
		return desc.LocSetByNames("BC", "DE", "HL")
	case mir2.ClassPair:
		return desc.LocSetByNames("BC", "DE", "HL")
	case mir2.ClassFlag:
		return desc.LocSetByNames("F")
	default:
		if width <= 8 {
			return desc.LocSetByNames("A", "B", "C", "D", "E", "H", "L")
		}
		return desc.LocSetByNames("BC", "DE", "HL")
	}
}

// fuseGlobalAccess fuses addr_of + store/load into direct global ops.
func fuseGlobalAccess(ops []VIROp) []VIROp {
	if len(ops) < 2 {
		return ops
	}

	defMap := make(map[int]int)
	for i, op := range ops {
		if op.Dst >= 0 {
			defMap[op.Dst] = i
		}
	}

	var result []VIROp
	skip := make(map[int]bool)

	for i, op := range ops {
		if skip[i] {
			continue
		}

		if op.Op == OpStore && op.Src[0] >= 0 {
			if defIdx, ok := defMap[op.Src[0]]; ok {
				def := ops[defIdx]
				if def.Op == OpConst && def.Sym != "" {
					skip[defIdx] = true
					result = append(result, VIROp{
						Op: OpStoreGlobal, Dst: -1,
						Src: [2]int{op.Src[1], op.Src[1]},
						Imm: def.Imm, Sym: def.Sym, Width: op.Width,
					})
					continue
				}
			}
		}

		if op.Op == OpLoad && op.Src[0] >= 0 {
			if defIdx, ok := defMap[op.Src[0]]; ok {
				def := ops[defIdx]
				if def.Op == OpConst && def.Sym != "" {
					skip[defIdx] = true
					result = append(result, VIROp{
						Op: OpLoadGlobal, Dst: op.Dst,
						Src: [2]int{-1, -1},
						Imm: def.Imm, Sym: def.Sym, Width: op.Width,
					})
					continue
				}
			}
		}

		result = append(result, op)
	}

	return result
}

// injectParamPins emits identity moves at block entry for function parameter
// vregs that are used in this block but defined in the entry block (or as
// function params). The DstHint constrains each param to its ABI register.
//
// This tells the Z3 solver: "vreg v1 is in A, v2 is in B" at block entry.
// Without this, the solver treats cross-block vregs as unconstrained and
// may assign them to wrong registers (e.g., both to A via tied patterns).
func injectParamPins(ops []VIROp, b *mir2.Block, f *mir2.Func, desc *MachineDesc) []VIROp {
	if len(f.Contract.Params) == 0 {
		return ops
	}

	// Collect vregs used in this block's VIROps (as sources)
	usedInBlock := make(map[int]bool)
	for _, op := range ops {
		for _, s := range op.Src {
			if s > 0 {
				usedInBlock[s] = true
			}
		}
	}

	// For each function param used in this block but not defined here,
	// prepend a pin move: pinReg = move(paramReg) with DstHint = ABI register.
	// Then rewrite all VIROp uses of paramReg → pinReg.
	var pins []VIROp

	for _, cp := range f.Contract.Params {
		paramReg := int(cp.Reg)
		if !usedInBlock[paramReg] {
			continue
		}
		// Skip if vreg is defined in this block
		definedHere := false
		for _, op := range ops {
			if op.Dst == paramReg {
				definedHere = true
				break
			}
		}
		if definedHere {
			continue
		}

		w := 8
		if cp.Ty != nil {
			if tw := cp.Ty.Width(); tw > 0 {
				w = tw
			}
		}
		if w < 8 {
			w = 8
		}

		hint := regClassToLocSet(desc, cp.Class, w)
		if hint.IsEmpty() {
			continue
		}

		pinReg := 8800 + paramReg
		pins = append(pins, VIROp{
			Op: OpMove, Dst: pinReg, Src: [2]int{paramReg, -1},
			Width: w, DstHint: hint,
		})

		// Rewrite VIROp uses: paramReg → pinReg
		for i := range ops {
			for j, s := range ops[i].Src {
				if s == paramReg {
					ops[i].Src[j] = pinReg
				}
			}
		}
	}

	if len(pins) > 0 {
		return append(pins, ops...)
	}
	return ops
}

// foldConstIntoALU converts `const N; add(x, const_vreg)` → `addImm(x, N)`.
// This enables INC/DEC patterns (OpAddImm with imm=1, OpSubImm with imm=1).
func foldConstIntoALU(ops []VIROp) []VIROp {
	// Build const map: vreg → immediate value
	consts := make(map[int]int64)
	for _, op := range ops {
		if op.Op == OpConst && op.Dst > 0 && op.Sym == "" {
			consts[op.Dst] = op.Imm
		}
	}
	if len(consts) == 0 {
		return ops
	}

	// Map ALU op → immediate ALU op
	immOp := map[Op]Op{
		OpAdd: OpAddImm,
		OpSub: OpSubImm,
		OpAnd: OpAndImm,
		OpOr:  OpOrImm,
		OpXor: OpXorImm,
		OpCmp: OpCmpImm,
	}

	skip := make(map[int]bool) // const ops to remove
	var result []VIROp

	for i, op := range ops {
		if skip[i] {
			continue
		}

		newOp, ok := immOp[op.Op]
		if !ok {
			result = append(result, op)
			continue
		}

		// Check if src1 is a constant
		if op.Src[1] > 0 {
			if imm, isConst := consts[op.Src[1]]; isConst {
				// Fold: add(x, const_N) → addImm(x, N)
				result = append(result, VIROp{
					Op: newOp, Dst: op.Dst, Src: [2]int{op.Src[0], -1},
					Imm: imm, Width: op.Width,
					DstHint: op.DstHint, SrcHint: op.SrcHint,
				})
				// Mark the const op for removal (if single-use)
				for j, cop := range ops {
					if cop.Op == OpConst && cop.Dst == op.Src[1] {
						// Check if const is used elsewhere
						usedElsewhere := false
						for k, other := range ops {
							if k == i {
								continue
							}
							for _, s := range other.Src {
								if s == cop.Dst {
									usedElsewhere = true
								}
							}
						}
						if !usedElsewhere {
							skip[j] = true
						}
					}
				}
				continue
			}
		}

		// Check if src0 is a constant (for commutative ops)
		if op.Src[0] > 0 && (op.Op == OpAdd || op.Op == OpAnd || op.Op == OpOr || op.Op == OpXor) {
			if imm, isConst := consts[op.Src[0]]; isConst {
				result = append(result, VIROp{
					Op: newOp, Dst: op.Dst, Src: [2]int{op.Src[1], -1},
					Imm: imm, Width: op.Width,
					DstHint: op.DstHint, SrcHint: op.SrcHint,
				})
				for j, cop := range ops {
					if cop.Op == OpConst && cop.Dst == op.Src[0] {
						usedElsewhere := false
						for k, other := range ops {
							if k == i {
								continue
							}
							for _, s := range other.Src {
								if s == cop.Dst {
									usedElsewhere = true
								}
							}
						}
						if !usedElsewhere {
							skip[j] = true
						}
					}
				}
				continue
			}
		}

		result = append(result, op)
	}

	return result
}

// appendReturnMove adds an OpMove to place the return value in A (u8) or HL (u16)
// before a TermRet/TermCondRet. Uses a synthetic vreg (9900+) as the
// "return register" with DstHint constraining it to A or HL.
func appendReturnMove(ops []VIROp, b *mir2.Block, desc *MachineDesc, f ...*mir2.Func) []VIROp {
	term := b.Term
	var retVals []mir2.Reg

	switch t := term.(type) {
	case *mir2.TermRet:
		retVals = t.Vals
	case *mir2.TermCondRet:
		retVals = t.Vals
	default:
		return ops
	}

	if len(retVals) == 0 {
		return ops
	}

	retReg := int(retVals[0])
	if retReg <= 0 {
		return ops
	}

	// Determine width from the vreg's definition
	w := 8
	for i := len(ops) - 1; i >= 0; i-- {
		if ops[i].Dst == retReg && ops[i].Width > 0 {
			w = ops[i].Width
			break
		}
		// Also check if it's used as src (cross-block param)
		for _, s := range ops[i].Src {
			if s == retReg && ops[i].Width > 0 {
				w = ops[i].Width
				break
			}
		}
	}

	// Check if the result vreg is already defined by an op that constrains
	// it to A (8-bit ALU) or HL (16-bit ALU). If so, no move needed.
	alreadyConstrained := false

	// Check if result is a block param (function parameter already in correct register)
	for _, bp := range b.Params {
		if int(bp.Dst) == retReg {
			alreadyConstrained = true
			break
		}
	}
	// Check function-level contract params: only skip move if the param's
	// ABI register matches the return ABI register (A for u8, HL for u16).
	if len(f) > 0 && f[0] != nil {
		for _, cp := range f[0].Contract.Params {
			if int(cp.Reg) == retReg {
				if w <= 8 && cp.Class == mir2.ClassAcc {
					alreadyConstrained = true // param already in A = return register
				} else if w > 8 && cp.Class == mir2.ClassPointer {
					alreadyConstrained = true // param already in HL = return register
				}
				break
			}
		}
	}

	for _, op := range ops {
		if op.Dst == retReg {
			switch op.Op {
			case OpAdd, OpSub, OpAnd, OpOr, OpXor, OpNeg,
				OpAddImm, OpSubImm, OpAndImm, OpOrImm, OpXorImm:
				alreadyConstrained = true
			case OpMove:
				if !op.DstHint.IsEmpty() {
					alreadyConstrained = true
				}
			}
		}
	}

	if alreadyConstrained {
		return ops
	}

	// Synthetic vreg for the return-ABI move
	retABIReg := 9900 + retReg

	var retHint LocSet
	if w <= 8 {
		retHint = desc.LocSetByNames("A")
	} else {
		retHint = desc.LocSetByNames("HL")
	}

	// If the return vreg is a function param, set SrcHint to its PBQP-allocated
	// register (not just the class). The assert bootstrap loads args based on
	// PBQP allocation, so VIR must match.
	var srcHint LocSet
	if len(f) > 0 && f[0] != nil {
		for _, cp := range f[0].Contract.Params {
			if int(cp.Reg) == retReg {
				// Use PBQP allocation if available (exact register).
				// This is passed via a module-level allocResults map.
				// For now, fall through to class-based hint.
				// Fallback to class-based hint
				srcHint = regClassToLocSet(desc, cp.Class, w)
				break
			}
		}
	}

	ops = append(ops, VIROp{
		Op: OpMove, Dst: retABIReg, Src: [2]int{retReg, -1},
		Width: w, DstHint: retHint, SrcHint: [2]LocSet{srcHint},
	})

	return ops
}
