package ir

import (
	"fmt"
	"strings"
)

// Z80Register represents a physical Z80 register
type Z80Register uint32

// Z80 register definitions
const (
	// 8-bit registers
	Z80_A Z80Register = 1 << iota
	Z80_F
	Z80_B
	Z80_C
	Z80_D
	Z80_E
	Z80_H
	Z80_L
	
	// 16-bit register pairs
	Z80_AF
	Z80_BC
	Z80_DE
	Z80_HL
	Z80_IX
	Z80_IY
	Z80_SP
	
	// Shadow registers
	Z80_A_SHADOW
	Z80_F_SHADOW
	Z80_B_SHADOW
	Z80_C_SHADOW
	Z80_D_SHADOW
	Z80_E_SHADOW
	Z80_H_SHADOW
	Z80_L_SHADOW
	Z80_AF_SHADOW
	Z80_BC_SHADOW
	Z80_DE_SHADOW
	Z80_HL_SHADOW

	// Undocumented register halves (stable on all real Z80 NMOS/CMOS and clones).
	// IXH/IXL occupy the H/L slots within DD-prefixed instructions.
	// IYH/IYL occupy the H/L slots within FD-prefixed instructions.
	// NOT available on SM83 (Game Boy). Available everywhere else.
	Z80_IXH
	Z80_IXL
	Z80_IYH
	Z80_IYL
)

// RegisterSet tracks which Z80 registers are used
type RegisterSet uint32

// Add adds a register to the set
func (rs *RegisterSet) Add(reg Z80Register) {
	*rs |= RegisterSet(reg)
}

// Contains checks if a register is in the set
func (rs RegisterSet) Contains(reg Z80Register) bool {
	return rs&RegisterSet(reg) != 0
}

// Clear removes all registers from the set
func (rs *RegisterSet) Clear() {
	*rs = 0
}

// Count returns the number of registers in the set
func (rs RegisterSet) Count() int {
	count := 0
	for i := uint32(rs); i != 0; i &= i - 1 {
		count++
	}
	return count
}

// Opcode represents an IR operation
type Opcode uint8

const (
	// Control flow
	OpNop Opcode = iota
	OpLabel
	OpJump
	OpJumpIf
	OpJumpIfNot
	OpJumpIfZero
	OpJumpIfNotZero
	OpJumpIfFlag    // Jump based on CPU flag condition (CY/NC/Z/NZ) — used for inline filter predicates
	OpCall
	OpCallIndirect  // Indirect function call through register
	OpReturn
	
	// Data movement
	OpLoadConst
	OpLoadVar
	OpStoreVar
	OpLoadParam
	OpLoadField
	OpStoreField
	OpLoadIndex
	OpStoreIndex
	OpLoadElement    // Load array element
	OpStoreElement   // Store array element
	OpLoadBitField  // Load bit field value
	OpStoreBitField // Store bit field value
	OpMove
	OpLoadLabel  // Load address of a label
	OpLoadDirect // Load from direct memory address
	OpStoreDirect // Store to direct memory address
	
	// Self-modifying code operations
	OpSMCLoadConst
	OpSMCStoreConst
	OpSMCParam      // SMC parameter slot
	OpSMCSave       // Save SMC parameter to stack
	OpSMCRestore    // Restore SMC parameter from stack
	OpSMCUpdate     // Update SMC parameter value
	OpStoreTSMCRef  // Store to TSMC reference immediate
	
	// TRUE SMC operations (истинный SMC)
	OpTrueSMCLoad   // Load from anchor address
	OpTrueSMCPatch  // Patch anchor before call
	
	// TSMC Reference operations
	OpTSMCRefAnchor // Create anchor for TSMC reference parameter
	OpTSMCRefLoad   // Load from TSMC reference (immediate)
	OpTSMCRefPatch  // Patch TSMC reference at call site
	
	// Instruction Patching operations (Advanced TRUE SMC)
	OpPatchPoint    // Define patchable instruction sequence with templates
	OpPatchTemplate // Select template for patchable instruction sequence
	OpPatchTarget   // Set target address for store operations in patch
	OpPatchParam    // Patch function parameter immediate
	
	// Error handling (Carry-flag ABI)
	OpSetError      // Set carry flag and error code in A
	OpCheckError    // Check carry flag for error
	
	// Array operations
	OpArrayInit     // Initialize array  
	OpArrayElement  // Set array element during initialization
	OpArrayLiteral  // Array literal data block (optimized)
	
	// Arithmetic
	OpAdd
	OpSub
	OpMul
	OpDiv
	OpMod
	OpNeg
	OpInc
	OpDec
	
	// Bitwise
	OpAnd
	OpOr
	OpXor
	OpNot
	OpShl
	OpShr
	
	// Logical (short-circuit evaluation)
	OpLogicalAnd
	OpLogicalOr
	
	// Comparison
	OpCmp  // Generic comparison
	OpTest // Test register (sets flags without compare)
	OpEq
	OpNe
	OpLt
	OpGt
	OpLe
	OpGe
	
	// Memory
	OpAlloc
	OpFree
	OpLoadPtr
	OpStorePtr
	OpAddr     // Address-of operator (&)
	OpLoad     // Load from memory address (indirect)
	OpStore    // Store to memory address (indirect)
	
	// Stack
	OpPush
	OpPop
	
	// Inline assembly
	OpAsm
	
	// Loop operations
	OpLoadAddr       // Load address of variable/array
	OpCopyToBuffer   // Copy memory to static buffer
	OpCopyFromBuffer // Copy static buffer to memory
	OpDJNZ          // Decrement and jump if not zero
	OpLoadImm       // Load immediate value
	OpLoadReg       // Load register to register
	OpLoadMem       // Load from memory
	OpStoreMem      // Store to memory  
	OpAddImm        // Add immediate to register
	OpJmp           // Unconditional jump (alias for OpJump)
	OpJmpIf         // Jump if non-zero (alias for OpJumpIf)
	OpJmpIfNot      // Jump if zero (alias for OpJumpIfNot)
	OpPrintChar     // Print character
	OpHalt          // Halt execution
	
	// Built-in functions
	OpPrint         // Print a u8 character
	OpPrintU8       // Print u8 as decimal
	OpPrintU16      // Print u16 as decimal
	OpPrintI8       // Print i8 as decimal 
	OpPrintI16      // Print i16 as decimal
	OpPrintBool     // Print bool as "true"/"false"
	OpPrintString   // Print null-terminated string
	OpPrintStringDirect // Print short string directly (no loop)
	OpLoadString    // Load string literal address
	OpLen           // Get length of array/string
	OpMemcpy        // Copy memory block
	OpMemset        // Set memory block
	
	// Metaprogramming
	OpEmit          // @emit instruction for compile-time code generation
	
	// Cast interface operations (v0.11.0)
	// DEPRECATED: Not used - MinZ uses monomorphization for generics
	// and zero-cost interfaces (direct calls, no vtables)
	OpCastInterface     // Cast to interface (compile-time resolved) - UNUSED
	OpCheckCast         // Check cast conformance at compile-time - UNUSED
	OpMethodDispatch    // Static method dispatch to concrete implementation - UNUSED
	OpInterfaceCall     // Interface method call (resolved at compile-time) - UNUSED

	// I/O Port operations (v0.18.0) - for MZV platform abstraction
	OpPortIn            // r0 = port_in(port) - read from I/O port
	OpPortOut           // port_out(port, r0) - write to I/O port
	OpSyscall           // syscall(id, args...) - platform system call
)

// RegisterHint provides hints to the register allocator for optimal Z80 register usage
type RegisterHint uint8

const (
	RegHintNone RegisterHint = iota
	RegHintA                 // Prefer A register (accumulator, for arithmetic)
	RegHintB                 // Prefer B register (for DJNZ loops)
	RegHintC                 // Prefer C register
	RegHintD                 // Prefer D register
	RegHintE                 // Prefer E register
	RegHintH                 // Prefer H register
	RegHintL                 // Prefer L register
	RegHintHL                // Prefer HL register pair (for pointers)
	RegHintDE                // Prefer DE register pair
	RegHintBC                // Prefer BC register pair
	RegHintIXH               // Prefer IXH (undocumented high byte of IX)
	RegHintIXL               // Prefer IXL (undocumented low byte of IX)
	RegHintIYH               // Prefer IYH (undocumented high byte of IY)
	RegHintIYL               // Prefer IYL (undocumented low byte of IY)
)

// LocationKind specifies how a single parameter or return value is passed.
type LocationKind uint8

const (
	LK_PhysReg  LocationKind = iota // Standard register (A, B, HL, DE, ...)
	LK_Stack                        // Stack slot (PUSH/POP)
	LK_Flag                         // CPU flag (CF, ZF — for boolean returns)
	LK_SMCPatch                     // SMC immediate patch (loop-invariant constants)
)

// ConventionLocation describes where one parameter or return value lives.
type ConventionLocation struct {
	Kind        LocationKind
	Reg         Z80Register  // valid if Kind == LK_PhysReg
	Flag        FlagCondition // valid if Kind == LK_Flag (reuses CY/NC/Z/NZ — declared below)
	StackOffset int          // valid if Kind == LK_Stack
	Size        int          // 1 or 2 bytes
}

// FunctionContract is the typed calling convention for one function.
// nil = fall back to CallingConvention string (backward compatibility).
type FunctionContract struct {
	Params     []ConventionLocation // where each parameter arrives
	Returns    []ConventionLocation // where each return value goes
	Clobbers   RegisterSet          // registers destroyed by this function
	StackBytes int                  // total stack frame size
}

// FlagCondition represents a CPU flag condition for OpJumpIfFlag
type FlagCondition uint8

const (
	FlagCY FlagCondition = iota // Carry set (CF=1)
	FlagNC                      // Carry not set (CF=0)
	FlagZ                       // Zero set (ZF=1)
	FlagNZ                      // Zero not set (ZF=0)
)

// String returns the string representation of a FlagCondition
func (f FlagCondition) String() string {
	switch f {
	case FlagCY: return "CY"
	case FlagNC: return "NC"
	case FlagZ:  return "Z"
	case FlagNZ: return "NZ"
	default: return "??"
	}
}

// CodegenHints provides optimization hints from MIR analysis to code generator
// These hints allow the code generator to emit optimal instructions directly
// instead of relying on assembly-level peephole optimization.
// ADR: docs/297_MIR_Value_Tracking_ADR.md
type CodegenHints struct {
	// Value delta hints - detected when same register is loaded with related value
	CanUseINC    bool  // Value is previous + 1, can use INC instead of LD
	CanUseDEC    bool  // Value is previous - 1, can use DEC instead of LD
	CanEliminate bool  // Value unchanged, skip instruction entirely
	CanUseXOR    bool  // Value is 0, can use XOR A (only for A register)

	// Known value tracking
	IsConstant   bool  // Value is compile-time constant
	ConstValue   int64 // The constant value (valid if IsConstant)
	PrevValue    int64 // Previous value in register (for delta calculation)

	// Zero propagation
	IsZero       bool  // Result is known to be zero

	// Register preference (stronger than RegisterHint)
	MustUseA     bool  // Must use accumulator (e.g., for XOR A)

	// Flags awareness
	NextUsesFlags bool // Next instruction reads flags - don't use INC/DEC

	// DJNZ optimization
	BareDJNZ bool // B register is safe throughout loop — use bare DJNZ instead of manual DEC B + JR NZ
}

// StructLiteralData represents literal data for a struct in an array
type StructLiteralData struct {
	TypeName string           // Struct type name
	Fields   map[string]int64 // Field name -> literal value
}

// SMCAnnotation represents metadata for Self-Modifying Code
// Option B: Annotations carry SMC intent while instructions remain regular/executable
type SMCAnnotation struct {
	Kind    SMCAnnotationKind

	// For SMCCallSite
	Target  string  // Function being called
	Pattern string  // Usage pattern: "store_u8", "immediate", "reg_b", "reg_c"
	Dest    string  // Destination variable (for store patterns)

	// For SMCParam
	ParamName string
	Offset    int    // Byte offset in function prologue
	Size      int    // 1 or 2 bytes

	// For SMCReturn
	Mode    string  // "patchable" or "direct"
}

// SMCAnnotationKind identifies the type of SMC annotation
type SMCAnnotationKind int

const (
	SMCAnnotationNone     SMCAnnotationKind = iota
	SMCAnnotationCallSite                    // @smc_call(target, pattern, dest)
	SMCAnnotationParam                       // @smc_param(name, offset, size)
	SMCAnnotationReturn                      // @smc_return(mode)
)

// Instruction represents a single IR instruction
type Instruction struct {
	Op           Opcode
	Dest         Register
	Src1         Register
	Src2         Register
	Imm          int64
	Imm2         int64  // Second immediate for some operations
	Label        string
	Symbol       string
	Type         Type
	Comment      string
	PhysicalRegs map[string]string // Maps virtual to physical registers
	SMCLabel     string            // Label for self-modifying code location
	SMCTarget    string            // Target label for SMC store operations
	AsmCode      string            // Raw assembly code for OpAsm instructions
	AsmName      string            // Optional name for named asm blocks
	LiteralData  []int64           // Literal data values for OpArrayLiteral
	StructArrayData []StructLiteralData // Struct literal data for struct arrays
	
	// PGO Metadata (Quick Win #1)
	SourceLine   int    // Line number in original .minz file
	SourceFile   string // Source file path
	BasicBlockID int    // Which basic block this instruction belongs to
	ProfileHint  string // PGO hints: "hot", "cold", "likely", "unlikely"
	Args            []Register        // Argument registers for OpCall
	InlineArgValues []int64          // Constant values for inline parameters (u8, u16)
	InlineArgStrings []string        // String values for inline parameters (asciiz, cpmstr)
	InlineArgTypes  []string         // Types for inline parameters (u8, u16, asciiz, cpmstr)
	Hint            RegisterHint      // Hint for register allocator
	CodegenHint     *CodegenHints     // Hints from MIR optimizer for code generation

	// VM-specific fields
	Value        int              // Immediate value for OpLoadImm
	Target       int              // Jump target for OpJmp/OpJmpIf/OpJmpIfNot
	FuncName     string           // Function name for OpCall
	Offset       int              // Memory offset for OpLoadMem/OpStoreMem
	Size         int              // Data size for memory operations
	
	// Instruction Patching fields
	PatchPointLabel string       // Label of the patch point to modify
	TemplateName    string       // Template name for OpPatchTemplate
	TargetAddress   string       // Target address symbol for OpPatchTarget
	ParamName       string       // Parameter name for OpPatchParam
	
	// Metaprogramming fields
	StringValue     string       // String value for @emit
	StringID        int          // String pool ID for OpLoadString
	PatchPoint      *PatchPoint  // Patch point definition for OpPatchPoint

	// SMC Annotations (Option B: metadata instead of opcodes)
	// These carry SMC intent while keeping instruction executable by VM
	SMCAnnotations  []SMCAnnotation // Annotations attached to this instruction
}

// AsmBlock represents an inline assembly block
type AsmBlock struct {
	Name string
	Code string
}

// Register represents a virtual register
type Register int

const (
	// Special registers
	RegZero Register = -1 // Always zero
	RegSP   Register = -2 // Stack pointer
	RegFP   Register = -3 // Frame pointer
	RegRet  Register = -4 // Return value
)

// Type represents a type in the IR
type Type interface {
	Size() int // Size in bytes
	String() string
}

// BasicType represents primitive types
type BasicType struct {
	Kind TypeKind
}

type TypeKind int

const (
	TypeVoid TypeKind = iota
	TypeBool
	TypeU8
	TypeU16
	TypeU24
	TypeU32     // 32-bit unsigned (for intermediate calculations)
	TypeI8
	TypeI16
	TypeI24
	TypeI32     // 32-bit signed (for intermediate calculations)
	TypeF8_8    // Fixed point 8.8
	TypeF_8     // Fixed point .8 (pure fractional 8-bit)
	TypeF_16    // Fixed point .16 (pure fractional 16-bit)
	TypeF16_8   // Fixed point 16.8
	TypeF8_16   // Fixed point 8.16
)

func (t *BasicType) Size() int {
	switch t.Kind {
	case TypeVoid:
		return 0
	case TypeBool, TypeU8, TypeI8, TypeF_8:
		return 1
	case TypeU16, TypeI16, TypeF8_8, TypeF_16:
		return 2
	case TypeU24, TypeI24, TypeF16_8, TypeF8_16:
		return 3
	case TypeU32, TypeI32:
		return 4
	default:
		return 0
	}
}

func (t *BasicType) String() string {
	switch t.Kind {
	case TypeVoid:
		return "void"
	case TypeBool:
		return "bool"
	case TypeU8:
		return "u8"
	case TypeU16:
		return "u16"
	case TypeU24:
		return "u24"
	case TypeU32:
		return "u32"
	case TypeI8:
		return "i8"
	case TypeI16:
		return "i16"
	case TypeI24:
		return "i24"
	case TypeI32:
		return "i32"
	case TypeF8_8:
		return "f8.8"
	case TypeF_8:
		return "f.8"
	case TypeF_16:
		return "f.16"
	case TypeF16_8:
		return "f16.8"
	case TypeF8_16:
		return "f8.16"
	default:
		return "unknown"
	}
}

// PointerType represents pointer types
type PointerType struct {
	Base      Type
	IsMutable bool
}

func (t *PointerType) Size() int {
	return 2 // 16-bit pointers on Z80
}

func (t *PointerType) String() string {
	if t.IsMutable {
		return "*mut " + t.Base.String()
	}
	return "*" + t.Base.String()
}

// ArrayType represents array types
type ArrayType struct {
	Element Type
	Length  int
}

func (t *ArrayType) Size() int {
	return t.Element.Size() * t.Length
}

func (t *ArrayType) String() string {
	return fmt.Sprintf("[%d]%s", t.Length, t.Element.String())
}

// LambdaType represents function pointer types (lambda closures)
type LambdaType struct {
	ParamTypes []Type
	ReturnType Type
}

func (t *LambdaType) Size() int {
	return 2 // Function pointer is 16-bit on Z80
}

func (t *LambdaType) String() string {
	params := make([]string, len(t.ParamTypes))
	for i, p := range t.ParamTypes {
		params[i] = p.String()
	}
	return fmt.Sprintf("|%s| -> %s", strings.Join(params, ", "), t.ReturnType.String())
}

// StructType represents struct types
type StructType struct {
	Name       string
	Fields     map[string]Type
	FieldOrder []string // Preserves field order for layout
}

func (t *StructType) Size() int {
	size := 0
	for _, fieldName := range t.FieldOrder {
		size += t.Fields[fieldName].Size()
	}
	return size
}

func (t *StructType) String() string {
	return t.Name
}

// IteratorType represents iterator types for functional programming
type IteratorType struct {
	ElementType Type
}

func (t *IteratorType) Size() int {
	// Iterator is represented as a pointer to the data + state
	return 4 // Pointer (2 bytes) + counter/state (2 bytes)
}

func (t *IteratorType) String() string {
	return fmt.Sprintf("Iterator<%s>", t.ElementType.String())
}

// EnumType represents enum types
type EnumType struct {
	Name     string
	Variants map[string]int
}

func (t *EnumType) Size() int {
	// Enums are represented as u8 or u16 depending on variant count
	if len(t.Variants) <= 256 {
		return 1
	}
	return 2
}

func (t *EnumType) String() string {
	return t.Name
}

// StringType represents short strings (u8 length, max 255 chars)
type StringType struct {
	// String has structure: { len: u8, data: [u8] }
	// The size is dynamic, but we track the maximum possible size
	MaxLength int // Maximum length (usually 255)
}

func (t *StringType) Size() int {
	// Return the size for a pointer to string data
	// Actual string storage is variable-length
	return 2 // Pointer to string data
}

func (t *StringType) String() string {
	return "String"
}

// LStringType represents long strings (u16 length, max 65535 chars)
type LStringType struct {
	// LString has structure: { len: u16, data: [u8] }
	// The size is dynamic, but we track the maximum possible size
	MaxLength int // Maximum length (usually 65535)
}

func (t *LStringType) Size() int {
	// Return the size for a pointer to string data
	// Actual string storage is variable-length
	return 2 // Pointer to string data
}

func (t *LStringType) String() string {
	return "LString"
}

// BitStructType represents bit-struct types
type BitStructType struct {
	UnderlyingType Type               // u8 or u16
	Fields         map[string]*BitField
	FieldOrder     []string           // Preserve field declaration order
}

// FunctionType represents function types
type FunctionType struct {
	Params []Type
	Return Type
}

func (t *FunctionType) Size() int {
	return 2 // Function pointers are 16-bit addresses on Z80
}

func (t *FunctionType) String() string {
	params := []string{}
	for _, p := range t.Params {
		params = append(params, p.String())
	}
	return fmt.Sprintf("fun(%s) -> %s", strings.Join(params, ", "), t.Return.String())
}

// GenericType represents a type parameter (e.g., T in fn<T: Drawable>)
// This is a placeholder that gets replaced during monomorphization
type GenericType struct {
	Name   string   // The type parameter name (e.g., "T")
	Bounds []string // Interface bounds (e.g., ["Drawable"])
}

func (t *GenericType) Size() int {
	return 0 // Size unknown until monomorphized
}

func (t *GenericType) String() string {
	if len(t.Bounds) > 0 {
		return fmt.Sprintf("%s: %s", t.Name, strings.Join(t.Bounds, " + "))
	}
	return t.Name
}

func (t *BitStructType) Size() int {
	return t.UnderlyingType.Size()
}

func (t *BitStructType) String() string {
	return fmt.Sprintf("bits<%s>", t.UnderlyingType.String())
}

// BitField represents a field in a bit struct
type BitField struct {
	Name      string
	BitOffset int    // Starting bit position
	BitWidth  int    // Number of bits
}

// Function represents a function in IR
type Function struct {
	Name         string
	Params       []Parameter
	ReturnType   Type
	ErrorType    Type     // Optional error type for functions with ? syntax
	Locals       []Local
	Instructions []Instruction
	NextReg      Register
	NumParams    int
	IsInterrupt  bool
	NextRegister Register // Same as NextReg but more clearly named
	IsSMCEnabled bool     // Whether self-modifying code is enabled for this function
	IsRecursive  bool     // Whether this function is recursive
	SMCLocations map[string]int // Maps SMC labels to instruction indices
	IsSMCDefault     bool                    // Use SMC by default (true)
	SMCParamOffsets  map[string]int          // Parameter name -> SMC offset
	RequiresContext  bool                    // True for recursive functions
	HasTailRecursion bool                    // True if function has tail recursive calls
	
	// Register usage tracking for optimal prologue/epilogue
	UsedRegisters    RegisterSet // Which Z80 registers are actually used
	ModifiedRegisters RegisterSet // Which registers are modified (need saving)
	
	// TRUE SMC support
	UsesTrueSMC  bool                    // Uses TRUE SMC anchors (not fixed slots)
	SMCAnchors   map[string]*SMCAnchorInfo // Parameter -> anchor info
	
	// Instruction Patching support
	NeedsPatchPoints bool                 // Function will be called with instruction patching

	// SMC Annotations (Option B: function-level SMC metadata)
	SMCParamAnnotations []SMCAnnotation   // @smc_param annotations for each parameter
	SMCReturnAnnotation *SMCAnnotation    // @smc_return annotation if patchable return

	// Metadata for optimization passes
	Metadata map[string]string // Generic metadata storage
	CalleeSavedRegs  RegisterSet // Registers this function must preserve
	MaxStackDepth    int         // Maximum stack depth for this function
	CallingConvention string          // ABI calling convention ("smc", "register", "stack", etc.)
	Contract         *FunctionContract // Typed calling convention; nil = use CallingConvention string

	// Extern function support
	IsExtern         bool   // True if function is @extern (no body, external linkage)
	ExternAddress    uint16 // Address for @extern(0xC000), 0 if not specified
	HasExternAddress bool   // True if ExternAddress was explicitly set
	NoRST            bool     // True if @norst - force CALL even at RST addresses
	InlineParams     []string // Inline parameter types from @abi(inline: [u8, u16, asciiz])

	// eZ80 CPU mode support
	CPUMode          string // "adl", "z80", or "" (default to target)
	IsAsm            bool   // True if function is an asm fun (body is raw assembly)

	// Local function support
	ParentFunction string                  // Name of parent function (if this is a local function)
	CapturedVars   map[string]*CapturedVar // Variables captured from parent scope
}

// Parameter represents a function parameter
type Parameter struct {
	Name      string
	Type      Type
	Reg       Register
	TargetReg string // Explicit register mapping for extern: "A", "HL", "BC", "DE", etc.
	IsTSMCRef bool   // True if this should use TSMC reference passing
}

// Local represents a local variable
type Local struct {
	Name   string
	Type   Type
	Reg    Register
	Offset int          // Stack offset if spilled
	Hint   RegisterHint // Preferred physical register (attractor); RegHintNone = no preference
}

// CapturedVar represents a variable captured from a parent scope in a local function
type CapturedVar struct {
	Name         string    // Name of the captured variable
	Type         Type      // Type of the captured variable
	ParentReg    Register  // Register in parent function
	LocalReg     Register  // Register in local function
	CaptureMode  string    // "copy" or "reference"
}

// NewFunction creates a new IR function
func NewFunction(name string, returnType Type) *Function {
	return &Function{
		Name:            name,
		ReturnType:      returnType,
		NextReg:         1, // Start from 1, 0 is reserved
		NextRegister:    1, // Same as NextReg
		IsSMCDefault:    false, // ADR-0010: register-first is the default
		IsSMCEnabled:    false, // ADR-0010: SMC opt-in via @abi(smc)
		SMCParamOffsets: make(map[string]int),
	}
}

// AllocReg allocates a new virtual register
func (f *Function) AllocReg() Register {
	reg := f.NextReg
	f.NextReg++
	return reg
}

// LastAllocatedReg returns the last allocated register
func (f *Function) LastAllocatedReg() Register {
	return f.NextReg - 1
}

// AddParam adds a parameter to the function
func (f *Function) AddParam(name string, typ Type) Register {
	return f.AddParamWithRegister(name, typ, "")
}

// AddParamWithRegister adds a parameter with an explicit target register mapping
// The targetReg is used for extern functions to specify which CPU register the param is in
func (f *Function) AddParamWithRegister(name string, typ Type, targetReg string) Register {
	reg := f.AllocReg()

	// Check if this should be a TSMC reference parameter
	isTSMCRef := false
	if _, isPtr := typ.(*PointerType); isPtr && f.IsSMCEnabled {
		// Pointer parameters in SMC functions become TSMC references
		isTSMCRef = true
	}

	f.Params = append(f.Params, Parameter{
		Name:      name,
		Type:      typ,
		Reg:       reg,
		TargetReg: targetReg,
		IsTSMCRef: isTSMCRef,
	})
	f.NumParams++
	return reg
}

// AddLocal adds a local variable
func (f *Function) AddLocal(name string, typ Type) Register {
	reg := f.AllocReg()
	f.Locals = append(f.Locals, Local{
		Name: name,
		Type: typ,
		Reg:  reg,
	})
	return reg
}

// Emit adds an instruction to the function
func (f *Function) Emit(op Opcode, dest, src1, src2 Register) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:   op,
		Dest: dest,
		Src1: src1,
		Src2: src2,
	})
}

// EmitTyped adds an instruction with type information
func (f *Function) EmitTyped(op Opcode, dest, src1, src2 Register, typ Type) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:   op,
		Dest: dest,
		Src1: src1,
		Src2: src2,
		Type: typ,
	})
}

// EmitImm adds an instruction with immediate value
func (f *Function) EmitImm(op Opcode, dest Register, imm int64) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:   op,
		Dest: dest,
		Imm:  imm,
	})
}

// EmitLabel adds a label instruction
func (f *Function) EmitLabel(label string) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:    OpLabel,
		Label: label,
	})
}

// EmitJump adds a jump instruction
func (f *Function) EmitJump(label string) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:    OpJump,
		Label: label,
	})
}

// EmitJumpIf adds a conditional jump instruction
func (f *Function) EmitJumpIf(cond Register, label string) {
	f.Instructions = append(f.Instructions, Instruction{
		Op:    OpJumpIf,
		Src1:  cond,
		Label: label,
	})
}

// Module represents a collection of functions
type Module struct {
	Name      string
	Functions []*Function
	Globals   []Global
	Strings   []*String
	PatchTable []PatchEntry // TRUE SMC patch table
}

// Global represents a global variable
type Global struct {
	Name     string
	Type     Type
	Init     interface{} // Initial value
	Value    interface{} // AST expression for constants
	Constant bool        // Whether this is a constant
}

// ConstExpr represents a constant expression for initialization
type ConstExpr struct {
	Value int
}

// String represents a string literal
type String struct {
	Label  string
	Value  string
	IsLong bool // true for LString (u16 length), false for String (u8 length)
}

// NewModule creates a new IR module
func NewModule(name string) *Module {
	return &Module{
		Name: name,
	}
}

// AddFunction adds a function to the module
func (m *Module) AddFunction(f *Function) {
	m.Functions = append(m.Functions, f)
}

// AddGlobal adds a global variable
func (m *Module) AddGlobal(name string, typ Type, init interface{}) {
	m.Globals = append(m.Globals, Global{
		Name: name,
		Type: typ,
		Init: init,
	})
}

// String representation for debugging
func (i *Instruction) String() string {
	switch i.Op {
	case OpNop:
		return "nop"
	case OpLabel:
		return i.Label + ":"
	case OpJump:
		return fmt.Sprintf("jump %s", i.Label)
	case OpJumpIf:
		return fmt.Sprintf("jump_if r%d, %s", i.Src1, i.Label)
	case OpJumpIfNot:
		return fmt.Sprintf("jump_if_not r%d, %s", i.Src1, i.Label)
	case OpCall:
		if len(i.Args) > 0 {
			args := make([]string, len(i.Args))
			for j, arg := range i.Args {
				args[j] = fmt.Sprintf("r%d", arg)
			}
			return fmt.Sprintf("r%d = call %s(%s)", i.Dest, i.Symbol, strings.Join(args, ", "))
		}
		return fmt.Sprintf("r%d = call %s", i.Dest, i.Symbol)
	case OpCallIndirect:
		return fmt.Sprintf("r%d = call_indirect r%d", i.Dest, i.Src1)
	case OpReturn:
		if i.Src1 != 0 {
			return fmt.Sprintf("return r%d", i.Src1)
		}
		return "return"
	case OpLoadConst:
		return fmt.Sprintf("r%d = %d", i.Dest, i.Imm)
	case OpLoadVar:
		return fmt.Sprintf("r%d = load %s", i.Dest, i.Symbol)
	case OpStoreVar:
		return fmt.Sprintf("store %s, r%d", i.Symbol, i.Src1)
	case OpStoreTSMCRef:
		return fmt.Sprintf("store_tsmc_ref %s, r%d", i.Symbol, i.Src1)
	case OpLoadParam:
		return fmt.Sprintf("r%d = param %s", i.Dest, i.Symbol)
	case OpAdd:
		return fmt.Sprintf("r%d = r%d + r%d", i.Dest, i.Src1, i.Src2)
	case OpSub:
		return fmt.Sprintf("r%d = r%d - r%d", i.Dest, i.Src1, i.Src2)
	case OpMul:
		return fmt.Sprintf("r%d = r%d * r%d", i.Dest, i.Src1, i.Src2)
	case OpDiv:
		return fmt.Sprintf("r%d = r%d / r%d", i.Dest, i.Src1, i.Src2)
	case OpEq:
		return fmt.Sprintf("r%d = r%d == r%d", i.Dest, i.Src1, i.Src2)
	case OpNe:
		return fmt.Sprintf("r%d = r%d != r%d", i.Dest, i.Src1, i.Src2)
	case OpLt:
		return fmt.Sprintf("r%d = r%d < r%d", i.Dest, i.Src1, i.Src2)
	case OpGt:
		return fmt.Sprintf("r%d = r%d > r%d", i.Dest, i.Src1, i.Src2)
	case OpLe:
		return fmt.Sprintf("r%d = r%d <= r%d", i.Dest, i.Src1, i.Src2)
	case OpGe:
		return fmt.Sprintf("r%d = r%d >= r%d", i.Dest, i.Src1, i.Src2)
	case OpAsm:
		if i.AsmName != "" {
			return fmt.Sprintf("asm %s { %s }", i.AsmName, i.AsmCode)
		}
		return fmt.Sprintf("asm { %s }", i.AsmCode)
	case OpLoadAddr:
		return fmt.Sprintf("r%d = addr(%s)", i.Dest, i.Symbol)
	case OpCopyToBuffer:
		return fmt.Sprintf("copy [r%d] to buffer@%d size=%d", i.Src1, i.Imm, i.Imm2)
	case OpCopyFromBuffer:
		return fmt.Sprintf("copy buffer@%d to [r%d] size=%d", i.Imm, i.Dest, i.Imm2)
	case OpDJNZ:
		return fmt.Sprintf("djnz r%d, %s", i.Src1, i.Label)
	case OpLoadImm:
		return fmt.Sprintf("r%d = %d", i.Dest, i.Imm)
	case OpAddImm:
		return fmt.Sprintf("r%d = r%d + %d", i.Dest, i.Src1, i.Imm)
	case OpCmp:
		return fmt.Sprintf("cmp r%d, r%d", i.Src1, i.Src2)
	case OpLoadDirect:
		return fmt.Sprintf("r%d = [$%04X]", i.Dest, i.Imm)
	case OpStoreDirect:
		return fmt.Sprintf("[$%04X] = r%d", i.Imm, i.Src1)
	case OpLoad:
		return fmt.Sprintf("r%d = *r%d", i.Dest, i.Src1)
	case OpStore:
		return fmt.Sprintf("*r%d = r%d", i.Src1, i.Src2)
	case OpMod:
		return fmt.Sprintf("r%d = r%d %% r%d", i.Dest, i.Src1, i.Src2)
	case OpNeg:
		return fmt.Sprintf("r%d = -r%d", i.Dest, i.Src1)
	case OpInc:
		return fmt.Sprintf("r%d++", i.Src1)
	case OpDec:
		return fmt.Sprintf("r%d--", i.Src1)
	case OpAnd:
		return fmt.Sprintf("r%d = r%d & r%d", i.Dest, i.Src1, i.Src2)
	case OpOr:
		return fmt.Sprintf("r%d = r%d | r%d", i.Dest, i.Src1, i.Src2)
	case OpXor:
		return fmt.Sprintf("r%d = r%d ^ r%d", i.Dest, i.Src1, i.Src2)
	case OpNot:
		return fmt.Sprintf("r%d = ~r%d", i.Dest, i.Src1)
	case OpShl:
		return fmt.Sprintf("r%d = r%d << r%d", i.Dest, i.Src1, i.Src2)
	case OpShr:
		return fmt.Sprintf("r%d = r%d >> r%d", i.Dest, i.Src1, i.Src2)
	case OpPrint:
		return fmt.Sprintf("print(r%d)", i.Src1)
	case OpPrintU8:
		return fmt.Sprintf("print_u8(r%d)", i.Src1)
	case OpPrintU16:
		return fmt.Sprintf("print_u16(r%d)", i.Src1)
	case OpPrintI8:
		return fmt.Sprintf("print_i8(r%d)", i.Src1)
	case OpPrintI16:
		return fmt.Sprintf("print_i16(r%d)", i.Src1)
	case OpPrintBool:
		return fmt.Sprintf("print_bool(r%d)", i.Src1)
	case OpPrintString:
		return fmt.Sprintf("print_string(r%d)", i.Src1)
	case OpPrintStringDirect:
		return fmt.Sprintf("print_direct(\"%s\")", i.Symbol)
	case OpLoadString:
		return fmt.Sprintf("r%d = string(%s)", i.Dest, i.Symbol)
	case OpLen:
		return fmt.Sprintf("r%d = len(r%d)", i.Dest, i.Src1)
	case OpMemcpy:
		return fmt.Sprintf("memcpy([r%d], [r%d], r%d)", i.Dest, i.Src1, i.Src2)
	case OpMemset:
		return fmt.Sprintf("memset([r%d], r%d, r%d)", i.Dest, i.Src1, i.Src2)
	case OpLoadField:
		return fmt.Sprintf("r%d = r%d.field[%d]", i.Dest, i.Src1, i.Imm)
	case OpStoreField:
		return fmt.Sprintf("r%d.field[%d] = r%d", i.Src1, i.Imm, i.Src2)
	case OpAddr:
		return fmt.Sprintf("r%d = &r%d", i.Dest, i.Src1)
	case OpLoadLabel:
		return fmt.Sprintf("r%d = label %s", i.Dest, i.Symbol)
	case OpMove:
		return fmt.Sprintf("r%d = r%d", i.Dest, i.Src1)
	case OpTest:
		return fmt.Sprintf("test r%d", i.Src1)
	case OpLogicalAnd:
		return fmt.Sprintf("r%d = r%d && r%d", i.Dest, i.Src1, i.Src2)
	case OpLogicalOr:
		return fmt.Sprintf("r%d = r%d || r%d", i.Dest, i.Src1, i.Src2)
	case OpLoadIndex:
		return fmt.Sprintf("r%d = r%d[r%d]", i.Dest, i.Src1, i.Src2)
	case OpStoreIndex:
		return fmt.Sprintf("r%d[r%d] = r%d", i.Src1, i.Src2, i.Dest)
	case OpLoadElement:
		return fmt.Sprintf("r%d = r%d[%d]", i.Dest, i.Src1, i.Imm)
	case OpStoreElement:
		return fmt.Sprintf("r%d[%d] = r%d", i.Src1, i.Imm, i.Src2)
	case OpLoadPtr:
		return fmt.Sprintf("r%d = *r%d", i.Dest, i.Src1)
	case OpStorePtr:
		return fmt.Sprintf("*r%d = r%d", i.Dest, i.Src1)
	case OpAlloc:
		return fmt.Sprintf("r%d = alloc(%d)", i.Dest, i.Imm)
	case OpFree:
		return fmt.Sprintf("free(r%d)", i.Src1)
	case OpPush:
		return fmt.Sprintf("push r%d", i.Src1)
	case OpPop:
		return fmt.Sprintf("r%d = pop", i.Dest)
	case OpPatchPoint:
		return fmt.Sprintf("patch_point %s", i.PatchPointLabel)
	case OpPatchTemplate:
		return fmt.Sprintf("patch_template %s", i.TemplateName)
	case OpPatchTarget:
		return fmt.Sprintf("patch_target %s", i.TargetAddress)
	case OpPatchParam:
		return fmt.Sprintf("patch_param %s", i.ParamName)
	case OpArrayInit:
		return fmt.Sprintf("r%d = array_init(%d)", i.Dest, i.Imm)
	case OpArrayElement:
		return fmt.Sprintf("r%d[%d] = %d", i.Dest, i.Imm, i.Imm2)
	case OpArrayLiteral:
		return fmt.Sprintf("r%d = array_literal", i.Dest)
	case OpLoadBitField:
		return fmt.Sprintf("r%d = r%d.bits[%d:%d]", i.Dest, i.Src1, i.Imm, i.Imm2)
	case OpStoreBitField:
		return fmt.Sprintf("r%d.bits[%d:%d] = r%d", i.Dest, i.Imm, i.Imm2, i.Src1)
	case OpSetError:
		return fmt.Sprintf("set_error r%d", i.Src1)
	case OpCheckError:
		return fmt.Sprintf("r%d = check_error", i.Dest)
	case OpSyscall:
		return fmt.Sprintf("syscall %d (r%d, r%d)", i.Imm, i.Src1, i.Src2)
	case OpPortIn:
		return fmt.Sprintf("r%d = port_in(r%d)", i.Dest, i.Src1)
	case OpPortOut:
		return fmt.Sprintf("port_out(r%d, r%d)", i.Src1, i.Src2)
	case OpTrueSMCLoad:
		if i.Symbol != "" {
			return fmt.Sprintf("r%d = smc_load %s", i.Dest, i.Symbol)
		}
		return fmt.Sprintf("r%d = smc_load r%d", i.Dest, i.Src1)
	case OpTrueSMCPatch:
		return fmt.Sprintf("smc_patch %s = r%d", i.Symbol, i.Src1)
	case OpTSMCRefAnchor:
		return fmt.Sprintf("tsmc_anchor %s", i.Symbol)
	case OpTSMCRefLoad:
		return fmt.Sprintf("r%d = tsmc_ref_load %s", i.Dest, i.Symbol)
	case OpTSMCRefPatch:
		return fmt.Sprintf("tsmc_ref_patch %s = r%d", i.Symbol, i.Src1)
	case OpSMCLoadConst:
		return fmt.Sprintf("r%d = smc_const %d", i.Dest, i.Imm)
	case OpSMCStoreConst:
		return fmt.Sprintf("smc_store_const %s = %d", i.Symbol, i.Imm)
	case OpSMCParam:
		return fmt.Sprintf("smc_param %s", i.Symbol)
	case OpSMCSave:
		return fmt.Sprintf("smc_save %s", i.Symbol)
	case OpSMCRestore:
		return fmt.Sprintf("smc_restore %s", i.Symbol)
	case OpSMCUpdate:
		return fmt.Sprintf("smc_update %s = r%d", i.Symbol, i.Src1)
	default:
		return fmt.Sprintf("unknown op %d", i.Op)
	}
}

// StringWithAnnotations returns the instruction string with any SMC annotations
func (i *Instruction) StringWithAnnotations() string {
	var parts []string

	// Add annotations first (on separate lines for readability)
	for _, ann := range i.SMCAnnotations {
		parts = append(parts, ann.String())
	}

	// Add the instruction itself
	parts = append(parts, i.String())

	return strings.Join(parts, "\n")
}

// String returns the string representation of an SMC annotation
func (a *SMCAnnotation) String() string {
	switch a.Kind {
	case SMCAnnotationCallSite:
		if a.Dest != "" {
			return fmt.Sprintf("@smc_call(target=%s, pattern=%s, dest=%s)", a.Target, a.Pattern, a.Dest)
		}
		return fmt.Sprintf("@smc_call(target=%s, pattern=%s)", a.Target, a.Pattern)
	case SMCAnnotationParam:
		return fmt.Sprintf("@smc_param(%s, offset=%d, size=%d)", a.ParamName, a.Offset, a.Size)
	case SMCAnnotationReturn:
		return fmt.Sprintf("@smc_return(mode=%s)", a.Mode)
	default:
		return ""
	}
}

// AddSMCCallSiteAnnotation adds an SMC call site annotation to the instruction
func (i *Instruction) AddSMCCallSiteAnnotation(target, pattern, dest string) {
	i.SMCAnnotations = append(i.SMCAnnotations, SMCAnnotation{
		Kind:    SMCAnnotationCallSite,
		Target:  target,
		Pattern: pattern,
		Dest:    dest,
	})
}

// AddSMCParamAnnotation adds an SMC param annotation to the instruction
func (i *Instruction) AddSMCParamAnnotation(paramName string, offset, size int) {
	i.SMCAnnotations = append(i.SMCAnnotations, SMCAnnotation{
		Kind:      SMCAnnotationParam,
		ParamName: paramName,
		Offset:    offset,
		Size:      size,
	})
}

// HasSMCAnnotations returns true if the instruction has SMC annotations
func (i *Instruction) HasSMCAnnotations() bool {
	return len(i.SMCAnnotations) > 0
}

// GetSMCCallSite returns the SMC call site annotation if present
func (i *Instruction) GetSMCCallSite() *SMCAnnotation {
	for idx := range i.SMCAnnotations {
		if i.SMCAnnotations[idx].Kind == SMCAnnotationCallSite {
			return &i.SMCAnnotations[idx]
		}
	}
	return nil
}

// SetMetadata sets a metadata value for the function
func (f *Function) SetMetadata(key, value string) {
	if f.Metadata == nil {
		f.Metadata = make(map[string]string)
	}
	f.Metadata[key] = value
}

// GetMetadata retrieves a metadata value for the function
func (f *Function) GetMetadata(key string) (string, bool) {
	if f.Metadata == nil {
		return "", false
	}
	value, ok := f.Metadata[key]
	return value, ok
}

// SMCAnchorInfo represents information about a TRUE SMC anchor
type SMCAnchorInfo struct {
	Symbol      string    // Anchor symbol (e.g., "x_imm0")
	Address     uint16    // Address in generated code
	Size        uint8     // 1 or 2 bytes
	Instruction Opcode    // The instruction containing the immediate
}

// PatchEntry represents an entry in the PATCH-TABLE
type PatchEntry struct {
	Symbol   string    // Anchor symbol (e.g., "x_imm0")
	Address  uint16    // Address to patch
	Size     uint8     // 1 or 2 bytes
	Bank     uint8     // Memory bank
	ParamTag string    // Parameter name
	Function string    // Function name
}

// PatchTemplate represents a template for instruction patching
type PatchTemplate struct {
	Name         string   // Template name (e.g., "immediate", "store_u8")
	Instructions []byte   // Bytes to patch (opcodes + operands)
	Size         int      // Template size in bytes
	Description  string   // Human-readable description
}

// PatchPoint represents a patchable instruction sequence
type PatchPoint struct {
	Label     string                    // Patch point label
	Size      int                       // Reserved space for patches
	Templates map[string]*PatchTemplate // Available templates
	Default   string                    // Default template name
}

// CreateReturnPatchPoint creates a standard return sequence patch point
func CreateReturnPatchPoint(label string) *PatchPoint {
	return &PatchPoint{
		Label: label,
		Size:  6, // Reserve 6 bytes for largest template
		Templates: map[string]*PatchTemplate{
			"immediate": {
				Name:         "immediate",
				Instructions: []byte{0xC9}, // RET
				Size:         1,
				Description:  "Early return with result in A register",
			},
			"store_u8": {
				Name:         "store_u8",
				Instructions: []byte{0x32, 0x00, 0x00, 0xC9}, // LD (addr), A; RET
				Size:         4,
				Description:  "Store u8 result to memory and return",
			},
			"store_u16": {
				Name:         "store_u16", 
				Instructions: []byte{0x22, 0x00, 0x00, 0xC9}, // LD (addr), HL; RET
				Size:         4,
				Description:  "Store u16 result to memory and return",
			},
			"reg_b": {
				Name:         "reg_b",
				Instructions: []byte{0x47, 0xC9}, // LD B, A; RET
				Size:         2,
				Description:  "Move result to B register and return",
			},
			"reg_c": {
				Name:         "reg_c",
				Instructions: []byte{0x4F, 0xC9}, // LD C, A; RET
				Size:         2,
				Description:  "Move result to C register and return",
			},
		},
		Default: "store_u8", // Most common pattern
	}
}

// String returns the string representation of an Opcode
func (op Opcode) String() string {
	switch op {
	case OpNop: return "NOP"
	case OpLabel: return "LABEL"
	case OpJump: return "JUMP"
	case OpJumpIf: return "JUMP_IF"
	case OpJumpIfNot: return "JUMP_IF_NOT"
	case OpJumpIfZero: return "JUMP_IF_ZERO"
	case OpJumpIfNotZero: return "JUMP_IF_NOT_ZERO"
	case OpJumpIfFlag: return "JUMP_IF_FLAG"
	case OpCall: return "CALL"
	case OpCallIndirect: return "CALL_INDIRECT"
	case OpReturn: return "RETURN"
	case OpLoadConst: return "LOAD_CONST"
	case OpLoadVar: return "LOAD_VAR"
	case OpStoreVar: return "STORE_VAR"
	case OpLoadParam: return "LOAD_PARAM"
	case OpLoadField: return "LOAD_FIELD"
	case OpStoreField: return "STORE_FIELD"
	case OpLoadIndex: return "LOAD_INDEX"
	case OpStoreIndex: return "STORE_INDEX"
	case OpLoadBitField: return "LOAD_BIT_FIELD"
	case OpStoreBitField: return "STORE_BIT_FIELD"
	case OpMove: return "MOVE"
	case OpLoadLabel: return "LOAD_LABEL"
	case OpLoadDirect: return "LOAD_DIRECT"
	case OpStoreDirect: return "STORE_DIRECT"
	case OpAdd: return "ADD"
	case OpSub: return "SUB"
	case OpMul: return "MUL"
	case OpDiv: return "DIV"
	case OpMod: return "MOD"
	case OpNeg: return "NEG"
	case OpInc: return "INC"
	case OpDec: return "DEC"
	case OpAnd: return "AND"
	case OpOr: return "OR"
	case OpXor: return "XOR"
	case OpNot: return "NOT"
	case OpShl: return "SHL"
	case OpShr: return "SHR"
	case OpCmp: return "CMP"
	case OpTest: return "TEST"
	case OpEq: return "EQ"
	case OpNe: return "NE"
	case OpLt: return "LT"
	case OpGt: return "GT"
	case OpLe: return "LE"
	case OpGe: return "GE"
	case OpAlloc: return "ALLOC"
	case OpFree: return "FREE"
	case OpLoadPtr: return "LOAD_PTR"
	case OpStorePtr: return "STORE_PTR"
	case OpAddr: return "ADDR"
	case OpLoad: return "LOAD"
	case OpStore: return "STORE"
	case OpPush: return "PUSH"
	case OpPop: return "POP"
	case OpAsm: return "ASM"
	case OpLoadAddr: return "LOAD_ADDR"
	case OpCopyToBuffer: return "COPY_TO_BUFFER"
	case OpCopyFromBuffer: return "COPY_FROM_BUFFER"
	case OpDJNZ: return "DJNZ"
	case OpLoadImm: return "LOAD_IMM"
	case OpLoadReg: return "LOAD_REG"
	case OpLoadMem: return "LOAD_MEM"
	case OpStoreMem: return "STORE_MEM"
	case OpAddImm: return "ADD_IMM"
	case OpJmp: return "JMP"
	case OpJmpIf: return "JMP_IF"
	case OpJmpIfNot: return "JMP_IF_NOT"
	case OpPrintChar: return "PRINT_CHAR"
	case OpHalt: return "HALT"
	case OpPrint: return "PRINT"
	case OpPrintU8: return "PRINT_U8"
	case OpPrintU16: return "PRINT_U16"
	case OpPrintI8: return "PRINT_I8"
	case OpPrintI16: return "PRINT_I16"
	case OpPrintBool: return "PRINT_BOOL"
	case OpPrintString: return "PRINT_STRING"
	case OpPrintStringDirect: return "PRINT_STRING_DIRECT"
	case OpLoadString: return "LOAD_STRING"
	case OpSMCLoadConst: return "SMC_LOAD_CONST"
	case OpSMCStoreConst: return "SMC_STORE_CONST"
	case OpSMCParam: return "SMC_PARAM"
	case OpSMCSave: return "SMC_SAVE"
	case OpSMCRestore: return "SMC_RESTORE"
	case OpSMCUpdate: return "SMC_UPDATE"
	case OpStoreTSMCRef: return "STORE_TSMC_REF"
	case OpTrueSMCLoad: return "TRUE_SMC_LOAD"
	case OpTrueSMCPatch: return "TRUE_SMC_PATCH"
	case OpTSMCRefAnchor: return "TSMC_REF_ANCHOR"
	case OpTSMCRefLoad: return "TSMC_REF_LOAD"
	case OpTSMCRefPatch: return "TSMC_REF_PATCH"
	case OpPatchPoint: return "PATCH_POINT"
	case OpPatchTemplate: return "PATCH_TEMPLATE"
	case OpPatchTarget: return "PATCH_TARGET"
	case OpPatchParam: return "PATCH_PARAM"
	case OpSetError: return "SET_ERROR"
	case OpCheckError: return "CHECK_ERROR"
	case OpArrayInit: return "ARRAY_INIT"
	case OpArrayElement: return "ARRAY_ELEMENT"
	case OpLoadElement: return "LOAD_ELEMENT"
	case OpStoreElement: return "STORE_ELEMENT"
	case OpPortIn: return "PORT_IN"
	case OpPortOut: return "PORT_OUT"
	case OpSyscall: return "SYSCALL"
	default: return fmt.Sprintf("UNKNOWN_OP_%d", int(op))
	}
}