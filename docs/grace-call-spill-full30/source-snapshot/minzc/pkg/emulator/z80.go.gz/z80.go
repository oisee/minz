package emulator

import "github.com/minz/minzc/pkg/z80timing"

const (
	MEMORY_SIZE = 65536
)

// Z80 represents a Z80 processor emulator
type Z80 struct {
	// Main registers
	A, F   uint8  // Accumulator and Flags
	B, C   uint8  // BC register pair
	D, E   uint8  // DE register pair
	H, L   uint8  // HL register pair
	
	// Alternate registers
	A_, F_ uint8  // Shadow accumulator and flags
	B_, C_ uint8  // Shadow BC
	D_, E_ uint8  // Shadow DE
	H_, L_ uint8  // Shadow HL
	
	// Index registers
	IX, IY uint16
	
	// Special registers
	SP uint16 // Stack pointer
	PC uint16 // Program counter
	I  uint8  // Interrupt vector
	R  uint8  // Memory refresh
	
	// Memory
	memory [MEMORY_SIZE]byte
	
	// State
	cycles   uint32
	halted   bool
	iff1     bool // Interrupt flip-flop 1
	iff2     bool // Interrupt flip-flop 2
	im       uint8 // Interrupt mode
	
	// Exit handling configuration
	exitCode     uint16 // Exit code when program terminates
	exitOnRST38  bool   // Exit on RST 38h (cross-platform)
	exitOnRET0   bool   // Exit on RET to 0x0000 (ZX Spectrum)
	
	// I/O handlers
	output   []byte
	ioRead   func(port uint8) uint8
	ioWrite  func(port uint8, value uint8)
}

// Registers holds all Z80 registers for inspection
type Registers struct {
	A, F   uint8
	BC     uint16
	DE     uint16
	HL     uint16
	IX, IY uint16
	SP, PC uint16
}

// New creates a new Z80 emulator
func New() *Z80 {
	z := &Z80{}
	z.Reset()
	
	// Enable both exit conventions by default
	z.exitOnRST38 = true  // Cross-platform MinZ convention
	z.exitOnRET0 = true   // ZX Spectrum compatibility
	
	// Default I/O handlers
	z.ioWrite = func(port uint8, value uint8) {
		if port == 0x23 { // console stdout OUT ($23),A — mze/mzx standard
			z.output = append(z.output, value)
		} else if port == 0x25 { // console stderr OUT ($25),A — mze/mzx standard
			z.output = append(z.output, value)
		}
	}
	
	z.ioRead = func(port uint8) uint8 {
		return 0xFF // Default: all bits high
	}
	
	return z
}

// Reset resets the processor to initial state
func (z *Z80) Reset() {
	z.A, z.F = 0, 0
	z.B, z.C = 0, 0
	z.D, z.E = 0, 0
	z.H, z.L = 0, 0
	z.A_, z.F_ = 0, 0
	z.B_, z.C_ = 0, 0
	z.D_, z.E_ = 0, 0
	z.H_, z.L_ = 0, 0
	z.IX, z.IY = 0, 0
	z.SP = 0xFFFF
	z.PC = 0
	z.I, z.R = 0, 0
	z.cycles = 0
	z.halted = false
	z.iff1, z.iff2 = false, false
	z.im = 0
	z.output = []byte{}
	
	// Clear memory
	for i := range z.memory {
		z.memory[i] = 0
	}
}

// LoadAt loads code at specified address
func (z *Z80) LoadAt(address uint16, code []byte) {
	for i, b := range code {
		if int(address)+i < len(z.memory) {
			z.memory[int(address)+i] = b
		}
	}
}

// Execute runs code from specified address
func (z *Z80) Execute(address uint16) (string, uint32) {
	z.PC = address
	z.output = []byte{}
	startCycles := z.cycles
	
	// Execute until RET or HALT or max cycles
	maxCycles := uint32(100000)
	for z.cycles-startCycles < maxCycles && !z.halted {
		z.step()
		
		// Check for RET at end of function
		if z.memory[z.PC] == 0xC9 { // RET instruction
			z.step() // Execute the RET
			break
		}
	}
	
	return string(z.output), z.cycles - startCycles
}

// Step executes one instruction and returns the number of cycles used
func (z *Z80) Step() int {
	startCycles := z.cycles
	z.step()
	return int(z.cycles - startCycles)
}

// step executes one instruction (internal)
func (z *Z80) step() {
	opcode := z.fetchByte()
	
	switch opcode {
	// NOP
	case 0x00:
		z.cycles += z80timing.NOP

	// LD r, r'
	case 0x78: // LD A, B
		z.A = z.B
		z.cycles += z80timing.LD_r_r
	case 0x79: // LD A, C
		z.A = z.C
		z.cycles += z80timing.LD_r_r
	case 0x7A: // LD A, D
		z.A = z.D
		z.cycles += z80timing.LD_r_r
	case 0x7B: // LD A, E
		z.A = z.E
		z.cycles += z80timing.LD_r_r
	case 0x7C: // LD A, H
		z.A = z.H
		z.cycles += z80timing.LD_r_r
	case 0x7D: // LD A, L
		z.A = z.L
		z.cycles += z80timing.LD_r_r

	// LD r, n
	case 0x3E: // LD A, n
		z.A = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x06: // LD B, n
		z.B = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x0E: // LD C, n
		z.C = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x16: // LD D, n
		z.D = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x1E: // LD E, n
		z.E = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x26: // LD H, n
		z.H = z.fetchByte()
		z.cycles += z80timing.LD_r_n
	case 0x2E: // LD L, n
		z.L = z.fetchByte()
		z.cycles += z80timing.LD_r_n

	// LD rr, nn
	case 0x01: // LD BC, nn
		c := z.fetchByte()
		b := z.fetchByte()
		z.B = b
		z.C = c
		z.cycles += z80timing.LD_rr_nn
	case 0x11: // LD DE, nn
		e := z.fetchByte()
		d := z.fetchByte()
		z.D = d
		z.E = e
		z.cycles += z80timing.LD_rr_nn
	case 0x21: // LD HL, nn
		l := z.fetchByte()
		h := z.fetchByte()
		z.H = h
		z.L = l
		z.cycles += z80timing.LD_rr_nn

	// ADD A, r
	case 0x80: // ADD A, B
		z.add(z.B)
		z.cycles += z80timing.ADD_A_r
	case 0x81: // ADD A, C
		z.add(z.C)
		z.cycles += z80timing.ADD_A_r
	case 0x82: // ADD A, D
		z.add(z.D)
		z.cycles += z80timing.ADD_A_r
	case 0x83: // ADD A, E
		z.add(z.E)
		z.cycles += z80timing.ADD_A_r
	case 0x84: // ADD A, H
		z.add(z.H)
		z.cycles += z80timing.ADD_A_r
	case 0x85: // ADD A, L
		z.add(z.L)
		z.cycles += z80timing.ADD_A_r

	// ADD A, n
	case 0xC6:
		z.add(z.fetchByte())
		z.cycles += z80timing.ADD_A_n

	// SUB r
	case 0x90: // SUB B
		z.sub(z.B)
		z.cycles += z80timing.SUB_r
	case 0x91: // SUB C
		z.sub(z.C)
		z.cycles += z80timing.SUB_r

	// INC r
	case 0x3C: // INC A
		z.A = z.inc(z.A)
		z.cycles += z80timing.INC_r
	case 0x04: // INC B
		z.B = z.inc(z.B)
		z.cycles += z80timing.INC_r
	case 0x0C: // INC C
		z.C = z.inc(z.C)
		z.cycles += z80timing.INC_r

	// DEC r
	case 0x3D: // DEC A
		z.A = z.dec(z.A)
		z.cycles += z80timing.DEC_r
	case 0x05: // DEC B
		z.B = z.dec(z.B)
		z.cycles += z80timing.DEC_r

	// CALL nn
	case 0xCD:
		addr := z.fetchWord()
		z.push(z.PC)
		z.PC = addr
		z.cycles += z80timing.CALL_nn

	// RST instructions (single-byte CALL to fixed addresses)
	case 0xC7: // RST 00h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0000
		z.cycles += z80timing.RST_n
	case 0xCF: // RST 08h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0008
		z.cycles += z80timing.RST_n
	case 0xD7: // RST 10h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0010
		z.cycles += z80timing.RST_n
	case 0xDF: // RST 18h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0018
		z.cycles += z80timing.RST_n
	case 0xE7: // RST 20h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0020
		z.cycles += z80timing.RST_n
	case 0xEF: // RST 28h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0028
		z.cycles += z80timing.RST_n
	case 0xF7: // RST 30h
		z.PC++
		z.push(z.PC)
		z.PC = 0x0030
		z.cycles += z80timing.RST_n
	case 0xFF: // RST 38h — MinZ exit convention
		z.PC++
		if z.exitOnRST38 {
			z.exitCode = uint16(z.H)<<8 | uint16(z.L)
			z.halted = true
		} else {
			z.push(z.PC)
			z.PC = 0x0038
		}
		z.cycles += z80timing.RST_n

	// RET
	case 0xC9:
		returnAddr := z.pop()
		z.PC = returnAddr
		z.cycles += z80timing.RET
		// MinZ exit: RET to 0x0000 = program exit; BC = exit code
		if z.exitOnRET0 && returnAddr == 0x0000 {
			z.exitCode = uint16(z.B)<<8 | uint16(z.C)
			z.halted = true
		}

	// PUSH rr
	case 0xF5: // PUSH AF
		z.push(uint16(z.A)<<8 | uint16(z.F))
		z.cycles += z80timing.PUSH_rr
	case 0xC5: // PUSH BC
		z.push(uint16(z.B)<<8 | uint16(z.C))
		z.cycles += z80timing.PUSH_rr

	// POP rr
	case 0xF1: // POP AF
		af := z.pop()
		z.A = uint8(af >> 8)
		z.F = uint8(af & 0xFF)
		z.cycles += z80timing.POP_rr

	// JP nn
	case 0xC3:
		z.PC = z.fetchWord()
		z.cycles += z80timing.JP_nn

	// JR n
	case 0x18:
		offset := int8(z.fetchByte())
		z.PC = uint16(int(z.PC) + int(offset))
		z.cycles += z80timing.JR_e

	// CP n
	case 0xFE:
		z.compare(z.fetchByte())
		z.cycles += z80timing.CP_n

	// OUT (n), A — note: 11T textbook; remogatto measures 7T for non-ZX ports
	case 0xD3:
		port := z.fetchByte()
		z.ioWrite(port, z.A)
		z.cycles += 11

	// IN A, (n)
	case 0xDB:
		port := z.fetchByte()
		z.A = z.ioRead(port)
		z.cycles += 11

	// HALT
	case 0x76:
		z.halted = true
		z.cycles += z80timing.HALT

	default:
		// Unknown opcode — treat as NOP for now
		z.cycles += z80timing.NOP
	}
}

// Helper functions

func (z *Z80) fetchByte() uint8 {
	b := z.memory[z.PC]
	z.PC++
	return b
}

func (z *Z80) fetchWord() uint16 {
	l := z.fetchByte()
	h := z.fetchByte()
	return uint16(h)<<8 | uint16(l)
}

func (z *Z80) push(value uint16) {
	z.SP--
	z.memory[z.SP] = uint8(value >> 8)
	z.SP--
	z.memory[z.SP] = uint8(value & 0xFF)
}

func (z *Z80) pop() uint16 {
	l := z.memory[z.SP]
	z.SP++
	h := z.memory[z.SP]
	z.SP++
	return uint16(h)<<8 | uint16(l)
}

// Pop pops a 16-bit value from the stack (public version)
func (z *Z80) Pop() uint16 {
	return z.pop()
}

func (z *Z80) add(value uint8) {
	result := uint16(z.A) + uint16(value)
	z.setFlag(FLAG_C, result > 0xFF)
	z.setFlag(FLAG_H, (z.A&0xF)+(value&0xF) > 0xF)
	z.A = uint8(result)
	z.setFlag(FLAG_Z, z.A == 0)
	z.setFlag(FLAG_S, z.A&0x80 != 0)
	z.setFlag(FLAG_N, false)
}

func (z *Z80) sub(value uint8) {
	result := int16(z.A) - int16(value)
	z.setFlag(FLAG_C, result < 0)
	z.setFlag(FLAG_H, (z.A&0xF) < (value&0xF))
	z.A = uint8(result)
	z.setFlag(FLAG_Z, z.A == 0)
	z.setFlag(FLAG_S, z.A&0x80 != 0)
	z.setFlag(FLAG_N, true)
}

func (z *Z80) inc(value uint8) uint8 {
	result := value + 1
	z.setFlag(FLAG_Z, result == 0)
	z.setFlag(FLAG_S, result&0x80 != 0)
	z.setFlag(FLAG_H, (value&0xF) == 0xF)
	z.setFlag(FLAG_P, result == 0x80)
	z.setFlag(FLAG_N, false)
	return result
}

func (z *Z80) dec(value uint8) uint8 {
	result := value - 1
	z.setFlag(FLAG_Z, result == 0)
	z.setFlag(FLAG_S, result&0x80 != 0)
	z.setFlag(FLAG_H, (value&0xF) == 0)
	z.setFlag(FLAG_P, value == 0x80)
	z.setFlag(FLAG_N, true)
	return result
}

func (z *Z80) compare(value uint8) {
	result := int16(z.A) - int16(value)
	z.setFlag(FLAG_Z, result == 0)
	z.setFlag(FLAG_S, result < 0)
	z.setFlag(FLAG_C, result < 0)
	z.setFlag(FLAG_N, true)
}

// Flag bit positions
const (
	FLAG_C = 0 // Carry
	FLAG_N = 1 // Add/Subtract
	FLAG_P = 2 // Parity/Overflow
	FLAG_H = 4 // Half Carry
	FLAG_Z = 6 // Zero
	FLAG_S = 7 // Sign
)

func (z *Z80) setFlag(flag uint8, value bool) {
	if value {
		z.F |= (1 << flag)
	} else {
		z.F &^= (1 << flag)
	}
}

func (z *Z80) getFlag(flag uint8) bool {
	return z.F&(1<<flag) != 0
}

// GetRegisters returns current register values
func (z *Z80) GetRegisters() Registers {
	return Registers{
		A:  z.A,
		F:  z.F,
		BC: uint16(z.B)<<8 | uint16(z.C),
		DE: uint16(z.D)<<8 | uint16(z.E),
		HL: uint16(z.H)<<8 | uint16(z.L),
		IX: z.IX,
		IY: z.IY,
		SP: z.SP,
		PC: z.PC,
	}
}

// GetIFF1 returns interrupt flip-flop 1 state
func (z *Z80) GetIFF1() bool {
	return z.iff1
}

// GetIFF2 returns interrupt flip-flop 2 state
func (z *Z80) GetIFF2() bool {
	return z.iff2
}

// GetIM returns interrupt mode
func (z *Z80) GetIM() uint8 {
	return z.im
}

// ReadMemory reads a byte from memory
func (z *Z80) ReadMemory(address uint16) uint8 {
	return z.memory[address]
}

// WriteMemory writes a byte to memory
func (z *Z80) WriteMemory(address uint16, value uint8) {
	z.memory[address] = value
}

// DumpMemory returns memory contents for debugging
func (z *Z80) DumpMemory(start uint16, length uint16) []byte {
	result := make([]byte, length)
	for i := uint16(0); i < length; i++ {
		addr := start + i
		// Check for overflow and bounds
		if addr >= start && int(addr) < MEMORY_SIZE {
			result[i] = z.memory[addr]
		}
	}
	return result
}

// GetExitCode returns the exit code when program terminates
func (z *Z80) GetExitCode() uint16 {
	return z.exitCode
}

// SetExitConventions configures which exit conventions are enabled
// rst38: Enable RST 38h exit (cross-platform MinZ convention, HL = exit code)
// ret0: Enable RET to 0x0000 exit (ZX Spectrum convention, BC = exit code)
func (z *Z80) SetExitConventions(rst38, ret0 bool) {
	z.exitOnRST38 = rst38
	z.exitOnRET0 = ret0
}

// IsHalted returns true if CPU is halted
func (z *Z80) IsHalted() bool {
	return z.halted
}

// SetHalted sets the halted state
func (z *Z80) SetHalted(halted bool) {
	z.halted = halted
}

// AF returns the AF register pair value
func (z *Z80) AF() uint16 {
	return uint16(z.A)<<8 | uint16(z.F)
}

// BC returns the BC register pair value
func (z *Z80) BC() uint16 {
	return uint16(z.B)<<8 | uint16(z.C)
}

// DE returns the DE register pair value
func (z *Z80) DE() uint16 {
	return uint16(z.D)<<8 | uint16(z.E)
}

// HL returns the HL register pair value
func (z *Z80) HL() uint16 {
	return uint16(z.H)<<8 | uint16(z.L)
}

// GetMemory returns a reference to the memory array for direct access
func (z *Z80) GetMemory() *[MEMORY_SIZE]byte {
	return &z.memory
}

// Memory returns memory array reference (alias for compatibility)
func (z *Z80) Memory() *[MEMORY_SIZE]byte {
	return &z.memory
}

// GetDE returns the DE register pair value
func (z *Z80) GetDE() uint16 {
	return uint16(z.D)<<8 | uint16(z.E)
}

// SetCarryFlag sets or clears the carry flag
func (z *Z80) SetCarryFlag(set bool) {
	if set {
		z.F |= 0x01
	} else {
		z.F &^= 0x01
	}
}

// GetCarryFlag returns the state of the carry flag
func (z *Z80) GetCarryFlag() bool {
	return z.F&0x01 != 0
}

// Public field accessors for debugger
func (z *Z80) GetA() uint8 { return z.A }
func (z *Z80) GetF() uint8 { return z.F }
func (z *Z80) GetB() uint8 { return z.B }
func (z *Z80) GetC() uint8 { return z.C }
func (z *Z80) GetD() uint8 { return z.D }
func (z *Z80) GetE() uint8 { return z.E }
func (z *Z80) GetH() uint8 { return z.H }
func (z *Z80) GetL() uint8 { return z.L }
func (z *Z80) GetI() uint8 { return z.I }
func (z *Z80) GetPC() uint16 { return z.PC }
func (z *Z80) GetSP() uint16 { return z.SP }
func (z *Z80) GetIX() uint16 { return z.IX }
func (z *Z80) GetIY() uint16 { return z.IY }

// Public field setters for debugger
func (z *Z80) SetA(v uint8) { z.A = v }
func (z *Z80) SetF(v uint8) { z.F = v }
func (z *Z80) SetB(v uint8) { z.B = v }
func (z *Z80) SetC(v uint8) { z.C = v }
func (z *Z80) SetD(v uint8) { z.D = v }
func (z *Z80) SetE(v uint8) { z.E = v }
func (z *Z80) SetH(v uint8) { z.H = v }
func (z *Z80) SetL(v uint8) { z.L = v }
func (z *Z80) SetI(v uint8) { z.I = v }
func (z *Z80) SetPC(v uint16) { z.PC = v }
func (z *Z80) SetSP(v uint16) { z.SP = v }
func (z *Z80) SetIX(v uint16) { z.IX = v }
func (z *Z80) SetIY(v uint16) { z.IY = v }