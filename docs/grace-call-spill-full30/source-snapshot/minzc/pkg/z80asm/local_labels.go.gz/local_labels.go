package z80asm

import (
	"fmt"
	"strings"
)

// LocalLabelContext manages local label scoping
type LocalLabelContext struct {
	currentGlobal string              // Current global label scope
	localLabels   map[string]*Symbol  // Map of expanded local labels
}

// NewLocalLabelContext creates a new local label context
func NewLocalLabelContext() *LocalLabelContext {
	return &LocalLabelContext{
		localLabels: make(map[string]*Symbol),
	}
}

// processLabelForContext handles both global and local labels
func (ctx *LocalLabelContext) processLabelForContext(label string, addr int, pass int) (string, error) {
	// Check if it's a local label (starts with exactly one dot, not multiple dots)
	if isLocalLabel(label) {
		// Local label
		if ctx.currentGlobal == "" {
			return "", fmt.Errorf("local label '%s' defined before any global label", label)
		}
		
		// Expand local label to include global scope
		expandedLabel := ctx.currentGlobal + label
		return expandedLabel, nil
	} else {
		// Global label - update current scope
		ctx.currentGlobal = label
		return label, nil
	}
}

// expandLocalLabelReferences expands local label references in operands
// Handles both direct references (.local) and embedded references like (.local), (.local+1)
func (ctx *LocalLabelContext) expandLocalLabelReferences(operand string) string {
	if ctx.currentGlobal == "" {
		return operand
	}

	// Simple case: entire operand is a local label
	if isLocalLabel(operand) {
		return ctx.currentGlobal + operand
	}

	// Scan for local label references embedded in expressions
	// A local label starts with '.' followed by a letter/underscore, then alphanumeric/_
	result := []byte(operand)
	i := 0
	for i < len(result) {
		if result[i] == '.' && i+1 < len(result) {
			// Check if preceded by a letter/digit/underscore (part of another symbol like "foo.bar")
			if i > 0 {
				prev := result[i-1]
				if (prev >= 'a' && prev <= 'z') || (prev >= 'A' && prev <= 'Z') ||
					(prev >= '0' && prev <= '9') || prev == '_' {
					i++
					continue
				}
			}
			// Check next char is a valid label start
			next := result[i+1]
			if (next >= 'a' && next <= 'z') || (next >= 'A' && next <= 'Z') || next == '_' {
				// Find end of local label name
				end := i + 2
				for end < len(result) {
					c := result[end]
					if (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
						(c >= '0' && c <= '9') || c == '_' {
						end++
					} else {
						break
					}
				}
				localName := string(result[i:end])
				if isLocalLabel(localName) {
					expanded := ctx.currentGlobal + localName
					newResult := make([]byte, 0, len(result)+len(ctx.currentGlobal))
					newResult = append(newResult, result[:i]...)
					newResult = append(newResult, []byte(expanded)...)
					newResult = append(newResult, result[end:]...)
					i += len(expanded)
					result = newResult
					continue
				}
			}
		}
		i++
	}
	return string(result)
}

// preprocessLocalLabels processes all lines to expand local labels before assembly
func preprocessLocalLabels(lines []*Line) ([]*Line, error) {
	ctx := NewLocalLabelContext()
	result := make([]*Line, 0, len(lines))
	
	for _, line := range lines {
		newLine := &Line{
			Number:   line.Number,
			Label:    line.Label,
			Directive: line.Directive,
			Mnemonic: line.Mnemonic,
			Operands: make([]string, len(line.Operands)),
			Comment:  line.Comment,
			IsBlank:  line.IsBlank,
		}
		
		// Process label if present
		if line.Label != "" {
			expandedLabel, err := ctx.processLabelForContext(line.Label, 0, 1)
			if err != nil {
				return nil, fmt.Errorf("line %d: %w", line.Number, err)
			}
			
			// Update the label
			newLine.Label = expandedLabel
		}
		
		// Process operands for local label references
		for i, operand := range line.Operands {
			newLine.Operands[i] = ctx.expandLocalLabelReferences(operand)
		}
		
		result = append(result, newLine)
	}
	
	return result, nil
}

// isLocalLabel checks if a label is a local label
// A local label starts with exactly one dot followed by a simple identifier
// (no more dots in the name). Labels like ".home.alice..." are NOT local labels
// but rather module-qualified global labels from MinZ.
func isLocalLabel(label string) bool {
	if !strings.HasPrefix(label, ".") || strings.HasPrefix(label, "..") {
		return false
	}
	// Check if there are more dots after the first one
	// If so, it's a module-qualified label, not a local label
	rest := label[1:]
	return !strings.Contains(rest, ".")
}

// getGlobalScope extracts the global scope from an expanded local label
func getGlobalScope(expandedLabel string) string {
	// Find the last dot
	lastDot := strings.LastIndex(expandedLabel, ".")
	if lastDot > 0 {
		return expandedLabel[:lastDot]
	}
	return expandedLabel
}