// Package c89 implements a C89/C99 frontend for the MinZ compiler.
//
// Architecture:
//
//	C source → cparse.Translate() → cc.AST → lower.go → *hir.Module
//
// The heavy lifting (preprocessing, parsing, type checking, implicit conversions)
// is handled by modernc.org/cc. This package only walks the typed AST and emits
// HIR nodes.
//
// See docs/adr/0024-c89-frontend-strategy.md for the full design.
// See docs/adr/0025-struct-return-promotion.md for struct→tuple promotion.
// See docs/adr/0026-c-stdlib-print-variadics.md for @print and variadics.
package c89

import (
	"encoding/binary"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	cc "github.com/minz/minzc/pkg/cparse"

	"github.com/minz/minzc/pkg/hir"
	"github.com/minz/minzc/pkg/interop"
	"github.com/minz/minzc/pkg/mir2"
)

// z80 predefined macros and type declarations for the C type checker.
const z80Predefined = `
#define __CHAR_BIT__ 8
#define __SIZEOF_INT__ 2
#define __SIZEOF_LONG__ 4
#define __SIZEOF_POINTER__ 2
#define __SIZEOF_SHORT__ 2
#define __SIZE_TYPE__ unsigned int
#define __PTRDIFF_TYPE__ int
#define __WCHAR_TYPE__ int
#define __INT_MAX__ 32767
#define __LONG_MAX__ 2147483647
#define __SCHAR_MAX__ 127
#define __SHRT_MAX__ 32767
#define NULL ((void*)0)
#define __Z80__ 1
#define __MINZ__ 1
#define __STDC__ 1
#define __STDC_VERSION__ 201710L
#define __STDC_HOSTED__ 0
#define bool _Bool
#define true 1
#define false 0
#define nullptr ((void*)0)
#define constexpr const
#define __builtin_unreachable() do { while(1); } while(0)
typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned int uint16_t;
typedef signed int int16_t;
typedef unsigned long uint32_t;
typedef signed long int32_t;
typedef unsigned int size_t;
typedef int ptrdiff_t;
int __predefined_declarator;
typedef unsigned int __predefined_size_t;
typedef int __predefined_ptrdiff_t;
typedef int __predefined_wchar_t;
typedef void *__builtin_va_list;
`

// z80ABI returns the ABI configuration for Z80 (16-bit int, 16-bit pointers).
func z80ABI() *cc.ABI {
	mkTy := func(size int64) cc.AbiType {
		return cc.AbiType{Size: size, Align: 1, FieldAlign: 1}
	}
	return &cc.ABI{
		ByteOrder:  binary.LittleEndian,
		SignedChar: true,
		Types: map[cc.Kind]cc.AbiType{
			cc.Void:       mkTy(0),
			cc.Bool:       mkTy(1),
			cc.Char:       mkTy(1),
			cc.SChar:      mkTy(1),
			cc.UChar:      mkTy(1),
			cc.Short:      mkTy(2),
			cc.UShort:     mkTy(2),
			cc.Int:        mkTy(2),
			cc.UInt:       mkTy(2),
			cc.Long:       mkTy(4),
			cc.ULong:      mkTy(4),
			cc.LongLong:   mkTy(4),
			cc.ULongLong:  mkTy(4),
			cc.Float:      mkTy(4),
			cc.Double:     mkTy(4),
			cc.LongDouble: mkTy(4),
			cc.Ptr:        mkTy(2),
			cc.Function:   mkTy(2),
			cc.Array:      mkTy(0),
			cc.Struct:     mkTy(0),
			cc.Union:      mkTy(0),
			cc.Enum:       mkTy(2),
		},
	}
}

// CompileOpts configures the C89 compiler.
type CompileOpts struct {
	// BaseDir is the source file directory for resolving #import paths.
	BaseDir string
	// Resolver handles cross-language #import directives.
	// If nil, #import directives are ignored.
	Resolver *interop.Resolver
	// IncludePaths are additional directories for #include "file.h" resolution.
	IncludePaths []string
	// SysIncludePaths are additional directories for #include <file.h> resolution.
	SysIncludePaths []string
	// NoLibc disables the built-in minimal libc headers.
	NoLibc bool
}

// Compile parses C source code and produces an HIR module.
func Compile(src, name string) (*hir.Module, error) {
	return CompileWithOpts(src, name, CompileOpts{})
}

// CompileWithOpts parses C source code with options (including #import support).
func CompileWithOpts(src, name string, opts CompileOpts) (*hir.Module, error) {
	// Process #import directives before cc/v4 sees the source.
	var importedModules []*hir.Module
	if opts.Resolver != nil {
		cleaned, mods, err := opts.Resolver.Resolve(src)
		if err != nil {
			return nil, fmt.Errorf("c89 #import: %w", err)
		}
		src = cleaned
		importedModules = mods
	}

	// Strip C23 [[attribute]] annotations before cc/v4 sees the source.
	// These are cosmetic (warnings/hints) — no codegen effect on Z80.
	src = stripC23Attributes(src)

	// Process C23 _BitInt(N) → Z80 native types.
	// N=1..8 → uint8_t, N=9..16 → uint16_t, N=17..32 → uint32_t, else → error comment.
	src = preprocessBitInt(src)

	// Strip C23 digit separators: 1'000 → 1000, 0xFF'FF → 0xFFFF.
	// Safe: only matches digit'digit, never touches char literals ('A').
	src = stripDigitSeparators(src)

	// Process C23 #embed directives before cc/v4 sees the source.
	// #embed "file" → comma-separated byte values inline.
	src = preprocessEmbed(src, opts.BaseDir)

	// Build include paths: "@" means "same dir as source file".
	incPaths := []string{"@"}
	incPaths = append(incPaths, opts.IncludePaths...)

	// System include paths: always include our minimal libc unless disabled.
	var sysIncPaths []string
	if !opts.NoLibc {
		if dir := libcSysIncludeDir(); dir != "" {
			sysIncPaths = append(sysIncPaths, dir)
		}
	}
	sysIncPaths = append(sysIncPaths, opts.SysIncludePaths...)

	cfg := &cc.Config{
		ABI:             z80ABI(),
		IncludePaths:    incPaths,
		SysIncludePaths: sysIncPaths,
	}

	sources := []cc.Source{
		{Name: "<predefined>", Value: z80Predefined},
		{Name: name, Value: src},
	}

	ast, err := cc.Translate(cfg, sources)
	if err != nil {
		return nil, fmt.Errorf("c89 parse: %w", err)
	}

	modName := strings.TrimSuffix(name, ".c")
	modName = strings.TrimSuffix(modName, ".m")
	l := &lowerer{
		ast:         ast,
		hm:          &hir.Module{Name: modName},
		globals:     make(map[string]mir2.Ty),
		typedefs:    make(map[string]mir2.Ty),
		structs:     make(map[string]*mir2.StructTy),
		cStructs:    make(map[cc.Type]string),
		objcClasses:   make(map[string]*objcClassInfo),
		objcProtocols: make(map[string]*objcProtocolInfo),
	}

	if err := l.lower(); err != nil {
		return nil, fmt.Errorf("c89 lower: %w", err)
	}

	// Struct-return promotion (ADR-0025): small struct returns → tuple returns.
	// Must run before merge so promoted signatures are visible to importers.
	PromoteStructReturns(l.hm)

	// Merge imported modules into this module.
	if len(importedModules) > 0 {
		interop.MergeInto(l.hm, importedModules)
	}

	// Parse comment-based asserts and sandboxes.
	directives, err := ListAsserts(src)
	if err != nil {
		return nil, err
	}
	l.hm.Asserts, l.hm.Sandboxes = directives.Asserts, directives.Sandboxes

	// Parse and generate ObjC assert wrappers.
	l.generateObjCAssertWrappers(src)
	l.generateObjCDynAssertWrappers(src)

	return l.hm, nil
}

// assertRe matches: // assert fn(1, 2, 0xAB) == 42 [via mir2|z80]
var assertStartRe = regexp.MustCompile(`^\s*//\s*assert(?:\s|$)`)

var assertRe = regexp.MustCompile(
	`//\s*assert\s+(\w+)\s*\(([^)]*)\)\s*==\s*(-?(?:0[xX][0-9a-fA-F]+|\d+))(?:\s+via\s+(mir2|z80))?\s*(?://.*)?$`,
)

// objcAssertRe matches: // assert-objc Counter{count:42}.value(5) == 42
// Groups: 1=ClassName, 2=field_inits (may be empty), 3=methodName, 4=args (may be empty), 5=expected, 6=via
var objcAssertRe = regexp.MustCompile(
	`//\s*assert-objc\s+(\w+)\{([^}]*)}\s*\.\s*(\w+)\s*\(([^)]*)\)\s*==\s*(-?(?:0[xX][0-9a-fA-F]+|\d+))(?:\s+via\s+(mir2|z80))?\s*$`,
)

// objcDynAssertRe matches: // assert-objc-dyn Drawable Circle{radius:5}.area() == 25
// Groups: 1=Protocol, 2=ClassName, 3=field_inits, 4=methodName, 5=args, 6=expected, 7=via
var objcDynAssertRe = regexp.MustCompile(
	`//\s*assert-objc-dyn\s+(\w+)\s+(\w+)\{([^}]*)}\s*\.\s*(\w+)\s*\(([^)]*)\)\s*==\s*(-?(?:0[xX][0-9a-fA-F]+|\d+))(?:\s+via\s+(mir2|z80))?\s*$`,
)

// sandboxStartRe matches: // sandbox "name"
var sandboxStartRe = regexp.MustCompile(`//\s*sandbox\s+"([^"]+)"`)

// sandboxEndRe matches: // end sandbox
var sandboxEndRe = regexp.MustCompile(`//\s*end\s+sandbox`)

func parseAssertLine(line string, lineNo int) (hir.Assert, bool) {
	m := assertRe.FindStringSubmatch(line)
	if m == nil {
		return hir.Assert{}, false
	}
	funcName := m[1]
	argsStr := strings.TrimSpace(m[2])
	expectedStr := m[3]
	via := m[4]

	var args []int64
	if argsStr != "" {
		for _, s := range strings.Split(argsStr, ",") {
			s = strings.TrimSpace(s)
			v, err := strconv.ParseInt(s, 0, 64) // base 0: auto-detect 0x, 0b, octal
			if err != nil {
				return hir.Assert{}, false
			}
			args = append(args, v)
		}
	}

	expected, err := strconv.ParseInt(expectedStr, 0, 64)
	if err != nil {
		return hir.Assert{}, false
	}
	return hir.Assert{
		FuncName: funcName,
		Args:     args,
		Expected: expected,
		Source:   line,
		Line:     lineNo,
		Via:      via,
	}, true
}

// parseCommentDirectives scans C source for assert and sandbox directives in comments.
func parseCommentDirectives(src string) ([]hir.Assert, []hir.Sandbox) {
	var asserts []hir.Assert
	var sandboxes []hir.Sandbox

	var curSandbox *hir.Sandbox

	for i, line := range strings.Split(src, "\n") {
		line = strings.TrimSpace(line)
		lineNo := i + 1

		// Check sandbox start.
		if m := sandboxStartRe.FindStringSubmatch(line); m != nil {
			curSandbox = &hir.Sandbox{Name: m[1], Line: lineNo}
			continue
		}

		// Check sandbox end.
		if sandboxEndRe.MatchString(line) && curSandbox != nil {
			sandboxes = append(sandboxes, *curSandbox)
			curSandbox = nil
			continue
		}

		// Check assert.
		if a, ok := parseAssertLine(line, lineNo); ok {
			if curSandbox != nil {
				curSandbox.Asserts = append(curSandbox.Asserts, a)
			} else {
				asserts = append(asserts, a)
			}
		}
	}

	// Auto-close unclosed sandbox.
	if curSandbox != nil && len(curSandbox.Asserts) > 0 {
		sandboxes = append(sandboxes, *curSandbox)
	}

	return asserts, sandboxes
}

// bitIntRe matches C23 _BitInt(N) type specifier.
var bitIntRe = regexp.MustCompile(`_BitInt\(\s*(\d+)\s*\)`)

// preprocessBitInt replaces _BitInt(N) with Z80-native types.
//
//	_BitInt(1)..._BitInt(8)   → uint8_t
//	_BitInt(9)..._BitInt(16)  → uint16_t
//	_BitInt(17)..._BitInt(32) → uint32_t
//	_BitInt(>32)              → /* _BitInt(N) error: too wide for Z80 */ int
func preprocessBitInt(src string) string {
	return bitIntRe.ReplaceAllStringFunc(src, func(match string) string {
		m := bitIntRe.FindStringSubmatch(match)
		if m == nil {
			return match
		}
		n, err := strconv.Atoi(m[1])
		if err != nil || n < 1 {
			return match
		}
		switch {
		case n <= 8:
			return "uint8_t"
		case n <= 16:
			return "uint16_t"
		case n <= 32:
			return "uint32_t"
		default:
			return fmt.Sprintf("/* _BitInt(%d): too wide for Z80 (max 32) */ int", n)
		}
	})
}

// digitSepRe matches C23 digit separators: digit'digit (e.g. 1'000, 0xFF'FF).
// Safe: [0-9a-fA-F]'[0-9a-fA-F] never matches char literals ('A').
var digitSepRe = regexp.MustCompile(`([0-9a-fA-F])'([0-9a-fA-F])`)

// stripDigitSeparators removes C23 digit separators from numeric literals.
// Applied repeatedly to handle multiple separators (1'000'000 → 1000000).
func stripDigitSeparators(src string) string {
	for digitSepRe.MatchString(src) {
		src = digitSepRe.ReplaceAllString(src, "${1}${2}")
	}
	return src
}

// c23AttrRe matches C23 [[attribute]] annotations.
// Fixed set: maybe_unused, nodiscard, deprecated, noreturn, fallthrough,
// _Noreturn, unsequenced, reproducible. Optional ("msg") argument.
var c23AttrRe = regexp.MustCompile(`\[\[\s*(?:maybe_unused|nodiscard|noreturn|_Noreturn|fallthrough|unsequenced|reproducible|deprecated(?:\s*\([^)]*\))?)\s*\]\]`)

// stripC23Attributes removes [[attribute]] annotations from C23 source.
// These are cosmetic hints (warnings) — no codegen effect on Z80.
func stripC23Attributes(src string) string {
	return c23AttrRe.ReplaceAllString(src, "")
}

// embedRe matches: #embed "filename" or #embed <filename>
// Optional limit/offset params (C23): #embed "file" limit(N) offset(N)
var embedRe = regexp.MustCompile(`(?m)^\s*#\s*embed\s+("([^"]+)"|<([^>]+)>)(?:\s+limit\((\d+)\))?(?:\s+offset\((\d+)\))?\s*$`)

// preprocessEmbed replaces C23 #embed directives with comma-separated byte literals.
// This runs before the cc parser sees the source.
//
//	#embed "font.bin"                → 0x41,0x42,...
//	#embed "data.bin" limit(256)     → first 256 bytes
//	#embed "data.bin" offset(128)    → skip 128 bytes
func preprocessEmbed(src, baseDir string) string {
	return embedRe.ReplaceAllStringFunc(src, func(match string) string {
		m := embedRe.FindStringSubmatch(match)
		if m == nil {
			return match
		}
		filename := m[2]
		if filename == "" {
			filename = m[3] // <file> form
		}
		if filename == "" {
			return match
		}

		// Resolve relative to baseDir
		if !filepath.IsAbs(filename) && baseDir != "" {
			filename = filepath.Join(baseDir, filename)
		}

		data, err := os.ReadFile(filename)
		if err != nil {
			// Return error as comment so cc parser gives a clear message
			return fmt.Sprintf("/* #embed error: %s */", err)
		}

		// Optional offset
		offset := 0
		if m[5] != "" {
			offset, _ = strconv.Atoi(m[5])
			if offset > len(data) {
				offset = len(data)
			}
			data = data[offset:]
		}

		// Optional limit
		if m[4] != "" {
			limit, _ := strconv.Atoi(m[4])
			if limit < len(data) {
				data = data[:limit]
			}
		}

		if len(data) == 0 {
			return "/* #embed: empty */"
		}

		// Keep the expansion on its original line so assertion listing and compiler
		// diagnostics retain source line numbers.
		// Convert to comma-separated hex bytes
		var sb strings.Builder
		for i, b := range data {
			if i > 0 {
				sb.WriteByte(',')
			}
			fmt.Fprintf(&sb, "0x%02X", b)
		}
		return sb.String()
	})
}

// ListAsserts recognizes C assertion directives without requiring headers or
// lowering functions. This shares the production frontend parser and validation.
func ListAsserts(src string) (*hir.Module, error) {
	m := &hir.Module{}
	m.Asserts, m.Sandboxes = parseCommentDirectives(src)
	for i, line := range strings.Split(src, "\n") {
		if assertStartRe.MatchString(line) {
			if _, ok := parseAssertLine(line, i+1); !ok {
				return nil, fmt.Errorf("line %d: malformed // assert directive", i+1)
			}
		}
	}

	return m, nil
}
