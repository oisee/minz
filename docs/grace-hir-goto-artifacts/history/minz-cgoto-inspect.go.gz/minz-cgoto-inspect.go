package main
import("fmt";"github.com/minz/minzc/pkg/c89")
func main(){m,e:=c89.Compile(`int outward(void){int x=7;int i=0;again:{i=i+1;int x=99;if(i<2)goto again;}return x;}`,"goto.c");fmt.Println(e);fmt.Println(m.Dump())}
