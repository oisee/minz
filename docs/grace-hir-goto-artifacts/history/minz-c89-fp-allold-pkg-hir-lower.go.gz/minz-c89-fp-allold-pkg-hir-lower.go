package hir

// lower.go — HIR → MIR2 lowering pass.
//
// Algorithm:
//  1. For each HIR Func, create a MIR2 Func with register classes assigned
//     from parameter position + type (classForParam).
//  2. Maintain an environment map[varName]mir2.Reg that tracks the current
//     virtual register holding each named variable.
//     A parallel envTy map[varName]mir2.Ty tracks types (stable; never changes
//     once a variable is bound).
//  3. Lower statements:
//       VarDeclStmt  → alloca or just bind the init expression's vreg
//       AssignStmt   → lower rhs, update env[name] (new vreg each assignment)
//       ReturnStmt   → lower value (if any), emit Ret
//       IfStmt       → two-pass: scan mutations, emit BrIf with correct Jmp args
//       WhileStmt    → detect mutated vars, thread as block params at loop_head/exit
//       ForRangeStmt → desugar to WhileStmt equivalent
//       ExprStmt     → lower expr (side-effect only)
//  4. Lower expressions recursively; each call returns a mir2.Reg.
//
// Variable mutation across basic blocks:
//   WhileStmt detects which variables in the env are written inside the loop
//   body (via scanMutations) and promotes them to block params so that
//   loop-carried values flow through MIR2's SSA block arguments.
//
//   If/else: same idea — the join block receives the final value of each
//   mutated variable as a block param.
//
// This is "almost SSA" — single assignment per path, block params at joins —
// without a full dominance-frontier computation.  Good enough for structured
// control flow; the Braun 2013 algorithm is a Phase 4b refinement.

import (
	"fmt"
	"maps"
	"strings"

	"github.com/minz/minzc/pkg/mir2"
)

// ── Public entry point ────────────────────────────────────────────────────────

// LowerModule converts a HIR module to a MIR2 module.
func LowerModule(hm *Module) *mir2.Module {
	m := &mir2.Module{Name: hm.Name, Target: hm.Target}
	for _, g := range hm.Globals {
		m.AddGlobal(g)
	}
	for i, s := range hm.Strings {
		kind := mir2.StrSString // default
		if i < len(hm.StrKinds) {
			kind = hm.StrKinds[i]
		}
		m.Strings.InternKind(s, kind)
	}

	// Collect all function names and HIR func map for callback inlining.
	funcNames := make(map[string]bool, len(hm.Funcs))
	hirFuncs := make(map[string]*Func, len(hm.Funcs))
	for _, f := range hm.Funcs {
		funcNames[f.Name] = true
		hirFuncs[f.Name] = f
	}

	// Collect global names for free-variable detection.
	globalNames := make(map[string]bool, len(hm.Globals))
	for _, g := range hm.Globals {
		globalNames[g.Name] = true
	}

	for _, f := range hm.Funcs {
		// Skip standalone lowering of lambdas that capture outer locals.
		// Such functions are always inlined via lowerFusedForEach; lowering
		// them directly would panic on the free-variable references.
		if hasFreeVars(f, globalNames, funcNames) {
			continue
		}
		lowerFuncWithFuncNames(m, f, funcNames, hirFuncs, hm.LoopLineage)
	}
	return m
}

// hasFreeVars reports whether f references any variable that is not one of its
// own parameters, not a global, and not a module-level function name.
// Such functions are capture-lambdas that must be inlined rather than lowered
// as standalone MIR2 functions.
func hasFreeVars(f *Func, globalNames, funcNames map[string]bool) bool {
	if len(f.Captures) > 0 {
		return true
	}
	if f.Body == nil {
		return false
	}
	bound := make(map[string]bool, len(f.Params))
	for _, p := range f.Params {
		bound[p.Name] = true
	}
	return blockHasFreeRef(f.Body, bound, globalNames, funcNames)
}

func blockHasFreeRef(blk *Block, bound, globals, funcs map[string]bool) bool {
	for _, s := range blk.Body {
		if stmtHasFreeRef(s, bound, globals, funcs) {
			return true
		}
	}
	return false
}

func stmtHasFreeRef(s Stmt, bound, globals, funcs map[string]bool) bool {
	switch st := s.(type) {
	case *Block:
		return blockHasFreeRef(st, bound, globals, funcs)
	case *VarDeclStmt:
		if st.Init != nil && exprHasFreeRef(st.Init, bound, globals, funcs) {
			return true
		}
		bound[st.Name] = true // newly bound
	case *AssignStmt:
		if exprHasFreeRef(st.Val, bound, globals, funcs) {
			return true
		}
		if d, ok := st.Target.(*DerefExpr); ok {
			return exprHasFreeRef(d.Ptr, bound, globals, funcs)
		}
		// A plain variable assignment (c = a - b) binds the target name.
		if vr, ok := st.Target.(*VarRefExpr); ok {
			bound[vr.Name] = true
		}
	case *ReturnStmt:
		if st.Val != nil {
			return exprHasFreeRef(st.Val, bound, globals, funcs)
		}
		for _, v := range st.Vals {
			if exprHasFreeRef(v, bound, globals, funcs) {
				return true
			}
		}
	case *TupleLetStmt:
		for _, a := range st.Call.Args {
			if exprHasFreeRef(a, bound, globals, funcs) {
				return true
			}
		}
		for _, name := range st.Names {
			if name != "_" {
				bound[name] = true
			}
		}
	case *ExprStmt:
		return exprHasFreeRef(st.Expr, bound, globals, funcs)
	case *StoreStmt:
		return exprHasFreeRef(st.Ptr, bound, globals, funcs) ||
			exprHasFreeRef(st.Val, bound, globals, funcs)
	case *IfStmt:
		return exprHasFreeRef(st.Cond, bound, globals, funcs) ||
			blockHasFreeRef(st.Then, bound, globals, funcs) ||
			(st.Else != nil && blockHasFreeRef(st.Else, bound, globals, funcs))
	case *WhileStmt:
		return exprHasFreeRef(st.Cond, bound, globals, funcs) ||
			blockHasFreeRef(st.Body, bound, globals, funcs)
	case *ForEachStmt:
		if exprHasFreeRef(st.Ptr, bound, globals, funcs) {
			return true
		}
		if st.Len != nil && exprHasFreeRef(st.Len, bound, globals, funcs) {
			return true
		}
		bound[st.Var] = true // element variable is bound inside the body
		return blockHasFreeRef(st.Body, bound, globals, funcs)
	case *ForRangeStmt:
		if st.Start != nil && exprHasFreeRef(st.Start, bound, globals, funcs) {
			return true
		}
		if st.End != nil && exprHasFreeRef(st.End, bound, globals, funcs) {
			return true
		}
		bound[st.Var] = true // loop variable is bound inside the body
		return blockHasFreeRef(st.Body, bound, globals, funcs)
	case *SwitchStmt:
		if exprHasFreeRef(st.Val, bound, globals, funcs) {
			return true
		}
		for _, c := range st.Cases {
			if blockHasFreeRef(c.Body, bound, globals, funcs) {
				return true
			}
		}
		if st.Default != nil {
			return blockHasFreeRef(st.Default, bound, globals, funcs)
		}
	}
	return false
}

func exprHasFreeRef(e Expr, bound, globals, funcs map[string]bool) bool {
	if e == nil {
		return false
	}
	switch ex := e.(type) {
	case *VarRefExpr:
		return !bound[ex.Name] && !globals[ex.Name] && !funcs[ex.Name]
	case *BinExpr:
		return exprHasFreeRef(ex.L, bound, globals, funcs) ||
			exprHasFreeRef(ex.R, bound, globals, funcs)
	case *UnaryExpr:
		return exprHasFreeRef(ex.X, bound, globals, funcs)
	case *CallExpr:
		for _, a := range ex.Args {
			if exprHasFreeRef(a, bound, globals, funcs) {
				return true
			}
		}
	case *CallIndirectExpr:
		if exprHasFreeRef(ex.FnPtr, bound, globals, funcs) {
			return true
		}
		for _, a := range ex.Args {
			if exprHasFreeRef(a, bound, globals, funcs) {
				return true
			}
		}
	case *FieldExpr:
		return exprHasFreeRef(ex.X, bound, globals, funcs)
	case *LoadExpr:
		return exprHasFreeRef(ex.Ptr, bound, globals, funcs)
	case *DerefExpr:
		return exprHasFreeRef(ex.Ptr, bound, globals, funcs)
	case *CastExpr:
		return exprHasFreeRef(ex.X, bound, globals, funcs)
	case *IndexExpr:
		return exprHasFreeRef(ex.Base, bound, globals, funcs) ||
			exprHasFreeRef(ex.Idx, bound, globals, funcs)
	case *CondExpr:
		return exprHasFreeRef(ex.Cond, bound, globals, funcs) ||
			exprHasFreeRef(ex.Then, bound, globals, funcs) ||
			exprHasFreeRef(ex.Else, bound, globals, funcs)
	case *LetInExpr:
		if exprHasFreeRef(ex.Init, bound, globals, funcs) {
			return true
		}
		bound[ex.Name] = true
		return exprHasFreeRef(ex.Body, bound, globals, funcs)
	}
	return false
}

// ── Per-function lowering state ───────────────────────────────────────────────

// loopCtx holds the context needed for break/continue inside a loop.
type loopCtx struct {
	headLabel    string     // continue → jump here (with headMutated args)
	exitLabel    string     // break    → jump here (with exitMutated args)
	mutated      []string   // loop-carried variable names (same set for both)
	exitPrefix   []mir2.Reg // ForEach exit also receives its pointer and counter
	scopeDepth   int
	continueStep Stmt // ForRange advances its induction variable before continue
}

type lowerer struct {
	scopeRestores []func()
	lineage       map[Stmt]LoopLineage
	hf            *Func
	m             *mir2.Module
	mf            *mir2.Func
	bld           *mir2.Builder
	target        uint8 // platform target from hir.Module.Target

	// env maps variable names to their current virtual register.
	// envTy maps variable names to their type (stable: set once, never changed).
	env   map[string]mir2.Reg
	envTy map[string]mir2.Ty

	// hirFuncNames is the set of all function names in the HIR module.
	// Used to distinguish function references from undefined variables.
	hirFuncNames map[string]bool

	// hirFuncs maps function names to their HIR Func for callback inlining
	// in iterator chain fusion (map/filter/forEach).
	hirFuncs map[string]*Func

	// fnAliases maps local variable names to function names.
	// e.g. "let f = |x| x+1" → fnAliases["f"] = "lambda_0"
	// Calls through "f" are resolved to "lambda_0" at call sites.
	fnAliases map[string]string

	// localArrays tracks local array variables promoted to globals.
	// &name for these should return the env register (address) directly.
	localArrays map[string]bool

	// loopStack is the stack of enclosing loops (top = innermost).
	// Needed by BreakStmt and ContinueStmt.
	loopStack []loopCtx

	// inLoopContext is true whenever we are lowering expressions that form part
	// of a loop — either the loop head condition or the loop body.  It is used
	// to suppress classForALUResult: loop-carried values that live across ALU
	// operations must not be forced into A, which is a transient workspace for
	// comparisons and increments.
	inLoopContext bool

	// labelSeq generates unique block labels within this function.
	labelSeq int

	// gotoLabels maps C label names to MIR2 block labels.
	gotoLabels map[string]string

	// backwardGotoLabels is the set of labels that are targets of backward gotos
	// (i.e., the goto appears after the label in source order). These labels need
	// block parameters for all live variables so the back-edge carries updated values.
	backwardGotoLabels map[string]bool

	// backwardGotoVars records the sorted variable names threaded through each
	// backward-goto label block. Set when the LabelStmt is first lowered.
	backwardGotoVars map[string][]string
}

func (l *lowerer) pushLoop(ctx loopCtx) {
	ctx.scopeDepth = len(l.scopeRestores)
	l.loopStack = append(l.loopStack, ctx)
}
func (l *lowerer) popLoop() { l.loopStack = l.loopStack[:len(l.loopStack)-1] }
func (l *lowerer) curLoop() *loopCtx {
	if len(l.loopStack) == 0 {
		panic("hir/lower: break/continue outside loop")
	}
	return &l.loopStack[len(l.loopStack)-1]
}

func (l *lowerer) fresh(prefix string) string {
	l.labelSeq++
	return fmt.Sprintf("%s%d", prefix, l.labelSeq)
}

// bind records both the register and type for a variable name.
func (l *lowerer) bind(name string, r mir2.Reg, ty mir2.Ty) {
	l.env[name] = r
	l.envTy[name] = ty
	delete(l.fnAliases, name)
	delete(l.localArrays, name)
}

// findGlobal looks up a global by name in the MIR2 module.
func (l *lowerer) findGlobal(name string) (mir2.Global, bool) {
	for _, g := range l.m.Globals {
		if g.Name == name {
			return g, true
		}
	}
	return mir2.Global{}, false
}

// globalAddr emits AddrOf for a global variable name.
func (l *lowerer) globalAddr(name string) mir2.Reg {
	return l.bld.AddrOf(name, mir2.ClassPointer)
}

// lowerExprAddr lowers an expression to its address (lvalue), rather than its value.
// Used for field-store targets (origin.y = v) and eventually local struct alloca.
func (l *lowerer) lowerExprAddr(ex Expr) mir2.Reg {
	switch e := ex.(type) {
	case *VarRefExpr:
		if _, ok := l.findGlobal(e.Name); ok {
			return l.globalAddr(e.Name)
		}
		// Local pointer variable (e.g. param `self: ^Acc`): the register value IS the address.
		if reg, ok := l.env[e.Name]; ok {
			return reg
		}
		panic(fmt.Sprintf("hir/lower: cannot take address of local variable %q", e.Name))
	case *FieldExpr:
		baseAddr := l.lowerExprAddr(e.X)
		if e.Offset > 0 {
			return l.bld.Field(baseAddr, int64(e.Offset), mir2.ClassPointer)
		}
		return baseAddr
	case *IndexExpr:
		// base[i] address — same as lowerIndex but without the final Load
		baseAddr := l.lowerExpr(e.Base)
		idx := l.lowerExpr(e.Idx)
		stride := int64(e.ElemStride)
		if stride == 0 {
			stride = int64(e.ElemTy.Width() / 8)
		}
		if stride > 1 {
			width := e.ElemTy.Width()
			sizeTy := mir2.Ty(mir2.TyU16)
			if width <= 8 {
				sizeTy = mir2.TyU8
			}
			idx = l.bld.Mul(idx, l.bld.Const(stride, sizeTy, mir2.ClassAcc), sizeTy, mir2.ClassAcc)
		}
		return l.bld.PtrAdd(baseAddr, idx, mir2.ClassPointer)
	default:
		panic(fmt.Sprintf("hir/lower: cannot take address of %T", ex))
	}
}

func bitBaseTy(base Expr) mir2.Ty {
	if base == nil {
		return mir2.TyU8
	}
	return base.ExprTy()
}

func bitMaskFor(baseTy mir2.Ty, bit int64) int64 {
	mask := int64(1) << bit
	if baseTy == nil {
		return mask
	}
	w := baseTy.Width()
	if w <= 0 || w >= 63 {
		return mask
	}
	return mask & ((int64(1) << w) - 1)
}

func (l *lowerer) lowerBitRead(ex *BitExpr) mir2.Reg {
	baseTy := bitBaseTy(ex.X)
	base := l.lowerExpr(ex.X)
	return l.bld.BitGet(base, ex.Bit, baseTy, classForExpr(mir2.TyU8))
}

func (l *lowerer) lowerBitAssign(tgt *BitExpr, val Expr) {
	baseTy := bitBaseTy(tgt.X)
	maskImm := bitMaskFor(baseTy, int64(tgt.Bit))

	constAssign := func() (set bool, value bool) {
		switch v := val.(type) {
		case *IntLitExpr:
			return true, (v.Val & 1) != 0
		case *BoolLitExpr:
			return true, v.Val
		default:
			return false, false
		}
	}

	merge := func(cur mir2.Reg) mir2.Reg {
		if ok, bit := constAssign(); ok {
			if bit {
				return l.bld.BitSet(cur, tgt.Bit, baseTy, classForExpr(baseTy))
			}
			return l.bld.BitReset(cur, tgt.Bit, baseTy, classForExpr(baseTy))
		}
		notMask := l.bld.Const(^maskImm, baseTy, mir2.ClassGeneral)
		rhs := l.lowerExprAs(val, mir2.TyU8)
		rhsBase := l.bld.Ext(rhs, mir2.TyU8, baseTy, classForExpr(baseTy))
		one := l.bld.Const(1, baseTy, mir2.ClassGeneral)
		bitVal := l.bld.And(rhsBase, one, baseTy, classForExpr(baseTy))
		setVal := bitVal
		if tgt.Bit > 0 {
			shift := l.bld.Const(int64(tgt.Bit), baseTy, mir2.ClassGeneral)
			setVal = l.bld.Shl(bitVal, shift, baseTy, classForExpr(baseTy))
		}
		cleared := l.bld.And(cur, notMask, baseTy, classForExpr(baseTy))
		return l.bld.Or(cleared, setVal, baseTy, classForExpr(baseTy))
	}

	switch base := tgt.X.(type) {
	case *VarRefExpr:
		next := merge(l.lowerExpr(base))
		if g, found := l.findGlobal(base.Name); found {
			addr := l.globalAddr(base.Name)
			l.bld.Store(addr, next, g.Ty)
			return
		}
		l.env[base.Name] = next
	case *FieldExpr:
		addr := l.lowerExprAddr(base)
		l.bld.Store(addr, merge(l.lowerExpr(base)), baseTy)
	case *IndexExpr:
		addr := l.lowerExprAddr(base)
		l.bld.Store(addr, merge(l.lowerExpr(base)), baseTy)
	case *LoadExpr:
		ptr := l.lowerExpr(base.Ptr)
		l.bld.Store(ptr, merge(l.lowerExpr(base)), baseTy)
	case *DerefExpr:
		ptr := l.lowerExpr(base.Ptr)
		cur := l.bld.Load(ptr, baseTy, classForExpr(baseTy))
		l.bld.Store(ptr, merge(cur), baseTy)
	default:
		panic(fmt.Sprintf("hir/lower: unsupported BitExpr target base %T", tgt.X))
	}
}

// ── Function lowering ─────────────────────────────────────────────────────────

func lowerFunc(m *mir2.Module, f *Func) {
	lowerFuncWithFuncNames(m, f, nil, nil)
}

func lowerFuncWithFuncNames(m *mir2.Module, f *Func, funcNames map[string]bool, hirFuncs map[string]*Func, lineage ...map[Stmt]LoopLineage) {
	mf := m.AddFunc(f.Name)
	if f.IsExtern {
		mf.Attrs.IsExtern = true
		mf.Attrs.ExternAddr = f.ExternAddr
		mf.Contract.ExternClobbers = f.ExternClobbers
	}

	// Set return type(s).
	if len(f.RetTys) > 0 {
		// Multi-return: use RetTys slice.
		mf.Contract.Returns = make([]mir2.Return, len(f.RetTys))
		for i, ty := range f.RetTys {
			mf.Contract.Returns[i] = mir2.Return{Ty: ty, Class: classForRetPos(ty, i)}
		}
	} else if f.RetTy != mir2.TyVoid {
		cls := classForRet(f.RetTy)
		mf.Contract.Returns = []mir2.Return{{Ty: f.RetTy, Class: cls}}
	}

	if f.IsExtern {
		bld := mir2.NewBuilder(mf)
		for i, p := range f.Params {
			cls := classForParam(p.Ty, i)
			if p.RegClass != 0 {
				cls = p.RegClass
			}
			bld.Param(p.Name, p.Ty, cls)
		}
		return
	}

	bld := mir2.NewBuilder(mf)
	l := &lowerer{
		hf:           f,
		m:            m,
		mf:           mf,
		bld:          bld,
		target:       m.Target,
		env:          make(map[string]mir2.Reg),
		envTy:        make(map[string]mir2.Ty),
		hirFuncNames: funcNames,
		hirFuncs:     hirFuncs,
		fnAliases:    make(map[string]string),
		localArrays:  make(map[string]bool),
	}

	if len(lineage) > 0 {
		l.lineage = map[Stmt]LoopLineage{}
		for node, origin := range lineage[0] {
			l.lineage[node] = origin
		}
	}
	bld.SwitchToNewBlock("entry")

	// Bind parameters to virtual registers.
	// @smc params are NOT MIR2 contract params — they become PatchSlots in the
	// entry block (LD HL, imm16 with EQU label; auto-patcher synthesised by z80codegen).
	nonSMCIdx := 0
	for _, p := range f.Params {
		if p.SMC {
			sym := f.Name + "$" + p.Name
			r := bld.PatchSlotNamed(sym, 0, mir2.TyPtr, mir2.ClassPointer)
			l.bind(p.Name, r, mir2.TyPtr)
			continue
		}
		cls := classForParam(p.Ty, nonSMCIdx)
		if p.RegClass != 0 {
			cls = p.RegClass
		}
		r := bld.Param(p.Name, p.Ty, cls)
		l.bind(p.Name, r, p.Ty)
		nonSMCIdx++
	}

	// Pre-create blocks for all goto labels (forward references).
	l.gotoLabels = make(map[string]string)
	collectLabels(f.Body, func(name string) {
		blkLabel := "label_" + name
		bld.F.NewBlock(blkLabel)
		l.gotoLabels[name] = blkLabel
	})

	// Detect backward gotos (loop-via-goto) — these need variable threading.
	l.backwardGotoLabels = detectBackwardGotos(f.Body)
	l.backwardGotoVars = make(map[string][]string)

	// Lower body.
	l.lowerBlock(f.Body)

	// Implicit return for void functions that fall off the end of the current block.
	if !bld.Cur.IsSealed() {
		bld.Ret()
	}
}

// classForParam chooses a register class for the i-th parameter.
//
//	pos 0 → ClassAcc     (A)
//	ptr   → ClassPointer (HL)
//	pos 1 → ClassGeneral (C/D/E)
//	pos 2 → ClassCounter (B) — common for a count/length 3rd arg
func classForParam(ty mir2.Ty, pos int) mir2.RegClass {
	if mir2.IsPointer(ty) {
		return mir2.ClassPointer
	}
	if _, isStruct := ty.(*mir2.StructTy); isStruct {
		// Struct params are passed as pointers (address in HL on Z80).
		return mir2.ClassPointer
	}
	if ty == mir2.TyU16 || ty == mir2.TyI16 {
		if pos == 0 {
			return mir2.ClassPointer
		}
		return mir2.ClassIndex
	}
	switch pos {
	case 0:
		return mir2.ClassAcc
	case 1:
		return mir2.ClassGeneral
	case 2:
		return mir2.ClassCounter
	default:
		return mir2.ClassGeneral
	}
}

// classForRet chooses the return class for a single-return function.
func classForRet(ty mir2.Ty) mir2.RegClass {
	if mir2.IsPointer(ty) || ty == mir2.TyU16 || ty == mir2.TyI16 {
		return mir2.ClassPointer // HL
	}
	return mir2.ClassAcc // A
}

// classForRetPos chooses the return class for position pos in a multi-return function.
//
//	pos 0 → same as classForRet (A for u8, HL for u16)
//	pos 1 → ClassCounter (B) for u8/u16; ClassIndex (DE) for pointers/u16 pairs
//	pos 2 → ClassGeneral (C/D/E)
//
// Note: ClassIndex (DE) is a 16-bit pair and cannot hold an 8-bit return value
// directly — using it for u8 causes the allocator to spill to memory.
// Use ClassCounter (B) for the second u8 return instead.
func classForRetPos(ty mir2.Ty, pos int) mir2.RegClass {
	w := ty.Width()
	switch pos {
	case 0:
		return classForRet(ty)
	case 1:
		if w <= 8 {
			return mir2.ClassCounter // B — 8-bit register, fits u8
		}
		return mir2.ClassIndex // DE — 16-bit pair for u16/ptr
	default:
		return mir2.ClassGeneral // C/D/E
	}
}

// lowerExprForRet lowers an expression that is the direct value of a ReturnStmt.
// For a LoadExpr or FieldExpr at the top level, it uses classForRet (ClassAcc)
// instead of classForExpr (ClassGeneral), so the load goes directly into A and
// avoids the redundant LD C,(HL); LD A,C sequence.
func (l *lowerer) lowerExprForRet(e Expr) mir2.Reg {
	switch ex := e.(type) {
	case *LoadExpr:
		if ex.Ty.Width() <= 8 {
			ptr := l.lowerExpr(ex.Ptr)
			return l.bld.Load(ptr, ex.Ty, classForRet(ex.Ty))
		}
	case *FieldExpr:
		if ex.Ty.Width() <= 8 {
			base := l.lowerExpr(ex.X)
			if ex.Offset > 0 {
				base = l.bld.Field(base, int64(ex.Offset), mir2.ClassPointer)
			}
			return l.bld.Load(base, ex.Ty, classForRet(ex.Ty))
		}
	case *CondExpr:
		// Desugar `return cond ? X : Y` into two separate Ret blocks:
		//   BrIf(cond, then, else)
		//   then: Ret(X)
		//   else: Ret(Y)
		// This avoids a join block and enables CondRetSink + FuseAbsDiff.
		cond := l.lowerCond(ex.Cond)
		thenLabel := l.fresh("cret_then")
		elseLabel := l.fresh("cret_else")
		l.bld.BrIf(cond, thenLabel, nil, elseLabel, nil)

		l.bld.SwitchToNewBlock(thenLabel)
		thenVal := l.lowerExpr(ex.Then)
		l.bld.Ret(thenVal)

		l.bld.SwitchToNewBlock(elseLabel)
		elseVal := l.lowerExpr(ex.Else)
		l.bld.Ret(elseVal)

		// Return a dummy — the Ret instructions are already emitted.
		// The caller (ReturnStmt handler) will see that the block is
		// already terminated and skip emitting another Ret.
		return mir2.NoReg
	}
	return l.lowerExpr(e)
}

// classForExpr picks a "natural" class for an intermediate expression result.
//
// We use ClassGeneral (B/C/D/E) rather than ClassAcc (A) for 8-bit
// intermediates.  The Z80 genBinOp always uses A as a transient workspace and
// then stores the result to the destination register; if the destination were A
// and the *next* instruction also uses A as workspace, it would clobber the
// still-live intermediate value.  ClassGeneral destinations are written via
// "LD dst, A" and are safe across subsequent ALU operations that transiently
// modify A.
//
// Explicit "must be in A" values (function return values, call returns) still
// use ClassAcc via classForRet; parameters use classForParam.
func classForExpr(ty mir2.Ty) mir2.RegClass {
	if (mir2.IsPointer(ty) && mir2.PointerElem(ty) != mir2.TyU8) || ty == mir2.TyU16 || ty == mir2.TyI16 {
		return mir2.ClassPointer
	}
	return mir2.ClassGeneral
}

// classForALUResult returns the preferred class for an 8-bit ALU operation
// result. Z80 ALU ops (ADD, SUB, AND, OR, XOR, NEG) always write to A, so
// ClassAcc avoids a spurious LD C,A after the instruction.
// 16-bit variants write to HL → ClassPointer.
// Other ops (MUL, shifts) are not pure A-writes → ClassGeneral.
func classForALUResult(op string, ty mir2.Ty) mir2.RegClass {
	if (mir2.IsPointer(ty) && mir2.PointerElem(ty) != mir2.TyU8) || ty == mir2.TyU16 || ty == mir2.TyI16 {
		return mir2.ClassPointer
	}
	switch op {
	case "+", "-", "&", "|", "^":
		return mir2.ClassAcc
	}
	return classForExpr(ty)
}

// classForLoop chooses a good class for a loop-carried variable.
func classForLoop(ty mir2.Ty, _ string) mir2.RegClass {
	if (mir2.IsPointer(ty) && mir2.PointerElem(ty) != mir2.TyU8) || ty == mir2.TyU16 || ty == mir2.TyI16 {
		return mir2.ClassPointer
	}
	// ClassGeneral keeps loop vars out of A (which comparisons need).
	return mir2.ClassGeneral
}

// ── Statement lowering ────────────────────────────────────────────────────────

// lowerBlock lowers a HIR block (list of statements).
// Returns true if the block already ends with a terminator.
func (l *lowerer) lowerBlock(blk *Block) bool {
	// Each lexical declaration hides a binding only for this block. Snapshot
	// when the declaration executes, so earlier assignments to outer variables
	// survive. Restore metadata together with the SSA register on every exit.
	type binding struct {
		reg                     mir2.Reg
		ty                      mir2.Ty
		alias                   string
		hasReg, hasTy, hasAlias bool
		array                   bool
	}
	locals := map[string]binding{}
	save := func(name string) {
		if _, saved := locals[name]; saved {
			return
		}
		r, rok := l.env[name]
		ty, tok := l.envTy[name]
		alias, aok := l.fnAliases[name]
		locals[name] = binding{r, ty, alias, rok, tok, aok, l.localArrays[name]}
	}
	restore := func() {
		for name, b := range locals {
			if b.hasReg {
				l.env[name] = b.reg
			} else {
				delete(l.env, name)
			}
			if b.hasTy {
				l.envTy[name] = b.ty
			} else {
				delete(l.envTy, name)
			}
			if b.array {
				l.localArrays[name] = true
			} else {
				delete(l.localArrays, name)
			}
			if b.hasAlias {
				l.fnAliases[name] = b.alias
			} else {
				delete(l.fnAliases, name)
			}
		}
	}
	l.scopeRestores = append(l.scopeRestores, restore)
	defer func() { restore(); l.scopeRestores = l.scopeRestores[:len(l.scopeRestores)-1] }()
	terminated := false
	for _, s := range blk.Body {
		if terminated {
			// After a terminator (goto/break/return), only labels are reachable.
			if ls, ok := s.(*LabelStmt); ok {
				l.lowerStmt(ls)
				terminated = false
				continue
			}
			// Skip dead code after terminator.
			continue
		}
		switch decl := s.(type) {
		case *VarDeclStmt:
			save(decl.Name)
		case *TupleLetStmt:
			for _, name := range decl.Names {
				if name != "_" {
					save(name)
				}
			}
		}
		if l.lowerStmt(s) {
			terminated = true
		}
	}
	return terminated
}

// lowerStmt lowers one statement.  Returns true if it emitted a terminator.
func (l *lowerer) lowerStmt(s Stmt) bool {
	switch st := s.(type) {

	case *Block:
		return l.lowerBlock(st)

	case *VarDeclStmt:
		var r mir2.Reg
		if st.Init != nil {
			// Check for fold/reduce: let result = fold(ptr, init, cb, n)
			if foldReg, ok := l.tryLowerFold(st.Init); ok {
				chain, _ := l.recognizeIterChain(st.Init)
				l.bind(st.Name, foldReg, chain.foldAccTy)
				return false
			}
			r = l.lowerExpr(st.Init)
			if r == mir2.NoReg {
				// Init is a function reference (lambda or module function).
				// Record as alias so calls through this variable are resolved.
				if vr, ok := st.Init.(*VarRefExpr); ok {
					funcName := vr.Name
					if alias, isAlias := l.fnAliases[vr.Name]; isAlias {
						funcName = alias
					}
					delete(l.env, st.Name)
					delete(l.envTy, st.Name)
					delete(l.localArrays, st.Name)
					l.fnAliases[st.Name] = funcName
				}
				return false
			}
		} else if _, isStruct := st.Ty.(*mir2.StructTy); isStruct {
			// Local struct variable without init: allocate stack space.
			// Returns a pointer register (ClassPointer = HL on Z80).
			size := int64(st.Ty.Width() / 8)
			if size <= 0 {
				size = 1
			}
			r = l.bld.Alloca(size)
		} else if st.ArrayLen > 0 {
			// Local array variable: promote to module-level global.
			// Z80 has no stack frames — static storage is used instead.
			elemBytes := st.Ty.Width() / 8
			if elemBytes <= 0 {
				elemBytes = 1
			}
			totalBytes := st.ArrayLen * elemBytes
			globalName := l.mf.Name + "$" + st.Name
			baseName := globalName
			for {
				if _, exists := l.findGlobal(globalName); !exists {
					break
				}
				globalName = baseName + "$" + l.fresh("scope_")
			}
			initBytes := make([]byte, totalBytes)
			// Pre-populate from Initial (array designated/positional init)
			for i, expr := range st.Initial {
				if expr == nil {
					continue
				}
				if lit, ok := expr.(*IntLitExpr); ok {
					off := i * elemBytes
					if off < totalBytes {
						initBytes[off] = byte(lit.Val)
						if elemBytes >= 2 && off+1 < totalBytes {
							initBytes[off+1] = byte(lit.Val >> 8)
						}
					}
				}
			}
			l.m.Globals = append(l.m.Globals, mir2.Global{
				Name: globalName,
				Ty:   mir2.NewArray(st.Ty, st.ArrayLen),
				Init: initBytes,
			})
			r = l.bld.AddrOf(globalName, mir2.ClassPointer)
			l.localArrays[st.Name] = true
			// For non-constant initializers, emit runtime stores
			for i, expr := range st.Initial {
				if expr == nil {
					continue
				}
				if _, ok := expr.(*IntLitExpr); ok {
					continue // already in initBytes
				}
				val := l.lowerExpr(expr)
				off := i * elemBytes
				if off == 0 {
					l.bld.Store(r, val, st.Ty)
				} else {
					addr := l.bld.Add(r, l.bld.Const(int64(off), mir2.TyU16, mir2.ClassPointer), mir2.TyU16, mir2.ClassPointer)
					l.bld.Store(addr, val, st.Ty)
				}
			}
		} else {
			r = l.bld.Const(0, st.Ty, classForExpr(st.Ty))
		}
		delete(l.fnAliases, st.Name) // a scalar declaration hides a callable alias
		l.bind(st.Name, r, st.Ty)
		if st.ArrayLen > 0 {
			l.localArrays[st.Name] = true
		}
		return false

	case *AssignStmt:
		// Check for fold/reduce: x = fold(ptr, init, cb, n)
		if foldReg, ok := l.tryLowerFold(st.Val); ok {
			if tgt, ok2 := st.Target.(*VarRefExpr); ok2 {
				l.env[tgt.Name] = foldReg
				return false
			}
		}
		// Struct literal in-place construction: target = StructName{...}
		// Write each field directly into the target memory — no alloca needed.
		if lit, ok := st.Val.(*StructLitExpr); ok {
			switch tgt := st.Target.(type) {
			case *DerefExpr:
				// ptr^ = Struct{...}
				// Use sequential chaining: each field address derived from the
				// PREVIOUS field address + diff, so no base reg stays live across
				// multiple Field ops — all can share HL.
				ptrReg := l.lowerExpr(tgt.Ptr)
				l.emitStructLitFieldsChained(lit, ptrReg)
				return false
			case *VarRefExpr:
				// global_struct = Color{...}
				// Emit a fresh AddrOf per field so each AddrOf has useCount==1 —
				// that allows the HL-chain optimizer in z80codegen to fire:
				//   LD HL,sym ; LD (HL),n ; INC HL ; LD (HL),n ; ...
				if _, found := l.findGlobal(tgt.Name); found {
					name := tgt.Name
					l.emitStructLitFields(lit, func() mir2.Reg { return l.globalAddr(name) })
					return false
				}
			}
		}
		val := l.lowerExpr(st.Val)
		switch tgt := st.Target.(type) {
		case *VarRefExpr:
			// Global variable: store through pointer.
			if g, found := l.findGlobal(tgt.Name); found {
				addr := l.globalAddr(tgt.Name)
				l.bld.Store(addr, val, g.Ty)
				return false
			}
			// Re-bind the local variable to the new vreg (SSA-style rename).
			// Type is already in envTy; just update the register.
			l.env[tgt.Name] = val
		case *DerefExpr:
			ptr := l.lowerExpr(tgt.Ptr)
			l.bld.Store(ptr, val, tgt.Ty)
		case *FieldExpr:
			// Store to struct field: compute field address then store.
			addr := l.lowerExprAddr(tgt)
			l.bld.Store(addr, val, tgt.Ty)
		case *IndexExpr:
			// arr[i] = val: compute element address then store.
			addr := l.lowerExprAddr(tgt)
			l.bld.Store(addr, val, tgt.ElemTy)
		case *BitExpr:
			l.lowerBitAssign(tgt, st.Val)
		default:
			panic(fmt.Sprintf("hir/lower: unsupported AssignStmt target %T", st.Target))
		}
		return false

	case *ReturnStmt:
		if len(st.Vals) > 0 {
			// Multi-return: coerce each value to its contract register class so
			// PBQP allocates it to the correct physical register.  Without this,
			// all constants get [general] class and may be allocated to the same
			// physical register, causing TermRet to emit invalid parallel copies.
			regs := make([]mir2.Reg, len(st.Vals))
			for i, v := range st.Vals {
				r := l.lowerExpr(v)
				cls := classForRetPos(v.ExprTy(), i)
				if cls != 0 {
					r = l.bld.Move(r, v.ExprTy(), cls)
				}
				regs[i] = r
			}
			l.bld.Ret(regs...)
		} else if st.Val != nil {
			// Check for fold/reduce: return fold(ptr, init, cb, n)
			if foldReg, ok := l.tryLowerFold(st.Val); ok {
				l.bld.Ret(foldReg)
			} else {
				r := l.lowerExprForRet(st.Val)
				// NoReg means lowerExprForRet already emitted Ret instructions
				// (e.g. CondExpr desugared into two Ret blocks).
				if r != mir2.NoReg {
					l.bld.Ret(r)
				}
			}
		} else {
			l.bld.Ret()
		}
		return true

	case *TupleLetStmt:
		// Build Returns slice for CallMulti.
		returns := make([]mir2.Return, len(st.Tys))
		for i, ty := range st.Tys {
			returns[i] = mir2.Return{Ty: ty, Class: classForRetPos(ty, i)}
		}
		// Look up callee HIR params for type-directed literal coercion.
		// This handles the case where an integer literal like "10" is parsed
		// as u8 but the callee expects u16 (e.g. minmax(a: u16, b: u16)).
		var calleeParams []Param
		if callee, ok := l.hirFuncs[st.Call.Fn]; ok && callee != nil {
			calleeParams = callee.Params
		}
		args := make([]mir2.Reg, len(st.Call.Args))
		for i, a := range st.Call.Args {
			// Determine the callee's expected parameter type and class for this position.
			// Use lowerExprAs to widen integer literals to the callee's type,
			// then apply the calling-convention class coercion (same as regular CallExpr).
			paramTy := a.ExprTy()
			if i < len(calleeParams) {
				paramTy = calleeParams[i].Ty
			}
			r := l.lowerExprAs(a, paramTy)
			tgtCls := classForParam(paramTy, i)
			if tgtCls != classForExpr(paramTy) {
				r = l.bld.Move(r, paramTy, tgtCls)
			}
			args[i] = r
		}
		regs := l.bld.CallMulti(st.Call.Fn, args, returns, mir2.CallAttrs{})
		for i, name := range st.Names {
			if name == "_" || i >= len(regs) {
				continue
			}
			if regs[i] != mir2.NoReg {
				l.bind(name, regs[i], st.Tys[i])
			}
		}
		return false

	case *ExprStmt:
		if l.tryLowerIterChain(st.Expr) {
			return false
		}
		l.lowerExpr(st.Expr)
		return false

	case *StoreStmt:
		// When the target is an IndexExpr we need the *address* (TyPtr),
		// not the loaded value.  lowerExpr(IndexExpr) would emit a Load
		// and return the element value (TyU8/etc), causing PBQP to
		// allocate an 8-bit register for the store pointer → invalid codegen.
		var ptr mir2.Reg
		if ie, ok := st.Ptr.(*IndexExpr); ok {
			ptr = l.lowerIndexAddr(ie)
		} else {
			ptr = l.lowerExpr(st.Ptr)
		}
		// ptr^ = Struct{...}: use chained stores instead of alloca round-trip.
		if lit, ok := st.Val.(*StructLitExpr); ok {
			l.emitStructLitFieldsChained(lit, ptr)
			return false
		}
		val := l.lowerExpr(st.Val)
		l.bld.Store(ptr, val, st.Val.ExprTy())
		return false

	case *AsmStmt:
		// Inline assembly block.  We currently compile only for Z80; skip blocks
		// whose target tag doesn't match.  Empty target = match any.
		if st.Target != "" && st.Target != "z80" {
			return false // wrong target — silently skip
		}
		// Compute clobber set.
		var clobbers mir2.ClassSet
		switch {
		case st.ClobberAll:
			clobbers = mir2.AllClasses
		case len(st.ClobberRegs) > 0:
			// Explicit clobber list: (clob A, F, HL)
			for _, reg := range st.ClobberRegs {
				clobbers = clobbers.Union(z80RegToClassSet(reg))
			}
		case st.ClobberAuto:
			// Auto-detect clobbers from asm text.
			clobbers = z80AutoClobbers(st.Code)
		default:
			clobbers = mir2.AllClasses
		}
		// "/" is an inline instruction separator — expand to newline.
		// Each line is stripped so the codegen's own "    " prefix applies cleanly.
		var lines []string
		for _, line := range strings.Split(st.Code, "/") {
			line = strings.TrimSpace(line)
			if line != "" {
				lines = append(lines, line)
			}
		}
		code := strings.Join(lines, "\n    ")
		// Resolve input operands to virtual registers.
		// If no explicit (in ...) clause, auto-infer from @z80_X-annotated params.
		// If explicit, (in REG, ...) names physical registers; we reverse-map
		// each to the @z80_X parameter that occupies that register.
		var ins []mir2.Reg
		if len(st.Ins) == 0 {
			for _, p := range l.hf.Params {
				if p.RegClass != 0 {
					if r, ok := l.env[p.Name]; ok {
						ins = append(ins, r)
					}
				}
			}
		} else {
			for _, op := range st.Ins {
				wantCls := z80RegNameToClass(op.Name)
				found := false
				for _, p := range l.hf.Params {
					if p.RegClass == wantCls {
						if r, ok := l.env[p.Name]; ok {
							ins = append(ins, r)
							found = true
							break
						}
					}
				}
				if !found {
					// Fallback: try as variable name (backward compat)
					if r, ok := l.env[op.Name]; ok {
						ins = append(ins, r)
					}
				}
			}
		}
		var outs []mir2.Reg
		for _, op := range st.Outs {
			if r, ok := l.env[op.Name]; ok {
				outs = append(outs, r)
			}
		}
		// Determine return type and class from (ret REG).
		var retTy mir2.Ty = mir2.TyVoid
		retCls := mir2.ClassAcc
		if st.RetReg != "" {
			retTy, retCls = z80RetRegInfo(st.RetReg)
		}
		l.bld.Asm(code, ins, outs, clobbers, retTy, retCls)
		l.bld.F.Attrs.HasAsm = true
		return false

	case *IfStmt:
		return l.lowerIf(st)

	case *WhileStmt:
		l.lowerWhile(st)
		return false

	case *ForRangeStmt:
		l.lowerForRange(st)
		return false

	case *ForEachStmt:
		l.lowerForEach(st)
		return false

	case *BreakStmt:
		ctx := l.curLoop()
		oldEnv, oldTy, oldAlias, oldArrays := l.env, l.envTy, l.fnAliases, l.localArrays
		l.env = cloneMap(l.env)
		l.envTy = maps.Clone(l.envTy)
		l.fnAliases = maps.Clone(l.fnAliases)
		l.localArrays = maps.Clone(l.localArrays)
		for i := len(l.scopeRestores) - 1; i >= ctx.scopeDepth; i-- {
			l.scopeRestores[i]()
		}
		defer func() { l.env = oldEnv; l.envTy = oldTy; l.fnAliases = oldAlias; l.localArrays = oldArrays }()
		args := append(append([]mir2.Reg{}, ctx.exitPrefix...), l.collectArgs(ctx.mutated)...)
		l.bld.Jmp(ctx.exitLabel, args...)
		return true // break is a terminator

	case *ContinueStmt:
		ctx := l.curLoop()
		oldEnv, oldTy, oldAlias, oldArrays := l.env, l.envTy, l.fnAliases, l.localArrays
		l.env = cloneMap(l.env)
		l.envTy = maps.Clone(l.envTy)
		l.fnAliases = maps.Clone(l.fnAliases)
		l.localArrays = maps.Clone(l.localArrays)
		for i := len(l.scopeRestores) - 1; i >= ctx.scopeDepth; i-- {
			l.scopeRestores[i]()
		}
		defer func() { l.env = oldEnv; l.envTy = oldTy; l.fnAliases = oldAlias; l.localArrays = oldArrays }()
		if ctx.continueStep != nil {
			l.lowerStmt(ctx.continueStep)
		}
		args := l.collectArgs(ctx.mutated)
		l.bld.Jmp(ctx.headLabel, args...)
		return true // continue is a terminator

	case *SwitchStmt:
		l.lowerSwitch(st)
		return false

	case *LabelStmt:
		blkLabel := "label_" + st.Name

		if l.backwardGotoLabels[st.Name] {
			// Backward-goto target: thread all current env vars through block params.
			// This is analogous to a loop_head block.
			varNames := sortedKeys(mapToBool(l.env), l.env)
			l.backwardGotoVars[st.Name] = varNames

			// Jump to label block with current values.
			args := l.collectArgs(varNames)
			if !l.bld.Cur.IsSealed() {
				l.bld.Jmp(blkLabel, args...)
			}

			// Switch to the pre-created label block and add block params.
			for _, blk := range l.bld.F.Blocks {
				if blk.Label == blkLabel {
					l.bld.SwitchTo(blk)
					break
				}
			}
			newEnv := cloneMap(l.env)
			for _, name := range varNames {
				ty := l.envTy[name]
				r := l.bld.BlockParam(l.bld.Cur, ty, classForExpr(ty))
				newEnv[name] = r
			}
			l.env = newEnv
		} else {
			// Forward-goto target: no block params needed.
			if !l.bld.Cur.IsSealed() {
				l.bld.Jmp(blkLabel)
			}
			for _, blk := range l.bld.F.Blocks {
				if blk.Label == blkLabel {
					l.bld.SwitchTo(blk)
					break
				}
			}
		}
		return false

	case *GotoStmt:
		target := "label_" + st.Label
		if l.backwardGotoLabels[st.Label] {
			// Backward goto: pass current env values as block args.
			varNames := l.backwardGotoVars[st.Label]
			args := l.collectArgs(varNames)
			l.bld.Jmp(target, args...)
		} else {
			l.bld.Jmp(target)
		}
		return true // goto is a terminator

	default:
		panic(fmt.Sprintf("hir/lower: unhandled statement type %T", s))
	}
}

// ── If/else lowering (two-pass) ───────────────────────────────────────────────

// lowerIf lowers an IfStmt using a two-pass approach:
//
//	Pass 1: scan for mutations in each branch.
//	Pass 2: emit MIR2 with correct Jmp args to the join block.
//
// Cases:
//
//	(a) Both branches always return → no join block, returns true.
//	(b) Neither/one branch returns → join block collects updated vars as params.
func (l *lowerer) lowerIf(st *IfStmt) bool {
	envBefore := cloneMap(l.env)

	// Scan branches for mutations (variables that existed before and are written).
	thenMuts := scanMutations(st.Then, envBefore)
	elseMuts := map[string]bool{}
	if st.Else != nil {
		elseMuts = scanMutations(st.Else, envBefore)
	}

	// Union of mutated vars (stable iteration order via sort).
	mutated := unionKeys(thenMuts, elseMuts, envBefore)

	thenLabel := l.fresh("if_then")
	joinLabel := l.fresh("if_join")

	hasElse := st.Else != nil
	elseLabel := ""
	if hasElse {
		elseLabel = l.fresh("if_else")
	}

	// For no-else ifs, pre-collect envBefore values for the false edge args.
	// We must do this BEFORE emitting any new instructions so the regs are
	// the current values (not post-then).
	var falseEdgeArgs []mir2.Reg
	if !hasElse {
		falseEdgeArgs = l.collectArgs(mutated)
	}

	// Emit the branch.
	condReg := l.lowerCond(st.Cond)
	if hasElse {
		l.bld.BrIf(condReg, thenLabel, nil, elseLabel, nil)
	} else {
		// No else: false edge goes to join with the current (pre-then) values
		// of mutated vars.  The true (then) edge will jump to join with the
		// post-mutation values.  The join block will have block params for each
		// mutated var that receives from both paths.
		l.bld.BrIf(condReg, thenLabel, nil, joinLabel, falseEdgeArgs)
	}

	// ── then branch ──
	l.bld.SwitchToNewBlock(thenLabel)
	l.env = cloneMap(envBefore)
	thenReturns := l.lowerBlock(st.Then)
	envAfterThen := cloneMap(l.env)
	if !thenReturns {
		args := l.collectArgs(mutated)
		l.bld.Jmp(joinLabel, args...)
	}

	// ── else branch ──
	var elseReturns bool
	envAfterElse := envBefore
	if hasElse {
		l.bld.SwitchToNewBlock(elseLabel)
		l.env = cloneMap(envBefore)
		elseReturns = l.lowerBlock(st.Else)
		envAfterElse = cloneMap(l.env)
		if !elseReturns {
			args := l.collectArgs(mutated)
			l.bld.Jmp(joinLabel, args...)
		}
	}

	// Both branches returned → no join.
	if thenReturns && elseReturns {
		return true
	}

	// ── join block ──
	join := l.bld.SwitchToNewBlock(joinLabel)

	// Determine the post-join environment.
	//
	// Any live branch that reaches the join has emitted a Jmp (or BrIf
	// false-edge) with len(mutated) args.  The join block must therefore
	// have a BlockParam for every mutated variable whenever at least one
	// incoming edge carries args.
	//
	// Cases:
	//   (a) Both paths live (hasElse, !thenReturns, !elseReturns)
	//       → both supplied Jmp args, create params.
	//   (b) No else (!hasElse, !thenReturns)
	//       → then-Jmp + BrIf false-edge both supply args, create params.
	//   (c) Only then returned (thenReturns, hasElse, !elseReturns)
	//       → else-Jmp supplies args, create params.  Env = else's env
	//         projected through the params.
	//   (d) Only else returned (!thenReturns, elseReturns, hasElse)
	//       → then-Jmp supplies args, create params.  Env = then's env
	//         projected through the params.
	//   (e) Only then returned, no else (thenReturns, !hasElse)
	//       → BrIf false-edge supplies args, create params.
	joinEnv := cloneMap(envBefore)
	if len(mutated) > 0 {
		for _, name := range mutated {
			ty := l.envTy[name]
			r := l.bld.BlockParam(join, ty, classForExpr(ty))
			joinEnv[name] = r
		}
	}

	_ = envAfterThen
	_ = envAfterElse
	l.env = joinEnv
	return false
}

// ── While loop lowering ───────────────────────────────────────────────────────

// lowerWhile lowers a WhileStmt.
//
// Generated MIR2 structure (loopVars = all env vars used or mutated in the loop):
//
//	jmp @loop_head(init_vals...)
//	loop_head(v1, v2, ...):
//	    cond = lower(while.Cond)
//	    brif cond @loop_body @loop_exit(v1, v2, ...)
//	loop_body:
//	    lower(while.Body)  — directly uses head block's vregs
//	    jmp @loop_head(updated_v1, updated_v2, ...)
//	loop_exit(v1, v2, ...):
//	    ; continue with exit env
//
// Note: loop_body has no block params — it uses head's vregs directly
// (valid because head dominates body).  Only head and exit get block params.
//
// loopVars includes BOTH mutated AND read-only variables used in the loop.
// Read-only vars (like n in "while i < n") must be threaded through as block
// params to prevent A/other registers from being clobbered and lost between
// loop-head visits.
func (l *lowerer) lowerWhile(st *WhileStmt) {
	l.lowerWhileWithContinue(st, nil)
}

// A desugared range loop must run its increment even when the body continues.
func (l *lowerer) lowerWhileWithContinue(st *WhileStmt, continueStep Stmt) {
	envBefore := cloneMap(l.env)

	// Collect ALL env vars used (read or written) anywhere in the loop.
	allUsed := map[string]bool{}
	scanUsedExpr(st.Cond, envBefore, allUsed)
	scanUsedInBlock(st.Body, envBefore, allUsed)
	// Also include mutated vars (even if somehow not "used" in expressions).
	muts := scanMutations(st.Body, envBefore)
	for name := range muts {
		allUsed[name] = true
	}
	mutated := sortedKeys(allUsed, envBefore)

	headLabel := l.fresh("loop_head")
	bodyLabel := l.fresh("loop_body")
	exitLabel := l.fresh("loop_exit")

	// Jump to loop head with initial values.
	initArgs := l.collectArgs(mutated)
	l.bld.Jmp(headLabel, initArgs...)

	// ── loop_head ──
	head := l.bld.SwitchToNewBlock(headLabel)
	if source, ok := l.lineage[st]; ok {
		if l.mf.LoopOrigins == nil {
			l.mf.LoopOrigins = map[string]mir2.LoopOrigin{}
		}
		l.mf.LoopOrigins[bodyLabel] = mir2.LoopOrigin{SiteID: source.SiteID, Role: source.Role, Rule: source.Rule}
	}
	headEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		r := l.bld.BlockParam(head, ty, classForLoop(ty, name))
		headEnv[name] = r
	}
	l.env = headEnv

	prevInLoopCtx := l.inLoopContext
	l.inLoopContext = true
	cond := l.lowerCond(st.Cond)
	// True → body (no block params on body, no args needed).
	// False → exit (with block params, pass current head-env values).
	exitArgs := l.collectArgs(mutated)
	l.bld.BrIf(cond, bodyLabel, nil, exitLabel, exitArgs)

	// ── loop_body ──
	l.bld.SwitchToNewBlock(bodyLabel)
	l.env = cloneMap(headEnv) // body directly uses head's vregs
	l.pushLoop(loopCtx{headLabel: headLabel, exitLabel: exitLabel, mutated: mutated, continueStep: continueStep})
	terminated := l.lowerBlock(st.Body)
	l.popLoop()
	l.inLoopContext = prevInLoopCtx
	// A return, break or continue already sealed the current body block.
	if !terminated {
		backArgs := l.collectArgs(mutated)
		l.bld.Jmp(headLabel, backArgs...)
	}

	// ── loop_exit ──
	exit := l.bld.SwitchToNewBlock(exitLabel)
	exitEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		r := l.bld.BlockParam(exit, ty, classForExpr(ty))
		exitEnv[name] = r
	}
	l.env = exitEnv
}

// saveLexicalName restores one loop binder without discarding outer mutations.
func (l *lowerer) saveLexicalName(name string) func() {
	r, rok := l.env[name]
	ty, tok := l.envTy[name]
	a, aok := l.fnAliases[name]
	arr := l.localArrays[name]
	return func() {
		if rok {
			l.env[name] = r
		} else {
			delete(l.env, name)
		}
		if tok {
			l.envTy[name] = ty
		} else {
			delete(l.envTy, name)
		}
		if aok {
			l.fnAliases[name] = a
		} else {
			delete(l.fnAliases, name)
		}
		if arr {
			l.localArrays[name] = true
		} else {
			delete(l.localArrays, name)
		}
	}
}

// lowerForRange desugars a ForRangeStmt to a while-equivalent.
// for v in start..end → v = start; hi = end; while v < hi { body; v++ }
//
// The upper bound is evaluated ONCE before the loop and bound to a synthetic
// variable __for_hi_N.  This prevents expressions like (n+1) from being
// re-evaluated as an ADD inside the loop header on every iteration, which
// would force 'n' into the A register as the ADD lhs and corrupt it via
// the body's scratch uses of A (loads, mul16 counter, etc.).
func (l *lowerer) lowerForRange(st *ForRangeStmt) {
	defer l.saveLexicalName(st.Var)()
	var ty mir2.Ty = mir2.TyU8
	if st.End != nil {
		ty = st.End.ExprTy()
	}
	initReg := l.lowerExpr(st.Start)

	// Precompute the loop upper bound once, outside the loop.
	endReg := l.lowerExpr(st.End)
	l.bind(st.Var, initReg, ty)
	endName := l.fresh("__for_hi_")
	defer l.saveLexicalName(endName)()
	l.bind(endName, endReg, ty)

	// Synthesise a WhileStmt: while v < hi { body; v = v + 1 }
	one := &IntLitExpr{Val: 1, Ty: ty}
	increment := &AssignStmt{
		Target: &VarRefExpr{Name: st.Var, Ty: ty},
		Val:    &BinExpr{Op: "+", L: &VarRefExpr{Name: st.Var, Ty: ty}, R: one, Ty: ty},
	}
	// Copy the slice: lowering must not overwrite the source HIR backing array.
	whileBody := &Block{Body: []Stmt{st.Body, increment}}
	synthetic := &WhileStmt{
		Cond: &BinExpr{Op: "<", L: &VarRefExpr{Name: st.Var, Ty: ty}, R: &VarRefExpr{Name: endName, Ty: ty}, Ty: mir2.TyBool},
		Body: whileBody,
	}
	if origin, ok := l.lineage[st]; ok {
		l.lineage[synthetic] = origin
	}
	l.lowerWhileWithContinue(synthetic, increment)
}

// lowerForEach lowers a ForEachStmt.
//
// Byte loops without control transfers use an initial zero-trip check and
// a DJNZ back-edge, whose first target parameter receives the decremented
// count. The counter class prefers B; codegen handles its actual allocation.
// Wide loops and bodies with control transfers retain the structure below:
//
//	entry:
//	    ptr0 = lower(Ptr) + Start * stride
//	    cnt0 = lower(Len)
//	    jmp @fe_head(ptr0, cnt0, ...mutated_init...)
//	fe_head(ptr, cnt, ...mutated...):
//	    cond = cnt != 0
//	    brif cond @fe_body @fe_exit(ptr, cnt, ...mutated...)
//	fe_body:
//	    x = Load(ptr, ElemTy)
//	    [body]
//	    ptr_next = PtrBump(ptr, stride)
//	    cnt_next = Sub(cnt, 1)
//	    jmp @fe_head(ptr_next, cnt_next, ...updated_mutated...)
//	fe_exit(ptr, cnt, ...mutated...):   -- ptr/cnt discarded
//	    [continue]
func (l *lowerer) lowerForEach(st *ForEachStmt) {
	defer l.saveLexicalName(st.Var)()
	envBefore := cloneMap(l.env)
	needsTrampoline := false
	walkGraceBlocks(st.Body, "", func(_ string, b *Block) {
		for _, s := range b.Body {
			switch s.(type) {
			case *ContinueStmt, *BreakStmt, *ReturnStmt, *GotoStmt, *LabelStmt:
				needsTrampoline = true
			}
		}
	})
	stride := int64(mir2.ByteWidth(st.ElemTy))
	if st.ElemStride > 0 {
		stride = int64(st.ElemStride)
	}
	if stride < 1 {
		stride = 1
	}

	// Compute initial pointer (with optional start offset).
	ptrReg := l.lowerExpr(st.Ptr)
	if st.Start != nil {
		startReg := l.lowerExpr(st.Start)
		if stride > 1 {
			factor := l.bld.Const(stride, mir2.TyU16, mir2.ClassPointer)
			startReg = l.bld.Mul(startReg, factor, mir2.TyU16, mir2.ClassIndex)
		}
		ptrReg = l.bld.PtrAdd(ptrReg, startReg, mir2.ClassPointer)
	}
	// Compute element count.
	cntReg := l.lowerExpr(st.Len)
	cntTy := st.Len.ExprTy()
	if cntTy == mir2.TyU8 && !needsTrampoline {
		l.lowerForEachByteCountdown(st, envBefore, ptrReg, cntReg, stride)
		return
	}

	cntClass := mir2.ClassCounter
	zeroClass := mir2.ClassAcc
	if cntTy.Width() > mir2.TyU8.Width() {
		// ClassCounter targets the byte register B. Wide lengths need a pair,
		// preferably DE so the element pointer can remain in HL.
		cntClass = mir2.ClassIndex
		zeroClass = cntClass
	}

	// Literal operands are loop-invariant for the general control-flow path.
	zero := l.bld.Const(0, cntTy, zeroClass)
	one := l.bld.Const(1, cntTy, cntClass)

	// Collect user env vars used/mutated in the body (for block params).
	allUsed := map[string]bool{}
	scanUsedInBlock(st.Body, envBefore, allUsed)
	muts := scanMutations(st.Body, envBefore)
	for name := range muts {
		allUsed[name] = true
	}
	// Don't thread the element variable itself (it's fresh each iteration).
	delete(allUsed, st.Var)
	mutated := sortedKeys(allUsed, envBefore)

	headLabel := l.fresh("fe_head")
	bodyLabel := l.fresh("fe_body")
	contLabel := l.fresh("fe_cont") // continue trampoline: advance ptr/cnt → head
	exitLabel := l.fresh("fe_exit")

	// Jump to loop head: (ptr, cnt, mutated...)
	initArgs := append([]mir2.Reg{ptrReg, cntReg}, l.collectArgs(mutated)...)
	l.bld.Jmp(headLabel, initArgs...)

	// ── fe_head(ptr, cnt, mutated...) ──
	head := l.bld.SwitchToNewBlock(headLabel)
	if source, ok := l.lineage[st]; ok {
		if l.mf.LoopOrigins == nil {
			l.mf.LoopOrigins = map[string]mir2.LoopOrigin{}
		}
		l.mf.LoopOrigins[bodyLabel] = mir2.LoopOrigin{SiteID: source.SiteID, Role: source.Role, Rule: source.Rule}
	}
	headPtr := l.bld.BlockParam(head, mir2.TyPtr, mir2.ClassPointer) // HL
	headCnt := l.bld.BlockParam(head, cntTy, cntClass)
	headEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		r := l.bld.BlockParam(head, ty, classForLoop(ty, name))
		headEnv[name] = r
	}
	l.env = headEnv

	// brif (cnt != 0) → body, else → exit
	cond := l.bld.Cmp(mir2.CmpNe, headCnt, zero, mir2.ClassFlag, false)
	exitArgs := append([]mir2.Reg{headPtr, headCnt}, l.collectArgs(mutated)...)
	l.bld.BrIf(cond, bodyLabel, nil, exitLabel, exitArgs)

	// ── fe_body ──
	l.bld.SwitchToNewBlock(bodyLabel)
	l.env = cloneMap(headEnv)

	// Load element: x = *ptr (or x = ptr for struct pointer iteration)
	if st.PtrIter {
		// Pointer iteration: x IS the pointer, not a loaded value
		l.bind(st.Var, headPtr, mir2.TyPtr)
	} else {
		xReg := l.bld.Load(headPtr, st.ElemTy, classForExpr(st.ElemTy))
		l.bind(st.Var, xReg, st.ElemTy)
	}

	// ContinueStmt jumps to fe_cont (not fe_head) so ptr/cnt are advanced first.
	prevInLoopCtx2 := l.inLoopContext
	l.inLoopContext = true
	l.pushLoop(loopCtx{headLabel: contLabel, exitLabel: exitLabel, mutated: mutated, exitPrefix: []mir2.Reg{headPtr, headCnt}})
	terminated := l.lowerBlock(st.Body)
	l.popLoop()
	l.inLoopContext = prevInLoopCtx2

	// mapInPlace: store the (possibly transformed) element value back to ptr.
	if st.MutateInPlace && !terminated {
		if finalVal, ok := l.env[st.Var]; ok {
			l.bld.Store(headPtr, finalVal, st.ElemTy)
		}
	}

	// Continue needs an increment trampoline; retain it for other control
	// transfers too. Ordinary fall-through bodies increment directly.
	if needsTrampoline {
		// Only fall-through reaches the trampoline through this edge.
		if !terminated {
			l.bld.Jmp(contLabel, l.collectArgs(mutated)...)
		}

		// ── fe_cont(mutated...) — advance ptr/cnt, back-edge to fe_head ──
		// This is the target for ContinueStmt inside the body, as well as the
		// normal fall-through path. It advances ptr/cnt (using headPtr/headCnt
		// which dominate this block) and loops back.
		cont := l.bld.SwitchToNewBlock(contLabel)
		contEnv := cloneMap(headEnv)
		for _, name := range mutated {
			ty := l.envTy[name]
			r := l.bld.BlockParam(cont, ty, classForExpr(ty))
			contEnv[name] = r
		}
		l.env = contEnv
	}

	ptrNext := l.bld.PtrBump(headPtr, stride, mir2.ClassPointer)
	cntNext := l.bld.Sub(headCnt, one, cntTy, cntClass)

	backArgs := append([]mir2.Reg{ptrNext, cntNext}, l.collectArgs(mutated)...)
	l.bld.Jmp(headLabel, backArgs...)

	// ── fe_exit(ptr, cnt, mutated...) ──
	exit := l.bld.SwitchToNewBlock(exitLabel)
	l.bld.BlockParam(exit, mir2.TyPtr, mir2.ClassPointer) // discard ptr
	l.bld.BlockParam(exit, cntTy, cntClass)               // discard cnt
	exitEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		r := l.bld.BlockParam(exit, ty, classForExpr(ty))
		exitEnv[name] = r
	}
	// Element var goes out of scope.
	l.env = exitEnv
}

// Byte fall-through bodies need only one zero-trip check. DJNZ decrements
// the counter on the back-edge, so no zero/one values remain live in the body.
// Bodies with control transfers retain the general trampoline implementation.
func (l *lowerer) lowerForEachByteCountdown(st *ForEachStmt, envBefore map[string]mir2.Reg, ptrReg, cntReg mir2.Reg, stride int64) {
	allUsed := map[string]bool{}
	scanUsedInBlock(st.Body, envBefore, allUsed)
	for name := range scanMutations(st.Body, envBefore) {
		allUsed[name] = true
	}
	delete(allUsed, st.Var)
	mutated := sortedKeys(allUsed, envBefore)
	bodyLabel, exitLabel := l.fresh("fe_body"), l.fresh("fe_exit")
	zero := l.bld.Const(0, mir2.TyU8, mir2.ClassAcc)
	nonzero := l.bld.Cmp(mir2.CmpNe, cntReg, zero, mir2.ClassFlag, false)
	initial := append([]mir2.Reg{cntReg, ptrReg}, l.collectArgs(mutated)...)
	l.bld.BrIf(nonzero, bodyLabel, initial, exitLabel, l.collectArgs(mutated))
	body := l.bld.SwitchToNewBlock(bodyLabel)
	if origin, ok := l.lineage[st]; ok {
		if l.mf.LoopOrigins == nil {
			l.mf.LoopOrigins = map[string]mir2.LoopOrigin{}
		}
		l.mf.LoopOrigins[bodyLabel] = mir2.LoopOrigin{SiteID: origin.SiteID, Role: origin.Role, Rule: origin.Rule}
	}
	cnt := l.bld.BlockParam(body, mir2.TyU8, mir2.ClassCounter)
	ptr := l.bld.BlockParam(body, mir2.TyPtr, mir2.ClassPointer)
	env := cloneMap(envBefore)
	for _, name := range mutated {
		env[name] = l.bld.BlockParam(body, l.envTy[name], classForLoop(l.envTy[name], name))
	}
	l.env = env
	if st.PtrIter {
		l.bind(st.Var, ptr, mir2.TyPtr)
	} else {
		l.bind(st.Var, l.bld.Load(ptr, st.ElemTy, classForExpr(st.ElemTy)), st.ElemTy)
	}
	previous := l.inLoopContext
	l.inLoopContext = true
	l.lowerBlock(st.Body)
	l.inLoopContext = previous
	if st.MutateInPlace {
		if final, ok := l.env[st.Var]; ok {
			l.bld.Store(ptr, final, st.ElemTy)
		}
	}
	ptrNext := l.bld.PtrBump(ptr, stride, mir2.ClassPointer)
	updates := l.collectArgs(mutated)
	back := append([]mir2.Reg{ptrNext}, updates...)
	l.bld.DJNZ(cnt, bodyLabel, back, exitLabel, updates)
	exit := l.bld.SwitchToNewBlock(exitLabel)
	env = cloneMap(envBefore)
	for _, name := range mutated {
		env[name] = l.bld.BlockParam(exit, l.envTy[name], classForExpr(l.envTy[name]))
	}
	l.env = env
}

// ── Switch lowering ───────────────────────────────────────────────────────────

// lowerSwitch lowers a SwitchStmt to a chain of BrIf2 comparisons.
//
// Generated MIR2 structure for switch v { case 1: b1; case 2: b2; default: bd }:
//
//	%v = lower(val)
//	brif2 %v == 1 → case1 | next1
//	next1: brif2 %v == 2 → case2 | default
//	case1: lower(b1); jmp join
//	case2: lower(b2); jmp join
//	default: lower(bd); jmp join
//	join: ...
//
// For variables mutated in any case, join block receives them as block params.
func (l *lowerer) lowerSwitch(st *SwitchStmt) {
	envBefore := cloneMap(l.env)

	// Collect all mutations across all case bodies.
	allMuts := map[string]bool{}
	for _, c := range st.Cases {
		for name := range scanMutations(c.Body, envBefore) {
			allMuts[name] = true
		}
	}
	if st.Default != nil {
		for name := range scanMutations(st.Default, envBefore) {
			allMuts[name] = true
		}
	}
	mutated := sortedKeys(allMuts, envBefore)

	joinLabel := l.fresh("sw_join")
	defaultLabel := joinLabel // if no default, fall through to join
	if st.Default != nil {
		defaultLabel = l.fresh("sw_default")
	}

	// Generate case labels.
	caseLabels := make([]string, len(st.Cases))
	for i := range st.Cases {
		caseLabels[i] = l.fresh("sw_case")
	}
	nextLabels := make([]string, len(st.Cases))
	for i := range st.Cases {
		if i+1 < len(st.Cases) {
			nextLabels[i] = l.fresh("sw_next")
		} else {
			nextLabels[i] = defaultLabel
		}
	}

	valReg := l.lowerExpr(st.Val)
	valTy := st.Val.ExprTy()

	// Emit dispatch chain: for each case emit cmp(val==caseN) → brif → caseN / nextN.
	for i, c := range st.Cases {
		imm := l.bld.Const(c.Val, valTy, mir2.ClassGeneral)
		cond := l.bld.Cmp(mir2.CmpEq, valReg, imm, mir2.ClassFlag, false)
		l.bld.BrIf(cond, caseLabels[i], nil, nextLabels[i], nil)
		if i+1 < len(st.Cases) {
			l.bld.SwitchToNewBlock(nextLabels[i])
		}
	}

	// Push switch as a "loop" context so that break inside case bodies
	// jumps to joinLabel (C semantics: break exits the switch).
	l.pushLoop(loopCtx{headLabel: "", exitLabel: joinLabel, mutated: mutated})

	// Emit case bodies.
	var envsFinal []map[string]mir2.Reg
	for i, c := range st.Cases {
		l.bld.SwitchToNewBlock(caseLabels[i])
		l.env = cloneMap(envBefore)
		done := l.lowerBlock(c.Body)
		if !done {
			envsFinal = append(envsFinal, cloneMap(l.env))
			l.bld.Jmp(joinLabel, l.collectArgs(mutated)...)
		}
	}

	// Default body.
	if st.Default != nil {
		l.bld.SwitchToNewBlock(defaultLabel)
		l.env = cloneMap(envBefore)
		done := l.lowerBlock(st.Default)
		if !done {
			envsFinal = append(envsFinal, cloneMap(l.env))
			l.bld.Jmp(joinLabel, l.collectArgs(mutated)...)
		}
	}

	l.popLoop()

	// Join block: only reachable if at least one case (or default) fell through.
	joinReachable := len(envsFinal) > 0
	join := l.bld.SwitchToNewBlock(joinLabel)
	if !joinReachable {
		// All paths returned → join is dead; emit Unreachable so Verify passes.
		l.bld.Unreachable()
		l.env = cloneMap(envBefore)
		return
	}
	joinEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		r := l.bld.BlockParam(join, ty, classForExpr(ty))
		joinEnv[name] = r
	}
	_ = join
	l.env = joinEnv
}

// ── Expression lowering ───────────────────────────────────────────────────────

// lowerExprAs promotes narrow literals and sign-extends signed operands
// to the expression width. This also handles C integer promotions.
func (l *lowerer) lowerExprAs(e Expr, wantTy mir2.Ty) mir2.Reg {
	if lit, ok := e.(*IntLitExpr); ok && lit.Ty != wantTy && lit.Ty.Width() < wantTy.Width() {
		return l.bld.Const(lit.Val, wantTy, classForExpr(wantTy))
	}
	src := l.lowerExpr(e)
	srcTy := e.ExprTy()
	if mir2.IsInt(srcTy) && mir2.IsInt(wantTy) && srcTy.Width() < wantTy.Width() {
		if mir2.IsSigned(srcTy) {
			return l.bld.Sext(src, srcTy, wantTy, classForExpr(wantTy))
		}
		return l.bld.Ext(src, srcTy, wantTy, classForExpr(wantTy))
	}
	return src
}

// lowerExpr lowers an expression to the register holding its value.
func (l *lowerer) lowerExpr(e Expr) mir2.Reg {
	switch ex := e.(type) {

	case *IntLitExpr:
		return l.bld.Const(ex.Val, ex.Ty, classForExpr(ex.Ty))

	case *BoolLitExpr:
		v := int64(0)
		if ex.Val {
			v = 1
		}
		return l.bld.Const(v, mir2.TyBool, mir2.ClassGeneral)

	case *VarRefExpr:
		r, ok := l.env[ex.Name]
		if !ok {
			// Check if it's a function alias (let f = |x| ...).
			if _, isAlias := l.fnAliases[ex.Name]; isAlias {
				return mir2.NoReg // function reference — resolved at call site
			}
			// Check if it's a module-level function name used as a value.
			if l.hirFuncNames[ex.Name] {
				return mir2.NoReg // function reference — resolved at call site
			}
			// Check if it's a global variable.
			if g, found := l.findGlobal(ex.Name); found {
				addr := l.globalAddr(ex.Name)
				if _, isStruct := g.Ty.(*mir2.StructTy); isStruct {
					// Struct global: return the address (pointer to struct).
					// FieldExpr uses this address as base for offset computation.
					return addr
				}
				if _, isArray := g.Ty.(*mir2.ArrayTy); isArray {
					// Array global: return the address (pointer to first element).
					// IndexExpr uses this address as base for ptr_add.
					return addr
				}
				// Scalar global: load and return the value.
				return l.bld.Load(addr, g.Ty, classForExpr(g.Ty))
			}
			panic(fmt.Sprintf("hir/lower: undefined variable %q", ex.Name))
		}
		return r

	case *BinExpr:
		return l.lowerBinExpr(ex)

	case *UnaryExpr:
		return l.lowerUnaryExpr(ex)

	case *CallExpr:
		// @target() intrinsic — returns compile-time platform constant
		if ex.Fn == "@target" {
			return l.bld.Const(int64(l.target), mir2.TyU8, mir2.ClassGeneral)
		}

		// Resolve function name: may be a direct name, a local alias (let f = |x| ...), or
		// a module-level function reference.
		fnName := ex.Fn
		if alias, ok := l.fnAliases[fnName]; ok {
			fnName = alias
		}

		args := make([]mir2.Reg, len(ex.Args))
		for i, a := range ex.Args {
			r := l.lowerExpr(a)
			// Coerce arg to its calling-convention register class.
			// E.g. arg[0] must be in ClassAcc (A), but classForExpr returns
			// ClassGeneral for safety.  Emit an explicit Move so the allocator
			// puts the value in the right physical register.
			tgtCls := classForParam(a.ExprTy(), i)
			if tgtCls != classForExpr(a.ExprTy()) {
				r = l.bld.Move(r, a.ExprTy(), tgtCls)
			}
			args[i] = r
		}
		if ex.Ty == mir2.TyVoid {
			l.bld.CallVoid(fnName, args, mir2.CallAttrs{})
			return mir2.NoReg
		}
		cls := classForRet(ex.Ty)
		return l.bld.Call(fnName, args, ex.Ty, cls, mir2.CallAttrs{})

	case *CallIndirectExpr:
		// A local name bound to a known lambda/partial application has a
		// compile-time target. Call it directly; no runtime closure is needed.
		if vr, ok := ex.FnPtr.(*VarRefExpr); ok {
			if fnName, found := l.fnAliases[vr.Name]; found {
				return l.lowerExpr(&CallExpr{Fn: fnName, Args: ex.Args, Ty: ex.Ty})
			}
		}
		fnPtrReg := l.lowerExpr(ex.FnPtr)
		args := make([]mir2.Reg, len(ex.Args))
		for i, a := range ex.Args {
			r := l.lowerExpr(a)
			tgtCls := classForParam(a.ExprTy(), i)
			if tgtCls != classForExpr(a.ExprTy()) {
				r = l.bld.Move(r, a.ExprTy(), tgtCls)
			}
			args[i] = r
		}
		cls := classForRet(ex.Ty)
		return l.bld.CallIndirect(fnPtrReg, args, ex.Ty, cls)

	case *AddrOfExpr:
		if ex.X != nil {
			return l.lowerExprAddr(ex.X)
		}
		// Local array promoted to global: env register IS the address.
		if l.localArrays[ex.Sym] {
			if reg, ok := l.env[ex.Sym]; ok {
				return reg
			}
		}
		return l.bld.AddrOf(ex.Sym, mir2.ClassPointer)

	case *ConstPtrExpr:
		return l.bld.Const(int64(ex.Addr), mir2.TyPtr, mir2.ClassPointer)

	case *LoadExpr:
		ptr := l.lowerExpr(ex.Ptr)
		cls := classForExpr(ex.Ty)
		return l.bld.Load(ptr, ex.Ty, cls)

	case *FieldExpr:
		base := l.lowerExpr(ex.X)
		// Advance pointer by field offset.
		if ex.Offset > 0 {
			base = l.bld.Field(base, int64(ex.Offset), mir2.ClassPointer)
		}
		// Embedded struct field: return address, don't load.
		// The outer FieldExpr/IndexExpr will do the final scalar Load.
		if _, isStruct := ex.Ty.(*mir2.StructTy); isStruct {
			return base
		}
		return l.bld.Load(base, ex.Ty, classForExpr(ex.Ty))

	case *BitExpr:
		return l.lowerBitRead(ex)

	case *CastExpr:
		src := l.lowerExpr(ex.X)
		srcTy := ex.X.ExprTy()
		dstTy := ex.Ty
		sw, dw := srcTy.Width(), dstTy.Width()
		switch {
		case dw > sw:
			if mir2.IsSigned(srcTy) {
				return l.bld.Sext(src, srcTy, dstTy, classForExpr(dstTy))
			}
			return l.bld.Ext(src, srcTy, dstTy, classForExpr(dstTy))
		case dw < sw:
			return l.bld.Trunc(src, srcTy, dstTy, classForExpr(dstTy))
		default:
			return src // same width → no-op
		}

	case *IndexExpr:
		return l.lowerIndex(ex)

	case *StructLitExpr:
		return l.lowerStructLitAlloca(ex)

	case *CondExpr:
		return l.lowerCondExpr(ex)

	case *LetInExpr:
		// Lower init, bind the result to the variable name, then lower body.
		initReg := l.lowerExpr(ex.Init)
		l.env[ex.Name] = initReg
		l.envTy[ex.Name] = ex.Ty
		return l.lowerExpr(ex.Body)

	default:
		panic(fmt.Sprintf("hir/lower: unhandled expression type %T", e))
	}
}

// lowerIndexAddr lowers arr[i] → ptr_add(base, i * stride), returning the
// pointer register (TyPtr).  Used by StoreStmt which needs the address, not
// the loaded value.
//
// stride = ElemStride if set; otherwise ElemTy.Width()/8 (rounded up to 1).
func (l *lowerer) lowerIndexAddr(ex *IndexExpr) mir2.Reg {
	base := l.lowerExpr(ex.Base)
	idx := l.lowerExpr(ex.Idx)

	stride := ex.ElemStride
	if stride == 0 {
		w := ex.ElemTy.Width()
		stride = (w + 7) / 8
		if stride == 0 {
			stride = 1
		}
	}

	var offset mir2.Reg
	idxTy := ex.Idx.ExprTy()
	switch stride {
	case 1:
		if idxTy.Width() <= 8 {
			offset = l.bld.Ext(idx, idxTy, mir2.TyU16, mir2.ClassIndex)
		} else {
			offset = idx
		}
	case 2:
		if idxTy.Width() <= 8 {
			idx = l.bld.Ext(idx, idxTy, mir2.TyU16, mir2.ClassIndex)
		}
		one := l.bld.Const(1, mir2.TyU16, mir2.ClassGeneral)
		offset = l.bld.Shl(idx, one, mir2.TyU16, mir2.ClassIndex)
	default:
		if idxTy.Width() <= 8 {
			idx = l.bld.Ext(idx, idxTy, mir2.TyU16, mir2.ClassIndex)
		}
		strideReg := l.bld.Const(int64(stride), mir2.TyU16, mir2.ClassGeneral)
		offset = l.bld.Mul(idx, strideReg, mir2.TyU16, mir2.ClassIndex)
	}

	return l.bld.PtrAdd(base, offset, mir2.ClassPointer)
}

// lowerIndex lowers arr[i] → ptr_add(base, i * stride) → load.
func (l *lowerer) lowerIndex(ex *IndexExpr) mir2.Reg {
	ptr := l.lowerIndexAddr(ex)
	// Struct element: return address, don't load.
	// The outer FieldExpr will do the final scalar Load.
	if _, isStruct := ex.ElemTy.(*mir2.StructTy); isStruct {
		return ptr
	}
	return l.bld.Load(ptr, ex.ElemTy, classForExpr(ex.ElemTy))
}

// lowerCondExpr lowers: if Cond { Then } else { Else }  →  result register.
// Emits a BrIf to a then-block and an else-block, both converging at a join
// block with a block parameter that carries the result value.
func (l *lowerer) lowerCondExpr(ex *CondExpr) mir2.Reg {
	cond := l.lowerCond(ex.Cond)
	cls := classForExpr(ex.Ty)

	thenLabel := l.fresh("cond_then")
	elseLabel := l.fresh("cond_else")
	joinLabel := l.fresh("cond_join")

	l.bld.BrIf(cond, thenLabel, nil, elseLabel, nil)

	// then-branch
	thenBlk := l.bld.SwitchToNewBlock(thenLabel)
	_ = thenBlk
	thenVal := l.lowerExpr(ex.Then)
	l.bld.Jmp(joinLabel, thenVal)

	// else-branch
	elseBlk := l.bld.SwitchToNewBlock(elseLabel)
	_ = elseBlk
	elseVal := l.lowerExpr(ex.Else)
	l.bld.Jmp(joinLabel, elseVal)

	// join block: a block parameter receives the value from whichever branch
	joinBlk := l.bld.SwitchToNewBlock(joinLabel)
	result := l.bld.BlockParam(joinBlk, ex.Ty, cls)
	return result
}

// lowerBinExpr lowers a binary expression.
func (l *lowerer) lowerBinExpr(ex *BinExpr) mir2.Reg {
	// Comparison operators → produce a flag (ClassFlag).
	switch ex.Op {
	case "==", "!=", "<", "<=", ">", ">=":
		return l.lowerCond(ex)
	case "&&", "||":
		return l.lowerLogical(ex)
	}

	ty := ex.Ty
	// Use ClassAcc for 8-bit ALU results outside loop contexts — Z80 ALU ops
	// always write to A, avoiding a spurious LD C,A.  Inside loops (head
	// condition or body) values may be loop-carried or live across ALU ops
	// that transiently clobber A, so fall back to ClassGeneral.
	var cls mir2.RegClass
	if !l.inLoopContext {
		cls = classForALUResult(ex.Op, ty)
	} else {
		cls = classForExpr(ty)
	}
	// Type-widen integer literals to match the expression result type.
	// e.g. "0 - r" where r:u16 parses literal 0 as u8; promote to u16 so
	// the codegen sees a 16-bit const, not an 8-bit one.
	lReg := l.lowerExprAs(ex.L, ty)
	rReg := l.lowerExprAs(ex.R, ty)

	switch ex.Op {
	case "+":
		return l.bld.Add(lReg, rReg, ty, cls)
	case "-":
		return l.bld.Sub(lReg, rReg, ty, cls)
	case "*":
		return l.bld.Mul(lReg, rReg, ty, cls)
	case "/":
		if mir2.IsSigned(ty) {
			return l.bld.SDiv(lReg, rReg, ty, cls)
		}
		return l.bld.Div(lReg, rReg, ty, cls)
	case "%":
		if mir2.IsSigned(ty) {
			return l.bld.SMod(lReg, rReg, ty, cls)
		}
		return l.bld.Mod(lReg, rReg, ty, cls)
	case "&":
		return l.bld.And(lReg, rReg, ty, cls)
	case "|":
		return l.bld.Or(lReg, rReg, ty, cls)
	case "^":
		return l.bld.Xor(lReg, rReg, ty, cls)
	case "<<":
		return l.bld.Shl(lReg, rReg, ty, cls)
	case ">>":
		if mir2.IsSigned(ex.L.ExprTy()) {
			return l.bld.Sar(lReg, rReg, ty, cls)
		}
		return l.bld.Shr(lReg, rReg, ty, cls)
	default:
		panic(fmt.Sprintf("hir/lower: unhandled binary op %q", ex.Op))
	}
}

// lowerLogical preserves short-circuit evaluation and yields a canonical bool.
// The false/true blocks keep flag registers out of the join's block argument.
func (l *lowerer) lowerLogical(ex *BinExpr) mir2.Reg {
	rhsLabel := l.fresh("logic_rhs")
	trueLabel := l.fresh("logic_true")
	falseLabel := l.fresh("logic_false")
	joinLabel := l.fresh("logic_join")

	left := l.lowerCond(ex.L)
	if ex.Op == "&&" {
		l.bld.BrIf(left, rhsLabel, nil, falseLabel, nil)
	} else {
		l.bld.BrIf(left, trueLabel, nil, rhsLabel, nil)
	}
	l.bld.SwitchToNewBlock(rhsLabel)
	right := l.lowerCond(ex.R)
	l.bld.BrIf(right, trueLabel, nil, falseLabel, nil)

	l.bld.SwitchToNewBlock(trueLabel)
	one := l.bld.Const(1, mir2.TyBool, mir2.ClassGeneral)
	l.bld.Jmp(joinLabel, one)
	l.bld.SwitchToNewBlock(falseLabel)
	zero := l.bld.Const(0, mir2.TyBool, mir2.ClassGeneral)
	l.bld.Jmp(joinLabel, zero)
	join := l.bld.SwitchToNewBlock(joinLabel)
	return l.bld.BlockParam(join, mir2.TyBool, mir2.ClassGeneral)
}

// lowerUnaryExpr lowers a unary expression.
func (l *lowerer) lowerUnaryExpr(ex *UnaryExpr) mir2.Reg {
	xReg := l.lowerExpr(ex.X)
	ty := ex.Ty
	var cls mir2.RegClass
	if !l.inLoopContext {
		cls = classForALUResult(ex.Op, ty)
	} else {
		cls = classForExpr(ty)
	}
	switch ex.Op {
	case "-":
		return l.bld.Neg(xReg, ty, cls)
	case "~":
		return l.bld.Not(xReg, ty, cls)
	case "!":
		// Boolean not: x == 0
		zero := l.bld.Const(0, ty, mir2.ClassGeneral)
		return l.bld.Cmp(mir2.CmpEq, xReg, zero, mir2.ClassFlag, false)
	default:
		panic(fmt.Sprintf("hir/lower: unhandled unary op %q", ex.Op))
	}
}

// lowerCond lowers a condition expression and returns a ClassFlag vreg.
// Handles comparison ops directly; for non-bool expressions wraps in != 0.
// For ordering comparisons (<, <=, >, >=), picks signed or unsigned CmpCond
// based on the operand type: i8/i16 → signed (CmpLt etc.), u8/u16 → unsigned (CmpUlt etc.).
// Eq/Ne are sign-agnostic (bit patterns match regardless of interpretation).
func (l *lowerer) lowerCond(e Expr) mir2.Reg {
	if bin, ok := e.(*BinExpr); ok {
		if bin.Op == "&&" || bin.Op == "||" {
			return l.lowerLogical(bin)
		}
		var cmp mir2.CmpCond
		signed := mir2.IsSigned(bin.L.ExprTy())
		switch bin.Op {
		case "==":
			cmp = mir2.CmpEq
		case "!=":
			cmp = mir2.CmpNe
		case "<":
			if signed {
				cmp = mir2.CmpLt
			} else {
				cmp = mir2.CmpUlt
			}
		case "<=":
			if signed {
				cmp = mir2.CmpLe
			} else {
				cmp = mir2.CmpUle
			}
		case ">":
			if signed {
				cmp = mir2.CmpGt
			} else {
				cmp = mir2.CmpUgt
			}
		case ">=":
			if signed {
				cmp = mir2.CmpGe
			} else {
				cmp = mir2.CmpUge
			}
		default:
			goto fallback
		}
		lReg := l.lowerExpr(bin.L)
		rReg := l.lowerExpr(bin.R)
		if signed {
			return l.bld.CmpWithSrcTy(cmp, lReg, rReg, mir2.ClassFlag, false, bin.L.ExprTy())
		}
		return l.bld.Cmp(cmp, lReg, rReg, mir2.ClassFlag, false)
	}
fallback:
	// Treat expr as a bool: cond != 0
	r := l.lowerExpr(e)
	zero := l.bld.Const(0, e.ExprTy(), mir2.ClassGeneral)
	return l.bld.Cmp(mir2.CmpNe, r, zero, mir2.ClassFlag, false)
}

// ── Environment helpers ───────────────────────────────────────────────────────

func cloneMap(m map[string]mir2.Reg) map[string]mir2.Reg {
	out := make(map[string]mir2.Reg, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

// collectArgs returns the current vregs for a slice of variable names, in order.
func (l *lowerer) collectArgs(names []string) []mir2.Reg {
	if len(names) == 0 {
		return nil
	}
	args := make([]mir2.Reg, len(names))
	for i, name := range names {
		args[i] = l.env[name]
	}
	return args
}

// ── Mutation scanner ──────────────────────────────────────────────────────────

// scanMutations returns the set of variable names that are assigned in blk.
// Only variables already in env (defined before the block) are included.
func scanMutations(blk *Block, env map[string]mir2.Reg) map[string]bool {
	muts := map[string]bool{}
	scanBlock(blk, env, muts)
	return muts
}

func scanBlock(blk *Block, env map[string]mir2.Reg, muts map[string]bool) {
	for _, s := range blk.Body {
		scanStmt(s, env, muts)
	}
}

func scanStmt(s Stmt, env map[string]mir2.Reg, muts map[string]bool) {
	switch st := s.(type) {
	case *Block:
		scanBlock(st, env, muts)
	case *AssignStmt:
		target := st.Target
		for {
			bit, ok := target.(*BitExpr)
			if !ok {
				break
			}
			target = bit.X
		}
		if vr, ok := target.(*VarRefExpr); ok {
			if _, inEnv := env[vr.Name]; inEnv {
				muts[vr.Name] = true
			}
		}
	case *IfStmt:
		scanBlock(st.Then, env, muts)
		if st.Else != nil {
			scanBlock(st.Else, env, muts)
		}
	case *WhileStmt:
		scanBlock(st.Body, env, muts)
	case *ForRangeStmt:
		scanBlock(st.Body, env, muts)
	case *ForEachStmt:
		scanBlock(st.Body, env, muts)
	case *SwitchStmt:
		for _, c := range st.Cases {
			scanBlock(c.Body, env, muts)
		}
		if st.Default != nil {
			scanBlock(st.Default, env, muts)
		}
		// BreakStmt, ContinueStmt, LabelStmt, GotoStmt: no mutations
	}
}

// mapToBool converts a map[string]T to map[string]bool (keys only).
func mapToBool[T any](m map[string]T) map[string]bool {
	out := make(map[string]bool, len(m))
	for k := range m {
		out[k] = true
	}
	return out
}

// collectLabels scans a block for LabelStmt nodes and calls emit for each.
func collectLabels(blk *Block, emit func(string)) {
	if blk == nil {
		return
	}
	for _, s := range blk.Body {
		switch st := s.(type) {
		case *LabelStmt:
			emit(st.Name)
		case *Block:
			collectLabels(st, emit)
		case *IfStmt:
			collectLabels(st.Then, emit)
			collectLabels(st.Else, emit)
		case *WhileStmt:
			collectLabels(st.Body, emit)
		case *SwitchStmt:
			for _, c := range st.Cases {
				collectLabels(c.Body, emit)
			}
			collectLabels(st.Default, emit)
		}
	}
}

// detectBackwardGotos finds labels that are targets of backward gotos.
// A backward goto is one where the GotoStmt appears AFTER its target LabelStmt
// in a linear walk of the AST (i.e., it jumps to an earlier point → loop).
func detectBackwardGotos(blk *Block) map[string]bool {
	seen := map[string]bool{}   // labels seen so far
	result := map[string]bool{} // labels that are backward-goto targets
	walkBackwardGotos(blk, seen, result)
	return result
}

func walkBackwardGotos(blk *Block, seen, result map[string]bool) {
	if blk == nil {
		return
	}
	for _, s := range blk.Body {
		switch st := s.(type) {
		case *LabelStmt:
			seen[st.Name] = true
		case *GotoStmt:
			if seen[st.Label] {
				result[st.Label] = true // backward: label before goto
			}
		case *Block:
			walkBackwardGotos(st, seen, result)
		case *IfStmt:
			walkBackwardGotos(st.Then, seen, result)
			walkBackwardGotos(st.Else, seen, result)
		case *WhileStmt:
			walkBackwardGotos(st.Body, seen, result)
		case *ForRangeStmt:
			walkBackwardGotos(st.Body, seen, result)
		case *SwitchStmt:
			for _, c := range st.Cases {
				walkBackwardGotos(c.Body, seen, result)
			}
			walkBackwardGotos(st.Default, seen, result)
		}
	}
}

// ── Key set helpers ───────────────────────────────────────────────────────────

// sortedKeys returns keys of muts that also appear in env, in sorted order.
func sortedKeys(muts map[string]bool, env map[string]mir2.Reg) []string {
	var out []string
	for name := range muts {
		if _, ok := env[name]; ok {
			out = append(out, name)
		}
	}
	sortStrings(out)
	return out
}

// unionKeys returns the sorted union of keys from a and b that also appear in env.
func unionKeys(a, b map[string]bool, env map[string]mir2.Reg) []string {
	seen := map[string]bool{}
	var out []string
	add := func(name string) {
		if _, ok := env[name]; ok && !seen[name] {
			seen[name] = true
			out = append(out, name)
		}
	}
	for name := range a {
		add(name)
	}
	for name := range b {
		add(name)
	}
	sortStrings(out)
	return out
}

// ── Used-variable scanner ─────────────────────────────────────────────────────

// scanUsedExpr adds to used the names of env-variables referenced in e.
func scanUsedExpr(e Expr, env map[string]mir2.Reg, used map[string]bool) {
	switch ex := e.(type) {
	case *VarRefExpr:
		if _, ok := env[ex.Name]; ok {
			used[ex.Name] = true
		}
	case *BinExpr:
		scanUsedExpr(ex.L, env, used)
		scanUsedExpr(ex.R, env, used)
	case *UnaryExpr:
		scanUsedExpr(ex.X, env, used)
	case *CallExpr:
		for _, a := range ex.Args {
			scanUsedExpr(a, env, used)
		}
	case *CallIndirectExpr:
		scanUsedExpr(ex.FnPtr, env, used)
		for _, a := range ex.Args {
			scanUsedExpr(a, env, used)
		}
	case *FieldExpr:
		scanUsedExpr(ex.X, env, used)
	case *BitExpr:
		scanUsedExpr(ex.X, env, used)
	case *LoadExpr:
		scanUsedExpr(ex.Ptr, env, used)
	case *DerefExpr:
		scanUsedExpr(ex.Ptr, env, used)
	case *CastExpr:
		scanUsedExpr(ex.X, env, used)
	case *IndexExpr:
		scanUsedExpr(ex.Base, env, used)
		scanUsedExpr(ex.Idx, env, used)
		// IntLitExpr, BoolLitExpr, AddrOfExpr: no variable references
	}
}

// scanUsedInBlock adds to used the names of env-variables referenced in blk.
func scanUsedInBlock(blk *Block, env map[string]mir2.Reg, used map[string]bool) {
	for _, s := range blk.Body {
		scanUsedInStmt(s, env, used)
	}
}

func scanUsedInStmt(s Stmt, env map[string]mir2.Reg, used map[string]bool) {
	switch st := s.(type) {
	case *Block:
		scanUsedInBlock(st, env, used)
	case *VarDeclStmt:
		if st.Init != nil {
			scanUsedExpr(st.Init, env, used)
		}
	case *AssignStmt:
		scanUsedExpr(st.Val, env, used)
		if d, ok := st.Target.(*DerefExpr); ok {
			scanUsedExpr(d.Ptr, env, used)
		}
	case *ReturnStmt:
		if st.Val != nil {
			scanUsedExpr(st.Val, env, used)
		}
		for _, v := range st.Vals {
			scanUsedExpr(v, env, used)
		}
	case *TupleLetStmt:
		for _, a := range st.Call.Args {
			scanUsedExpr(a, env, used)
		}
	case *ExprStmt:
		scanUsedExpr(st.Expr, env, used)
	case *StoreStmt:
		scanUsedExpr(st.Ptr, env, used)
		scanUsedExpr(st.Val, env, used)
	case *IfStmt:
		scanUsedExpr(st.Cond, env, used)
		scanUsedInBlock(st.Then, env, used)
		if st.Else != nil {
			scanUsedInBlock(st.Else, env, used)
		}
	case *WhileStmt:
		scanUsedExpr(st.Cond, env, used)
		scanUsedInBlock(st.Body, env, used)
	case *ForRangeStmt:
		if st.Start != nil {
			scanUsedExpr(st.Start, env, used)
		}
		if st.End != nil {
			scanUsedExpr(st.End, env, used)
		}
		scanUsedInBlock(st.Body, env, used)
	case *ForEachStmt:
		scanUsedExpr(st.Ptr, env, used)
		if st.Start != nil {
			scanUsedExpr(st.Start, env, used)
		}
		scanUsedExpr(st.Len, env, used)
		scanUsedInBlock(st.Body, env, used)
	case *SwitchStmt:
		scanUsedExpr(st.Val, env, used)
		for _, c := range st.Cases {
			scanUsedInBlock(c.Body, env, used)
		}
		if st.Default != nil {
			scanUsedInBlock(st.Default, env, used)
		}
		// BreakStmt, ContinueStmt, LabelStmt, GotoStmt: no expressions to scan
	}
}

// sortStrings insertion-sorts a small slice (avoids importing sort).
func sortStrings(ss []string) {
	for i := 1; i < len(ss); i++ {
		for j := i; j > 0 && ss[j] < ss[j-1]; j-- {
			ss[j], ss[j-1] = ss[j-1], ss[j]
		}
	}
}

// ── Iterator chain fusion ─────────────────────────────────────────────────────
//
// Recognizes UFCS-rewritten iterator chains of the form:
//
//	ptr.map(f).filter(g).forEach(h, n)
//
// which the parser rewrites to:
//
//	forEach(filter(map(ptr, f), g), h, n)
//
// and fuses them into a single ForEachStmt with inlined bodies — no CALL overhead
// for the lambda/function callbacks.

type iterStage struct {
	kind string // "map" or "filter"
	fn   string // resolved function name
}

type iterChain struct {
	ptr    Expr        // base pointer expression (nil for range sources)
	len    Expr        // element count (nil for range sources — count derived from range)
	stages []iterStage // transformation stages (innermost-first)
	mutate bool        // mapInPlace: store transformed element back to ptr
	cbName string      // forEach callback function name
	elemTy mir2.Ty     // element type (from callback's first param)
	// fold fields (isFold=true when chain is fold/reduce, not forEach):
	isFold    bool    // true → fold terminal (returns accumulator)
	foldInit  Expr    // initial accumulator value
	foldAccTy mir2.Ty // accumulator type (cb's return type)
	// range source fields (isRange=true when source is range(lo..hi)):
	isRange  bool // true → counter-based source, no memory/pointer
	rangeLo  Expr // inclusive start (or the "count-from" value for back-counting)
	rangeHi  Expr // exclusive end  (or 0 for back-counting)
	rangeRev bool // true when range(hi..lo): B starts at lo, counts down to 0 (DJNZ direct)
}

// tryLowerIterChain detects iterator chain patterns and lowers them to a fused
// ForEachStmt (avoiding CALL overhead for lambda callbacks).
// Returns true if the pattern was recognized and lowered.
func (l *lowerer) tryLowerIterChain(expr Expr) bool {
	chain, ok := l.recognizeIterChain(expr)
	if !ok {
		return false
	}
	if chain.isFold {
		if chain.isRange {
			l.lowerRangeFold(chain)
		} else {
			l.lowerFusedFold(chain)
		}
	} else {
		if chain.isRange {
			l.lowerRangeForEach(chain)
		} else {
			l.lowerFusedForEach(chain)
		}
	}
	return true
}

// tryLowerFold recognizes a fold/reduce call and returns the result register.
// Returns (reg, true) on success; (NoReg, false) if expr is not a fold chain.
func (l *lowerer) tryLowerFold(expr Expr) (mir2.Reg, bool) {
	chain, ok := l.recognizeIterChain(expr)
	if !ok || !chain.isFold {
		return mir2.NoReg, false
	}
	if chain.isRange {
		return l.lowerRangeFold(chain), true
	}
	return l.lowerFusedFold(chain), true
}

// recognizeIterChain matches forEach(src,cb,n) and mapInPlace(src,cb,n)
// where src may be nested map/filter stages.
func (l *lowerer) recognizeIterChain(expr Expr) (iterChain, bool) {
	call, ok := expr.(*CallExpr)
	if !ok {
		return iterChain{}, false
	}
	// ── fold/reduce ─────────────────────────────────────────────────────────────
	// Chainable:  range(lo..hi).fold(init, cb)  → Args=[range, init, cb] (3 args)
	// Functional: fold(src, init, cb, n)         → Args=[src, init, cb, n] (4 args)
	if call.Fn == "fold" || call.Fn == "reduce" {
		var (
			srcExpr  Expr
			initExpr Expr
			cbArg    Expr
			lenExpr  Expr
		)
		switch len(call.Args) {
		case 3: // chainable: fold(range_src, init, cb)
			srcExpr, initExpr, cbArg = call.Args[0], call.Args[1], call.Args[2]
		case 4: // functional: fold(ptr_src, init, cb, n)
			srcExpr, initExpr, cbArg, lenExpr = call.Args[0], call.Args[1], call.Args[2], call.Args[3]
		default:
			return iterChain{}, false
		}
		cbName := l.resolveFunc(cbArg)
		if cbName == "" {
			return iterChain{}, false
		}
		// Infer accumulator type from callback's return type (default u8).
		accTy := mir2.Ty(mir2.TyU8)
		elemTy := mir2.Ty(mir2.TyU8)
		if cbFn, ok2 := l.hirFuncs[cbName]; ok2 {
			if cbFn.RetTy != nil && cbFn.RetTy != mir2.TyVoid {
				accTy = cbFn.RetTy
			}
			if len(cbFn.Params) >= 2 {
				elemTy = cbFn.Params[1].Ty
			} else if len(cbFn.Params) == 1 {
				elemTy = cbFn.Params[0].Ty
			}
		}
		chain := iterChain{
			foldInit:  initExpr,
			cbName:    cbName,
			elemTy:    elemTy,
			isFold:    true,
			foldAccTy: accTy,
		}
		// Unwrap nested map/filter calls (from pipe .apply() expansion or manual chaining).
		innerSrc := srcExpr
		for {
			inner, ok2 := innerSrc.(*CallExpr)
			if !ok2 {
				break
			}
			if (inner.Fn == "map" || inner.Fn == "filter") && len(inner.Args) == 2 {
				fn := l.resolveFunc(inner.Args[1])
				if fn == "" {
					break
				}
				chain.stages = append(chain.stages, iterStage{kind: inner.Fn, fn: fn})
				innerSrc = inner.Args[0]
			} else {
				break
			}
		}
		// Reverse: stages collected outermost→innermost; want innermost-first.
		for i, j := 0, len(chain.stages)-1; i < j; i, j = i+1, j-1 {
			chain.stages[i], chain.stages[j] = chain.stages[j], chain.stages[i]
		}
		if rs, ok2 := innerSrc.(*RangeSourceExpr); ok2 {
			chain.isRange = true
			chain.rangeLo = rs.Lo
			chain.rangeHi = rs.Hi
			chain.rangeRev = rs.Rev
		} else {
			chain.ptr = innerSrc
			chain.len = lenExpr
		}
		return chain, true
	}

	// ── forEach / mapInPlace ─────────────────────────────────────────────────
	// Chainable range form: range(lo..hi).forEach(cb)  → Args=[range, cb] (2 args)
	// Standard form:        forEach(src, cb, n)         → Args=[src, cb, n] (3 args)
	isMutate := false
	switch call.Fn {
	case "forEach":
	case "mapInPlace":
		isMutate = true
	default:
		return iterChain{}, false
	}

	// Unwrap stages before distinguishing range and memory sources. A range
	// chain has two terminal arguments even when map/filter wrap its source.
	if len(call.Args) != 2 && len(call.Args) != 3 {
		return iterChain{}, false
	}

	cbName := l.resolveFunc(call.Args[1])
	if cbName == "" {
		return iterChain{}, false
	}

	chain := iterChain{
		cbName: cbName,
		mutate: isMutate,
		elemTy: mir2.TyU8, // default; refined from callback param below
	}
	if cbFn, ok2 := l.hirFuncs[cbName]; ok2 && len(cbFn.Params) > 0 {
		chain.elemTy = cbFn.Params[0].Ty
	}

	// Unwrap nested map/filter calls (collected outermost-first, reversed below).
	src := call.Args[0]
	for {
		inner, ok2 := src.(*CallExpr)
		if !ok2 {
			break
		}
		if (inner.Fn == "map" || inner.Fn == "filter") && len(inner.Args) == 2 {
			fn := l.resolveFunc(inner.Args[1])
			if fn == "" {
				break
			}
			chain.stages = append(chain.stages, iterStage{kind: inner.Fn, fn: fn})
			src = inner.Args[0]
		} else {
			break
		}
	}
	// Reverse: stages were collected outermost→innermost; we want innermost-first.
	for i, j := 0, len(chain.stages)-1; i < j; i, j = i+1, j-1 {
		chain.stages[i], chain.stages[j] = chain.stages[j], chain.stages[i]
	}
	if rs, ok := src.(*RangeSourceExpr); ok {
		// mapInPlace requires storage; range values have no address to mutate.
		if chain.mutate || len(call.Args) != 2 {
			return iterChain{}, false
		}
		chain.isRange = true
		chain.rangeLo, chain.rangeHi, chain.rangeRev = rs.Lo, rs.Hi, rs.Rev
	} else {
		if len(call.Args) != 3 {
			return iterChain{}, false
		}
		chain.ptr, chain.len = src, call.Args[2]
	}
	return chain, true
}

// resolveFunc resolves a callback expression to a function name.
// Accepts VarRefExpr (legacy) and AddrOfExpr (function-as-value).
func (l *lowerer) resolveFunc(arg Expr) string {
	var name string
	switch a := arg.(type) {
	case *VarRefExpr:
		name = a.Name
	case *AddrOfExpr:
		if a.X != nil {
			return ""
		}
		name = a.Sym
	default:
		return ""
	}
	if alias, ok := l.fnAliases[name]; ok {
		return alias
	}
	if l.hirFuncNames[name] {
		return name
	}
	return ""
}

// lowerFusedForEach builds the fused ForEachStmt body and lowers it.
func (l *lowerer) lowerFusedForEach(chain iterChain) {
	const elemVar = "__iter_elem__"
	elemTy := chain.elemTy
	var bodyStmts []Stmt

	// Apply each stage (map / filter).
	for _, stage := range chain.stages {
		fn := l.hirFuncs[stage.fn]
		paramName := elemVar // fallback if func not found
		if fn != nil && len(fn.Params) > 0 {
			paramName = fn.Params[0].Name
		}

		switch stage.kind {
		case "map":
			var rhs Expr
			if fn != nil && fn.Body != nil {
				if ret := extractReturnExpr(fn.Body); ret != nil {
					rhs = renameExpr(ret, paramName, elemVar)
				}
			}
			if rhs == nil {
				// Complex or unknown body — emit a call.
				rhs = &CallExpr{
					Fn:   stage.fn,
					Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}},
					Ty:   elemTy,
				}
			}
			bodyStmts = append(bodyStmts, &AssignStmt{
				Target: &VarRefExpr{Name: elemVar, Ty: elemTy},
				Val:    rhs,
			})

		case "filter":
			var cond Expr
			if fn != nil && fn.Body != nil {
				if ret := extractReturnExpr(fn.Body); ret != nil {
					cond = renameExpr(ret, paramName, elemVar)
				}
			}
			if cond == nil {
				cond = &CallExpr{
					Fn:   stage.fn,
					Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}},
					Ty:   mir2.TyBool,
				}
			}
			// if !cond { continue }
			// Prefer inverting comparison operators directly (avoids double-flag issue).
			bodyStmts = append(bodyStmts, &IfStmt{
				Cond: invertCond(cond),
				Then: &Block{Body: []Stmt{&ContinueStmt{}}},
			})
		}
	}

	// Inline the terminal callback.
	// For mapInPlace: the callback is a value-transform (like map); assign result to elemVar.
	// For forEach: the callback is a side-effect action; emit inline stmts.
	cbFn := l.hirFuncs[chain.cbName]
	if chain.mutate {
		// mapInPlace: apply callback as a transform, result stored back by lowerForEach.
		var rhs Expr
		paramName := elemVar
		if cbFn != nil && cbFn.Body != nil {
			if len(cbFn.Params) > 0 {
				paramName = cbFn.Params[0].Name
			}
			if ret := extractReturnExpr(cbFn.Body); ret != nil {
				rhs = renameExpr(ret, paramName, elemVar)
			}
		}
		if rhs == nil {
			// Complex body — emit a call and use its return value.
			rhs = &CallExpr{
				Fn:   chain.cbName,
				Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}},
				Ty:   elemTy,
			}
		}
		bodyStmts = append(bodyStmts, &AssignStmt{
			Target: &VarRefExpr{Name: elemVar, Ty: elemTy},
			Val:    rhs,
		})
	} else if cbFn == nil || cbFn.Body == nil {
		// Unknown function — emit a call.
		bodyStmts = append(bodyStmts, &ExprStmt{
			Expr: &CallExpr{
				Fn:   chain.cbName,
				Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}},
				Ty:   mir2.TyVoid,
			},
		})
	} else {
		paramName := elemVar
		if len(cbFn.Params) > 0 {
			paramName = cbFn.Params[0].Name
		}
		for _, s := range cbFn.Body.Body {
			renamed := renameStmt(s, paramName, elemVar, l.lineage)
			// ReturnStmt inside an inlined forEach callback = end of iteration body
			// (not return from the outer function). Skip it.
			if _, isRet := renamed.(*ReturnStmt); isRet {
				continue
			}
			bodyStmts = append(bodyStmts, renamed)
		}
	}

	forEach := &ForEachStmt{
		Var:           elemVar,
		ElemTy:        elemTy,
		Ptr:           chain.ptr,
		Start:         &IntLitExpr{Val: 0, Ty: mir2.TyU8},
		Len:           chain.len,
		MutateInPlace: chain.mutate,
		Body:          &Block{Body: bodyStmts},
	}
	l.lowerForEach(forEach)
}

// lowerFusedFold lowers fold(src, init, cb, n) to a DJNZ accumulator loop.
//
// The accumulator variable "__fold_acc__" is bound in the lowerer's env before
// calling lowerForEach; scanMutations detects it as mutated and threads it
// through block parameters automatically.  After the loop, l.env["__fold_acc__"]
// holds the final register with the accumulated result.
func (l *lowerer) lowerFusedFold(chain iterChain) mir2.Reg {
	const accVar = "__fold_acc__"
	const elemVar = "__iter_elem__"
	accTy := chain.foldAccTy
	elemTy := chain.elemTy

	// 1. Seed the accumulator.
	initReg := l.lowerExpr(chain.foldInit)
	// Promote initReg to accTy class if needed.
	l.bind(accVar, initReg, accTy)

	// 2. Build the loop body: __fold_acc__ = cb(__fold_acc__, __iter_elem__)
	var bodyExpr Expr
	cbFn := l.hirFuncs[chain.cbName]
	if cbFn != nil && cbFn.Body != nil && len(cbFn.Params) >= 2 {
		if ret := extractReturnExpr(cbFn.Body); ret != nil {
			accParamName := cbFn.Params[0].Name
			elemParamName := cbFn.Params[1].Name
			// Double rename: acc param → accVar, elem param → elemVar.
			bodyExpr = renameExpr(ret, accParamName, accVar)
			bodyExpr = renameExpr(bodyExpr, elemParamName, elemVar)
		}
	}
	if bodyExpr == nil {
		// Complex or unknown callback — emit a call.
		args := []Expr{&VarRefExpr{Name: accVar, Ty: accTy}, &VarRefExpr{Name: elemVar, Ty: elemTy}}
		if cbFn != nil && len(cbFn.Params) == 1 {
			args = args[:1]
		}
		bodyExpr = &CallExpr{Fn: chain.cbName, Args: args, Ty: accTy}
	}
	bodyStmts := []Stmt{
		&AssignStmt{
			Target: &VarRefExpr{Name: accVar, Ty: accTy},
			Val:    bodyExpr,
		},
	}

	bodyStmts = foldStageBody(chain.stages, elemVar, elemTy, bodyStmts)

	// 3. Run the ForEachStmt — lowerForEach threads __fold_acc__ via block params.
	forEach := &ForEachStmt{
		Var:    elemVar,
		ElemTy: elemTy,
		Ptr:    chain.ptr,
		Start:  &IntLitExpr{Val: 0, Ty: mir2.TyU8},
		Len:    chain.len,
		Body:   &Block{Body: bodyStmts},
	}
	l.lowerForEach(forEach)

	// 4. Return the final accumulator register.
	return l.env[accVar]
}

// ── Range-based (counter-only) iterator lowering ─────────────────────────────
//
// range(lo..hi).forEach(cb)   — pure DJNZ loop, no memory access
// range(lo..hi).fold(init,cb) — DJNZ accumulator loop, result in register
//
// The range source exposes a countdown, not a conventional half-open interval:
// range(0..n) and range(n..0) both yield n, n-1, ..., 1. Other forward
// bounds give count = hi-lo; the element is the counter, not lo+offset.
// See Nanz Language Book, chapter 6. lowerRangeLoop emits TermDJNZ directly.
//
// lowerRangeForEach lowers range(lo..hi).forEach(cb) to a counter-only loop.
func (l *lowerer) lowerRangeForEach(chain iterChain) {
	const elemVar = "__iter_elem__"
	elemTy := chain.elemTy
	cbFn := l.hirFuncs[chain.cbName]

	// Build the loop body by inlining the callback (same as lowerFusedForEach
	// but without a Load — the element IS the counter).
	var bodyStmts []Stmt
	if cbFn != nil && cbFn.Body != nil && len(cbFn.Params) >= 1 {
		paramName := cbFn.Params[0].Name
		for _, st := range cbFn.Body.Body {
			if _, isRet := st.(*ReturnStmt); isRet {
				continue
			}
			bodyStmts = append(bodyStmts, renameStmt(st, paramName, elemVar, l.lineage))
		}
	} else {
		bodyStmts = []Stmt{&ExprStmt{Expr: &CallExpr{
			Fn:   chain.cbName,
			Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}},
			Ty:   mir2.TyVoid,
		}}}
	}

	// Prepend stage transformations (map/filter from pipe .apply() expansion).
	bodyStmts = l.prependStageStmts(chain.stages, elemVar, elemTy, bodyStmts)

	l.lowerRangeLoop(chain, elemVar, elemTy, bodyStmts)
}

// prependStageStmts preserves stage order and filter short-circuiting without
// ContinueStmt: continue would jump over a range loop's implicit DJNZ decrement.
func (l *lowerer) prependStageStmts(stages []iterStage, elemVar string, elemTy mir2.Ty, body []Stmt) []Stmt {
	for i := len(stages) - 1; i >= 0; i-- {
		stage := stages[i]
		ty := elemTy
		if stage.kind == "filter" {
			ty = mir2.TyBool
		}
		var value Expr
		if fn := l.hirFuncs[stage.fn]; fn != nil && len(fn.Params) == 1 {
			if ret := extractReturnExpr(fn.Body); ret != nil {
				value = renameExpr(ret, fn.Params[0].Name, elemVar)
			}
		}
		if value == nil {
			value = &CallExpr{Fn: stage.fn, Args: []Expr{&VarRefExpr{Name: elemVar, Ty: elemTy}}, Ty: ty}
		}
		switch stage.kind {
		case "map":
			assign := &AssignStmt{Target: &VarRefExpr{Name: elemVar, Ty: elemTy}, Val: value}
			body = append([]Stmt{assign}, body...)
		case "filter":
			body = []Stmt{&IfStmt{Cond: value, Then: &Block{Body: body}}}
		}
	}
	return body
}

// lowerRangeFold lowers range(lo..hi).fold(init, cb) to a DJNZ accumulator loop.
func (l *lowerer) lowerRangeFold(chain iterChain) mir2.Reg {
	const accVar = "__fold_acc__"
	const elemVar = "__iter_elem__"
	accTy := chain.foldAccTy
	elemTy := chain.elemTy

	// Seed the accumulator.
	initReg := l.lowerExpr(chain.foldInit)
	l.bind(accVar, initReg, accTy)

	// Build the loop body: __fold_acc__ = cb(__fold_acc__, __iter_elem__)
	var bodyExpr Expr
	cbFn := l.hirFuncs[chain.cbName]
	if cbFn != nil && cbFn.Body != nil && len(cbFn.Params) >= 2 {
		if ret := extractReturnExpr(cbFn.Body); ret != nil {
			bodyExpr = renameExpr(ret, cbFn.Params[0].Name, accVar)
			bodyExpr = renameExpr(bodyExpr, cbFn.Params[1].Name, elemVar)
		}
	} else if cbFn != nil && cbFn.Body != nil && len(cbFn.Params) == 1 {
		// Single-param cb: acc-only fold (element unused).
		if ret := extractReturnExpr(cbFn.Body); ret != nil {
			bodyExpr = renameExpr(ret, cbFn.Params[0].Name, accVar)
		}
	}
	if bodyExpr == nil {
		args := []Expr{&VarRefExpr{Name: accVar, Ty: accTy}, &VarRefExpr{Name: elemVar, Ty: elemTy}}
		if cbFn != nil && len(cbFn.Params) == 1 {
			args = args[:1]
		}
		bodyExpr = &CallExpr{Fn: chain.cbName, Args: args, Ty: accTy}
	}
	// Keep stage order and filter short-circuiting. Calls preserve callback
	// prefixes; predicates guard the remaining pipeline without continue,
	// which would bypass the range loop's implicit DJNZ decrement.
	foldAssign := &AssignStmt{Target: &VarRefExpr{Name: accVar, Ty: accTy}, Val: bodyExpr}
	bodyStmts := foldStageBody(chain.stages, elemVar, elemTy, []Stmt{foldAssign})

	l.lowerRangeLoop(chain, elemVar, elemTy, bodyStmts)
	return l.env[accVar]
}

// foldStageBody preserves map/filter order and skips the remaining stages and
// terminal fold when a filter fails. Build from the end to nest the suffix.
func foldStageBody(stages []iterStage, elemVar string, elemTy mir2.Ty, body []Stmt) []Stmt {
	for i := len(stages) - 1; i >= 0; i-- {
		stage := stages[i]
		value := &VarRefExpr{Name: elemVar, Ty: elemTy}
		switch stage.kind {
		case "map":
			assign := &AssignStmt{Target: value, Val: &CallExpr{Fn: stage.fn, Args: []Expr{value}, Ty: elemTy}}
			body = append([]Stmt{assign}, body...)
		case "filter":
			pred := &CallExpr{Fn: stage.fn, Args: []Expr{value}, Ty: mir2.TyBool}
			body = []Stmt{&IfStmt{Cond: pred, Then: &Block{Body: body}}}
		}
	}
	return body
}

// lowerRangeLoop emits a counter-only DJNZ loop for range(lo..hi) sources.
//
// Uses TermDJNZ directly — no CmpNe/AND A inside the loop at all.
//
//	entry:
//	    cnt = countExpr              B = n (ClassCounter)
//	    cond = (cnt != 0)            AND A while cnt may share A — pre-check only
//	    BrIf(cond, rng_body, rng_exit)
//
//	rng_body(cnt: B, mutated...):
//	    elem = cnt                   element = current B value
//	    [body stmts]                 may update mutated vars
//	    DJNZ rng_body(cnt-1, mutated...) | rng_exit(mutated...)
//	    ──> emitted as TermDJNZ; no CmpNe, no register clobber
//
//	rng_exit(mutated...):
//
// The pre-check uses A freely (before any acc block param is live).
// DJNZ handles all subsequent iterations without touching A.
func (l *lowerer) lowerRangeLoop(chain iterChain, elemVar string, elemTy mir2.Ty, bodyStmts []Stmt) {
	envBefore := cloneMap(l.env)

	// Compute loop count (initial B value).
	var countExpr Expr
	if chain.rangeRev {
		countExpr = chain.rangeLo // range(n..0): n iterations
	} else {
		lo := chain.rangeLo
		hi := chain.rangeHi
		if lit, ok := lo.(*IntLitExpr); ok && lit.Val == 0 {
			countExpr = hi
		} else {
			countExpr = &BinExpr{Op: "-", L: hi, R: lo, Ty: hi.ExprTy()}
		}
	}
	cntReg := l.lowerExpr(countExpr) // typically ClassAcc (A from func param)

	// Scan body for mutated outer vars (block params for loop-carried state).
	elemInitReg := l.bld.Const(0, elemTy, mir2.ClassGeneral)
	l.bind(elemVar, elemInitReg, elemTy)
	syntheticBody := &Block{Body: bodyStmts}
	allUsed := map[string]bool{}
	scanUsedInBlock(syntheticBody, envBefore, allUsed)
	muts := scanMutations(syntheticBody, envBefore)
	for name := range muts {
		allUsed[name] = true
	}
	delete(allUsed, elemVar)
	mutated := sortedKeys(allUsed, envBefore)

	bodyLabel := l.fresh("rng_body")
	exitLabel := l.fresh("rng_exit")

	// Pre-check: skip loop if cnt == 0.
	// cntReg is typically in A (ClassAcc from func param position 0).
	// AND A sets Z if A==0 without extra cost; the trampoline sorts out
	// the A→B (counter) and 0→A (acc) parallel copies before the loop body.
	zero8 := l.bld.Const(0, mir2.TyU8, mir2.ClassAcc)
	cond0 := l.bld.Cmp(mir2.CmpNe, cntReg, zero8, mir2.ClassFlag, false)
	entryBodyArgs := append([]mir2.Reg{cntReg}, l.collectArgs(mutated)...)
	exitArgs0 := l.collectArgs(mutated)
	l.bld.BrIf(cond0, bodyLabel, entryBodyArgs, exitLabel, exitArgs0)

	// ── rng_body(cnt: B, mutated...) ──
	body := l.bld.SwitchToNewBlock(bodyLabel)
	bodyCnt := l.bld.BlockParam(body, mir2.TyU8, mir2.ClassCounter) // B
	bodyEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		// For fold loops, put the accumulator in ClassAcc (A) — the result
		// is returned, so keeping it in A avoids a LD A,C copy at exit.
		cls := classForLoop(ty, name)
		if chain.isFold {
			cls = classForRet(ty)
		}
		r := l.bld.BlockParam(body, ty, cls)
		bodyEnv[name] = r
	}
	l.env = bodyEnv

	// Element = current B value.
	l.bind(elemVar, bodyCnt, elemTy)

	// A fold owns its accumulator in A. A forEach body may have several
	// independently live values (including stage results and captures); use
	// ordinary loop expression classes rather than forcing all ALU results to A.
	prevInLoop := l.inLoopContext
	l.inLoopContext = !chain.isFold
	l.pushLoop(loopCtx{headLabel: bodyLabel, exitLabel: exitLabel, mutated: mutated})
	l.lowerBlock(syntheticBody)
	l.popLoop()
	l.inLoopContext = prevInLoop

	// TermDJNZ: B--; if B!=0 goto body(mutated...) else exit(mutated...).
	// Counter (bodyCnt) is implicit — NOT passed in bodyBackArgs or exitArgs1.
	bodyBackArgs := l.collectArgs(mutated)
	exitArgs1 := l.collectArgs(mutated)
	l.bld.DJNZ(bodyCnt, bodyLabel, bodyBackArgs, exitLabel, exitArgs1)

	// ── rng_exit(mutated...) ──
	exit := l.bld.SwitchToNewBlock(exitLabel)
	exitEnv := cloneMap(envBefore)
	for _, name := range mutated {
		ty := l.envTy[name]
		cls := classForExpr(ty)
		if chain.isFold {
			cls = classForRet(ty) // keep acc in A for clean return
		}
		r := l.bld.BlockParam(exit, ty, cls)
		exitEnv[name] = r
	}
	delete(exitEnv, elemVar)
	l.env = exitEnv
}

// extractReturnExpr extracts a single-return expression only when it is the
// entire body. Dropping a prefix can erase effects, local bindings or control flow.
func extractReturnExpr(body *Block) Expr {
	if body == nil || len(body.Body) != 1 {
		return nil
	}
	if rs, ok := body.Body[0].(*ReturnStmt); ok && rs.Val != nil {
		return rs.Val
	}
	return nil
}

// renameExpr deep-copies an expression, renaming VarRefExpr{Name:from} → {Name:to}.
func renameExpr(e Expr, from, to string) Expr {
	if e == nil {
		return nil
	}
	switch ex := e.(type) {
	case *IntLitExpr:
		return &IntLitExpr{Val: ex.Val, Ty: ex.Ty}
	case *BoolLitExpr:
		return &BoolLitExpr{Val: ex.Val}
	case *VarRefExpr:
		if ex.Name == from {
			return &VarRefExpr{Name: to, Ty: ex.Ty}
		}
		return &VarRefExpr{Name: ex.Name, Ty: ex.Ty}
	case *BinExpr:
		return &BinExpr{Op: ex.Op, L: renameExpr(ex.L, from, to), R: renameExpr(ex.R, from, to), Ty: ex.Ty}
	case *UnaryExpr:
		return &UnaryExpr{Op: ex.Op, X: renameExpr(ex.X, from, to), Ty: ex.Ty}
	case *CastExpr:
		return &CastExpr{X: renameExpr(ex.X, from, to), Ty: ex.Ty}
	case *CallExpr:
		args := make([]Expr, len(ex.Args))
		for i, a := range ex.Args {
			args[i] = renameExpr(a, from, to)
		}
		return &CallExpr{Fn: ex.Fn, Args: args, Ty: ex.Ty}
	case *CallIndirectExpr:
		args := make([]Expr, len(ex.Args))
		for i, a := range ex.Args {
			args[i] = renameExpr(a, from, to)
		}
		return &CallIndirectExpr{FnPtr: renameExpr(ex.FnPtr, from, to), Args: args, Ty: ex.Ty, Signature: ex.Signature}
	case *LoadExpr:
		return &LoadExpr{Ptr: renameExpr(ex.Ptr, from, to), Ty: ex.Ty}
	case *IndexExpr:
		return &IndexExpr{
			Base: renameExpr(ex.Base, from, to), Idx: renameExpr(ex.Idx, from, to),
			ElemTy: ex.ElemTy, ElemStride: ex.ElemStride,
		}
	case *FieldExpr:
		return &FieldExpr{X: renameExpr(ex.X, from, to), Field: ex.Field, Offset: ex.Offset, Ty: ex.Ty}
	case *BitExpr:
		return &BitExpr{X: renameExpr(ex.X, from, to), Bit: ex.Bit}
	case *AddrOfExpr:
		if ex.X != nil {
			return &AddrOfExpr{Sym: ex.Sym, X: renameExpr(ex.X, from, to)}
		}
		return &AddrOfExpr{Sym: ex.Sym}
	case *ConstPtrExpr:
		return &ConstPtrExpr{ElemTy: ex.ElemTy, Addr: ex.Addr}
	case *LetInExpr:
		return &LetInExpr{
			Name: ex.Name, Ty: ex.Ty,
			Init: renameExpr(ex.Init, from, to),
			Body: renameExpr(ex.Body, from, to),
		}
	default:
		return e
	}
}

// renameStmt deep-copies a statement, renaming variables as in renameExpr.
func renameStmt(s Stmt, from, to string, lineage ...map[Stmt]LoopLineage) (renamed Stmt) {
	// Each inlined copy retains its original site attribution. The lowerer owns
	// this map; adding clone nodes must not mutate the input module metadata.
	defer func() {
		if len(lineage) > 0 && lineage[0] != nil && renamed != nil {
			if origin, ok := lineage[0][s]; ok {
				lineage[0][renamed] = origin
			}
		}
	}()
	if s == nil {
		return nil
	}
	switch st := s.(type) {
	case *ExprStmt:
		return &ExprStmt{Expr: renameExpr(st.Expr, from, to)}
	case *ReturnStmt:
		newVals := make([]Expr, len(st.Vals))
		for i, v := range st.Vals {
			newVals[i] = renameExpr(v, from, to)
		}
		return &ReturnStmt{Val: renameExpr(st.Val, from, to), Vals: newVals}
	case *AssignStmt:
		return &AssignStmt{Target: renameExpr(st.Target, from, to), Val: renameExpr(st.Val, from, to)}
	case *VarDeclStmt:
		return &VarDeclStmt{Name: st.Name, Ty: st.Ty, Init: renameExpr(st.Init, from, to)}
	case *IfStmt:
		var els *Block
		if st.Else != nil {
			els = renameBlock(st.Else, from, to, lineage...)
		}
		return &IfStmt{Cond: renameExpr(st.Cond, from, to), Then: renameBlock(st.Then, from, to, lineage...), Else: els}
	case *Block:
		return renameBlock(st, from, to, lineage...)
	case *BreakStmt:
		return &BreakStmt{}
	case *ContinueStmt:
		return &ContinueStmt{}
	case *LabelStmt:
		return &LabelStmt{Name: st.Name}
	case *GotoStmt:
		return &GotoStmt{Label: st.Label}
	case *StoreStmt:
		return &StoreStmt{Ptr: renameExpr(st.Ptr, from, to), Val: renameExpr(st.Val, from, to)}
	case *WhileStmt:
		return &WhileStmt{Cond: renameExpr(st.Cond, from, to), Body: renameBlock(st.Body, from, to, lineage...)}
	case *ForRangeStmt:
		c := *st
		c.Start = renameExpr(st.Start, from, to)
		c.End = renameExpr(st.End, from, to)
		c.Body = renameBlock(st.Body, from, to, lineage...)
		return &c
	case *ForEachStmt:
		c := *st
		c.Ptr = renameExpr(st.Ptr, from, to)
		c.Start = renameExpr(st.Start, from, to)
		c.Len = renameExpr(st.Len, from, to)
		c.Body = renameBlock(st.Body, from, to, lineage...)
		return &c
	case *SwitchStmt:
		c := *st
		c.Val = renameExpr(st.Val, from, to)
		c.Cases = make([]*SwitchCase, len(st.Cases))
		for i := range c.Cases {
			cc := *st.Cases[i]
			cc.Body = renameBlock(st.Cases[i].Body, from, to, lineage...)
			c.Cases[i] = &cc
		}
		c.Default = renameBlock(st.Default, from, to, lineage...)
		return &c
	default:
		return s
	}
}

// renameBlock deep-copies a block, renaming variables.
func renameBlock(b *Block, from, to string, lineage ...map[Stmt]LoopLineage) *Block {
	if b == nil {
		return nil
	}
	stmts := make([]Stmt, len(b.Body))
	for i, s := range b.Body {
		stmts[i] = renameStmt(s, from, to, lineage...)
	}
	return &Block{Body: stmts}
}

// invertCond returns the logical negation of a condition expression.
// For comparison BinExprs it flips the operator (e.g. > → <=), which lets
// lowerCond produce a direct Cmp without an extra flag-compare for "!".
func invertCond(e Expr) Expr {
	if bin, ok := e.(*BinExpr); ok {
		var inv string
		switch bin.Op {
		case "==":
			inv = "!="
		case "!=":
			inv = "=="
		case "<":
			inv = ">="
		case "<=":
			inv = ">"
		case ">":
			inv = "<="
		case ">=":
			inv = "<"
		}
		if inv != "" {
			return &BinExpr{Op: inv, L: bin.L, R: bin.R, Ty: bin.Ty}
		}
	}
	return &UnaryExpr{Op: "!", X: e, Ty: mir2.TyBool}
}

// emitStructLitFields stores each field of lit into the target struct.
// baseProvider is called once per field to get a fresh base address register;
// this ensures each OpAddrOf result has useCount==1, enabling the HL-chain
// optimization in z80codegen (LD HL,sym ; LD (HL),n ; INC HL ; ...).
// Fields may appear in any source order; unmentioned fields are left uninitialized.
func (l *lowerer) emitStructLitFields(lit *StructLitExpr, baseProvider func() mir2.Reg) {
	for _, fi := range lit.Fields {
		// Find the matching struct field to get its type and byte offset.
		var fieldTy mir2.Ty
		byteOff := 0
		for idx, sf := range lit.St.Fields {
			if sf.Name == fi.Name {
				fieldTy = sf.Ty
				byteOff = lit.St.ByteOffset(idx)
				break
			}
		}
		if fieldTy == nil {
			panic(fmt.Sprintf("hir/lower: struct %q has no field %q", lit.St.Name, fi.Name))
		}
		val := l.lowerExpr(fi.Val)
		base := baseProvider()
		var addr mir2.Reg
		if byteOff == 0 {
			addr = base
		} else {
			addr = l.bld.Field(base, int64(byteOff), mir2.ClassPointer)
		}
		l.bld.Store(addr, val, fieldTy)
	}
}

// emitStructLitFieldsChained stores fields in ascending offset order using
// sequential address chaining: each addr = Field(prevAddr, offsetDiff).
// This keeps only one pointer reg live at a time — all can share HL,
// enabling the INC HL / LD (HL),n pattern for @smc and other pointer writes.
//
// Each field value is lowered just before its Store, not upfront.  Lowering
// all values in advance would put two ClassAcc (A) vregs live simultaneously,
// causing the allocator to spill to alloca instead of keeping everything in
// registers.
func (l *lowerer) emitStructLitFieldsChained(lit *StructLitExpr, startAddr mir2.Reg) {
	// Build sorted (offset, ty, valExpr) list — store HIR Expr, not lowered Reg.
	type fieldEntry struct {
		byteOff int
		ty      mir2.Ty
		valExpr Expr
	}
	entries := make([]fieldEntry, 0, len(lit.Fields))
	for _, fi := range lit.Fields {
		var fieldTy mir2.Ty
		byteOff := 0
		for idx, sf := range lit.St.Fields {
			if sf.Name == fi.Name {
				fieldTy = sf.Ty
				byteOff = lit.St.ByteOffset(idx)
				break
			}
		}
		if fieldTy == nil {
			panic(fmt.Sprintf("hir/lower: struct %q has no field %q", lit.St.Name, fi.Name))
		}
		entries = append(entries, fieldEntry{byteOff, fieldTy, fi.Val})
	}
	// Sort ascending by byte offset (insertion sort — small N).
	for i := 1; i < len(entries); i++ {
		for j := i; j > 0 && entries[j].byteOff < entries[j-1].byteOff; j-- {
			entries[j], entries[j-1] = entries[j-1], entries[j]
		}
	}
	// Emit stores with sequential chaining: prevAddr → Field(prevAddr, diff) → Store.
	// Lower each val expression immediately before its Store so it is dead by the
	// time the next val is lowered — no A-register live range overlap.
	prevAddr := startAddr
	prevOff := 0
	for i, e := range entries {
		var addr mir2.Reg
		if i == 0 && e.byteOff == 0 {
			addr = startAddr
		} else if i == 0 {
			addr = l.bld.Field(startAddr, int64(e.byteOff), mir2.ClassPointer)
		} else {
			diff := e.byteOff - prevOff
			addr = l.bld.Field(prevAddr, int64(diff), mir2.ClassPointer)
		}
		val := l.lowerExpr(e.valExpr) // lower just before Store — short live range
		l.bld.Store(addr, val, e.ty)
		prevAddr = addr
		prevOff = e.byteOff
	}
}

// lowerStructLitAlloca lowers a StructLitExpr as a standalone expression:
// allocates a temporary stack frame, writes fields into it, and returns the
// pointer.  Used when the literal appears in non-assignment contexts (function
// arguments, return values, etc.).
func (l *lowerer) lowerStructLitAlloca(lit *StructLitExpr) mir2.Reg {
	bytes := int64(lit.St.Width() / 8)
	if bytes == 0 {
		bytes = 1
	}
	base := l.bld.Alloca(bytes)
	l.emitStructLitFields(lit, func() mir2.Reg { return base })
	return base
}

// ── Inline asm helpers ───────────────────────────────────────────────────────

// z80RegNameToClass maps a physical Z80 register name to its primary RegClass,
// matching the @z80_X annotation scheme used on function parameters.
func z80RegNameToClass(reg string) mir2.RegClass {
	switch strings.ToUpper(reg) {
	case "A":
		return mir2.ClassAcc
	case "B":
		return mir2.ClassCounter
	case "C":
		return mir2.ClassRegC
	case "D":
		return mir2.ClassRegD
	case "E":
		return mir2.ClassRegE
	case "H":
		return mir2.ClassRegH
	case "L":
		return mir2.ClassRegL
	case "HL":
		return mir2.ClassPointer
	case "DE":
		return mir2.ClassIndex
	case "BC":
		return mir2.ClassPair
	case "IX":
		return mir2.ClassIX
	case "IY":
		return mir2.ClassIY
	case "IXH", "IXL", "IYH", "IYL":
		return mir2.ClassIXY8
	default:
		return mir2.ClassGeneral
	}
}

// z80RegToClassSet maps a physical Z80 register name to the classes it occupies.
func z80RegToClassSet(reg string) mir2.ClassSet {
	var cs mir2.ClassSet
	switch strings.ToUpper(reg) {
	case "A":
		cs.Add(mir2.ClassAcc)
		cs.Add(mir2.ClassGeneral)
	case "B":
		cs.Add(mir2.ClassCounter)
		cs.Add(mir2.ClassGeneral)
	case "C", "D", "E", "H", "L":
		cs.Add(mir2.ClassGeneral)
	case "HL":
		cs.Add(mir2.ClassPointer)
		cs.Add(mir2.ClassPair)
	case "DE":
		cs.Add(mir2.ClassIndex)
		cs.Add(mir2.ClassPair)
	case "BC":
		cs.Add(mir2.ClassPair)
	case "IX":
		cs.Add(mir2.ClassIX)
	case "IY":
		cs.Add(mir2.ClassIY)
	case "F":
		cs.Add(mir2.ClassFlag)
	case "SP":
		// stack pointer — not allocatable, but flags as clobbered
	}
	return cs
}

// z80RetRegInfo returns the MIR2 type and class for an asm (ret REG) clause.
func z80RetRegInfo(reg string) (mir2.Ty, mir2.RegClass) {
	switch strings.ToUpper(reg) {
	case "A":
		return mir2.TyU8, mir2.ClassAcc
	case "B":
		return mir2.TyU8, mir2.ClassCounter
	case "C", "D", "E", "H", "L":
		return mir2.TyU8, mir2.ClassGeneral
	case "HL":
		return mir2.TyU16, mir2.ClassPointer
	case "DE":
		return mir2.TyU16, mir2.ClassIndex
	case "BC":
		return mir2.TyU16, mir2.ClassPair
	default:
		return mir2.TyU8, mir2.ClassAcc
	}
}

// z80AutoClobbers parses Z80 assembly text and returns the set of register
// classes that are written by the instructions.  Conservative: unknown
// instructions or CALL/RST clobber everything.  F (flags) is always included.
func z80AutoClobbers(code string) mir2.ClassSet {
	var cs mir2.ClassSet
	cs.Add(mir2.ClassFlag) // almost every Z80 instruction touches F

	for _, rawLine := range strings.Split(code, "\n") {
		line := strings.TrimSpace(rawLine)
		// Handle "/" as inline separator
		for _, part := range strings.Split(line, "/") {
			part = strings.TrimSpace(part)
			if part == "" || strings.HasSuffix(part, ":") {
				continue // empty or label
			}
			// Extract mnemonic (first word)
			fields := strings.Fields(part)
			if len(fields) == 0 {
				continue
			}
			mnem := strings.ToUpper(fields[0])

			// CALL/RST/DJNZ — conservative: clobber all
			switch mnem {
			case "CALL", "RST":
				return mir2.AllClasses
			}

			// Parse destination (first operand) for instructions that write.
			operands := ""
			if len(fields) > 1 {
				operands = strings.Join(fields[1:], " ")
			}
			parts := strings.SplitN(operands, ",", 2)
			dst := strings.TrimSpace(parts[0])
			dst = strings.Trim(dst, "()")

			switch mnem {
			case "LD", "ADD", "ADC", "SUB", "SBC", "AND", "OR", "XOR", "CP",
				"INC", "DEC", "NEG", "CPL", "DAA", "RLA", "RRA", "RLCA", "RRCA",
				"RL", "RR", "RLC", "RRC", "SLA", "SRA", "SRL", "BIT", "SET", "RES",
				"POP", "IN":
				cs = cs.Union(z80RegToClassSet(strings.ToUpper(dst)))
			case "EX":
				// EX DE,HL clobbers both
				cs = cs.Union(z80RegToClassSet("DE"))
				cs = cs.Union(z80RegToClassSet("HL"))
			case "EXX":
				cs.Add(mir2.ClassShadow)
			case "PUSH", "NOP", "HALT", "DI", "EI", "RET", "JP", "JR",
				"JRS", "OUT":
				// These don't write to a general register
			case "LDIR", "LDDR":
				cs = cs.Union(z80RegToClassSet("HL"))
				cs = cs.Union(z80RegToClassSet("DE"))
				cs = cs.Union(z80RegToClassSet("BC"))
			case "CPIR", "CPDR":
				cs = cs.Union(z80RegToClassSet("HL"))
				cs = cs.Union(z80RegToClassSet("BC"))
			default:
				// Unknown instruction → conservative
				return mir2.AllClasses
			}
		}
	}
	return cs
}
