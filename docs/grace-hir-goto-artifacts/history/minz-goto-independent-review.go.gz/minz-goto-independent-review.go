package main
import("fmt";"github.com/minz/minzc/pkg/c89";"github.com/minz/minzc/pkg/hir";"github.com/minz/minzc/pkg/mir2")
func main(){cases:=map[string]struct{src string;want int64}{
"skipped_init_used_else":{"unsigned short f(void){goto a;int x=99;a:if(0)x=7;return x;}",0},
"killed_before_jumpchain":{"unsigned short f(void){goto a;int x=99;a:x=7;goto b;b:return x;}",7},
"enter_loop_break":{"unsigned short f(void){goto a;for(int i=0;i<3;i++){a:break;}return 7;}",7},
"cross_sibling_return":{"unsigned short f(void){int x=7;{int y=99;goto a;}{int y=88;a:return x;}}",7},
"enter_aftershadow_kill_outer":{"unsigned short f(void){int x=7;goto a;{int x=99;a:x=8;}return x;}",7},
"jumpbeforedeclaration_reenter":{"unsigned short f(void){int n=0;a:n=n+1;{int x=99;if(n<2)goto a;}return n;}",2},
"branchgotoandlabel":{"unsigned short f(int c){int x=7;if(c)goto a;else goto b;a:x=9;goto out;b:x=11;out:return x;}",11},

"jump_chain":{"unsigned short f(void){int x=7;goto a;a:goto b;b:return x;}",7},
"dead_both":{"unsigned short f(void){int x=7;goto b;if(0){a:x=9;goto out;}else{b:x=11;goto out;}out:return x;}",11},
"skip_then_assign":{"unsigned short f(void){goto a;int x=99;a:x=7;return x;}",7},
"skip_decl_branch_assign":{"unsigned short f(void){goto a;int x=99;a:if(1)x=7;else x=8;return x;}",7},
"after_decl_shadow_chain":{"unsigned short f(void){int x=7;goto a;{int x=99;a:goto b;b:x=3;return x;}}",3},
"sibling_nondemand":{"unsigned short f(void){int x=7;{goto a;}{int x=99;a:return 3;}}",3},
"param_out_mutation":{"unsigned short f(int x){again:{x=x+1;int x=99;goto end;}end:return x;}",8},
"loop_entry_return":{"unsigned short f(void){goto a;for(int i=0;i<3;i++){a:return 7;}return 0;}",7},
"dead_switch":{"unsigned short f(void){int x=7;goto a;switch(x){case 7:a:x=9;break;default:x=3;}return x;}",9},
"forward_loop_label":{"unsigned short f(void){int x=7;goto a;while(0){a:x=9;break;}return x;}",9},
"backward_nested_types":{"unsigned short f(void){int x=7;int n=0;a:{n=n+1;char x=99;if(n<2)goto a;}return x;}",7},
}
for name,c:=range cases {func(){defer func(){if r:=recover();r!=nil{fmt.Println(name,"PANIC",r)}}();m,e:=c89.Compile(c.src,name+".c");if e!=nil {fmt.Println(name,"REFUSE",e);return};e=hir.Verify(m);if e!=nil{fmt.Println(name,"HIRREFUSE",e);return};mm:=hir.LowerModule(m);if e=mir2.Verify(mm);e!=nil{fmt.Println(name,"MIRREFUSE",e);return};args:=[]mir2.Value{};if name=="param_out_mutation"{args=[]mir2.Value{{I:7}}};if name=="branchgotoandlabel"{args=[]mir2.Value{{I:0}}};r,e:=mir2.NewVM(mm).Call("f",args);fmt.Println(name,"got",r,"want",c.want,"error",e)}()}
}
