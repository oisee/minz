package hir

import (
	"fmt"
	"reflect"
	"strings"

	"github.com/minz/minzc/pkg/mir2"
)

// Verify checks the structural and resolved-type contract consumed by lowering.
// Numeric width conversions and legacy integer addresses are intentionally legal.
// It does not prove equivalence, closure capture safety, or all-paths return.
func Verify(m *Module) error { return verifyHIRModule(m, false) }

// ResolveCallSignatures verifies HIR and records signatures for statically
// resolved indirect calls. Unknown raw pointers remain explicitly unresolved.
func ResolveCallSignatures(m *Module) error { return verifyHIRModule(m, true) }

func verifyHIRModule(m *Module, annotate bool) error {
	if m == nil {
		return fmt.Errorf("HIR: nil module")
	}
	v := &hirVerifier{funcs: map[string]*Func{}, globals: map[string]bool{}, active: map[any]bool{}, aliases: map[string]*Func{}, annotateCalls: annotate}
	for _, g := range m.Globals {
		if g.Name == "" || v.globals[g.Name] || nilHIR(g.Ty) {
			return fmt.Errorf("HIR: invalid or duplicate global %q", g.Name)
		}
		v.globals[g.Name] = true
	}
	for _, f := range m.Funcs {
		if f == nil {
			return fmt.Errorf("HIR: nil function")
		}
		if f.Name == "" || v.funcs[f.Name] != nil {
			return fmt.Errorf("HIR: invalid or duplicate function %q", f.Name)
		}
		v.funcs[f.Name] = f
	}
	for _, f := range m.Funcs {
		v.fn = f
		v.labels = map[string]bool{}
		v.gotos = nil
		env := map[string]mir2.Ty{}
		if nilHIR(f.RetTy) {
			return v.fail("missing return type")
		}
		for _, ty := range f.RetTys {
			if nilHIR(ty) {
				return v.fail("missing tuple return type")
			}
		}
		for _, p := range f.Params {
			if p.Name == "" || env[p.Name] != nil || nilHIR(p.Ty) || p.Ty == mir2.TyVoid {
				return v.fail("invalid or duplicate parameter %q", p.Name)
			}
			env[p.Name] = p.Ty
		}
		for _, c := range f.Captures {
			if c.Name == "" || env[c.Name] != nil || nilHIR(c.Ty) || c.Ty == mir2.TyVoid || v.globals[c.Name] || v.funcs[c.Name] != nil {
				return v.fail("invalid or duplicate capture %q", c.Name)
			}
			env[c.Name] = c.Ty
		}
		v.aliases = map[string]*Func{}
		if f.IsExtern {
			continue
		}
		if err := v.block(f.Body, env, 0); err != nil {
			return err
		}
		if err := verifyGotoBindings(f); err != nil {
			return v.fail("%s", err)
		}
		for _, name := range v.gotos {
			if !v.labels[name] {
				return v.fail("unknown label %q", name)
			}
		}
	}
	return nil
}

type hirVerifier struct {
	funcs         map[string]*Func
	globals       map[string]bool
	fn            *Func
	labels        map[string]bool
	gotos         []string
	active        map[any]bool
	aliases       map[string]*Func
	captureOuter  map[string]mir2.Ty
	collected     map[string]mir2.Ty
	annotateCalls bool
}

func nilHIR(x any) bool {
	return x == nil || reflect.ValueOf(x).Kind() == reflect.Ptr && reflect.ValueOf(x).IsNil()
}
func (v *hirVerifier) fail(format string, args ...any) error {
	return fmt.Errorf("HIR %s: %s", v.fn.Name, fmt.Sprintf(format, args...))
}
func copyHIRScope(env map[string]mir2.Ty) map[string]mir2.Ty {
	out := map[string]mir2.Ty{}
	for n, t := range env {
		out[n] = t
	}
	return out
}
func (v *hirVerifier) enter(x any) error {
	if nilHIR(x) {
		return v.fail("missing %T", x)
	}
	if v.active[x] {
		return v.fail("cyclic %T", x)
	}
	v.active[x] = true
	return nil
}
func (v *hirVerifier) block(b *Block, outer map[string]mir2.Ty, loops int) error {
	if err := v.enter(b); err != nil {
		return err
	}
	defer delete(v.active, b)
	env := copyHIRScope(outer)
	oldAliases := v.aliases
	v.aliases = map[string]*Func{}
	for n, f := range oldAliases {
		v.aliases[n] = f
	}
	defer func() { v.aliases = oldAliases }()
	for i, s := range b.Body {
		if err := v.stmt(s, env, loops); err != nil {
			return fmt.Errorf("statement %d: %w", i, err)
		}
	}
	return nil
}
func (v *hirVerifier) exprs(env map[string]mir2.Ty, xs ...Expr) error {
	for _, x := range xs {
		if err := v.expr(x, env); err != nil {
			return err
		}
	}
	return nil
}
func (v *hirVerifier) bind(env map[string]mir2.Ty, n string, ty mir2.Ty) error {
	if n == "" || nilHIR(ty) || ty == mir2.TyVoid {
		return v.fail("invalid binding %q", n)
	}
	env[n] = ty
	return nil
}

func rawHIRPointer(ty mir2.Ty) bool { return mir2.IsPointer(ty) && ty == mir2.PtrFor(ty.Width()) }

// assignableHIR reflects current implicit numeric conversions. Raw pointers and
// integer addresses remain an explicit legacy compatibility boundary.
func assignableHIR(dst, src mir2.Ty) bool {
	if nilHIR(dst) || nilHIR(src) {
		return false
	}
	if dst == src {
		return true
	}
	dst, src = mir2.BaseOf(dst), mir2.BaseOf(src)
	if mir2.IsInt(dst) && mir2.IsInt(src) {
		return true
	}
	if mir2.IsPointer(dst) && mir2.IsPointer(src) {
		return rawHIRPointer(dst) || rawHIRPointer(src) || dst.String() == src.String()
	}
	if mir2.IsPointer(dst) && mir2.IsInt(src) || mir2.IsInt(dst) && mir2.IsPointer(src) {
		return true
	}
	if mir2.IsPointer(dst) {
		switch src.(type) {
		case *mir2.StructTy, *mir2.ArrayTy:
			return true
		}
	}
	// Struct expressions are lowered as addresses; HIR does not yet distinguish
	// address-valued struct locals from aggregate values.
	if _, ok := dst.(*mir2.StructTy); ok {
		return mir2.IsPointer(src)
	}
	return dst.String() == src.String()
}
func (v *hirVerifier) valueAs(e Expr, ty mir2.Ty, env map[string]mir2.Ty) error {
	if err := v.expr(e, env); err != nil {
		return err
	}
	if !assignableHIR(ty, e.ExprTy()) {
		return v.fail("value type %s incompatible with %s", e.ExprTy(), ty)
	}
	return nil
}
func (v *hirVerifier) address(e Expr, env map[string]mir2.Ty) error {
	if err := v.expr(e, env); err != nil {
		return err
	}
	if vr, ok := e.(*VarRefExpr); ok {
		if _, array := env[vr.Name].(*mir2.ArrayTy); array {
			return nil
		}
	}
	ty := mir2.BaseOf(e.ExprTy())
	if mir2.IsPointer(ty) || mir2.IsInt(ty) && ty.Width() >= 16 {
		return nil
	}
	if _, ok := ty.(*mir2.ArrayTy); ok {
		return nil
	}
	if _, ok := ty.(*mir2.StructTy); ok {
		return nil
	}
	return v.fail("non-address type %s", ty)
}
func (v *hirVerifier) condition(e Expr, env map[string]mir2.Ty) error {
	if err := v.expr(e, env); err != nil {
		return err
	}
	ty := mir2.BaseOf(e.ExprTy())
	if !mir2.IsInt(ty) && !mir2.IsPointer(ty) {
		return v.fail("non-scalar condition %s", ty)
	}
	return nil
}
func (v *hirVerifier) pointee(e Expr, ty mir2.Ty, env map[string]mir2.Ty) error {
	if err := v.address(e, env); err != nil {
		return err
	}
	ptr := e.ExprTy()
	if mir2.IsPointer(ptr) && !rawHIRPointer(ptr) {
		elem := mir2.PointerElem(ptr)
		if elem != nil && elem.String() != ty.String() {
			return v.fail("pointee %s does not match access type %s", elem, ty)
		}
	}
	return nil
}
func (v *hirVerifier) stmt(s Stmt, env map[string]mir2.Ty, loops int) error {
	if nilHIR(s) {
		return v.fail("nil statement")
	}
	// Blocks have their own cycle guard.
	if b, ok := s.(*Block); ok {
		return v.block(b, env, loops)
	}
	if err := v.enter(s); err != nil {
		return err
	}
	defer delete(v.active, s)
	switch s := s.(type) {
	case *VarDeclStmt:
		if s.ArrayLen < 0 {
			return v.fail("negative array length")
		}
		if s.Init != nil {
			if err := v.expr(s.Init, env); err != nil {
				return err
			}
		}
		for _, init := range s.Initial {
			if init != nil {
				if err := v.expr(init, env); err != nil {
					return err
				}
			}
		}
		f := v.functionValue(s.Init)
		_, aliasInit := s.Init.(*VarRefExpr)
		if f != nil && aliasInit {
			v.aliases[s.Name] = f
		} else {
			delete(v.aliases, s.Name)
		}
		ty := s.Ty
		if s.ArrayLen > 0 {
			if nilHIR(ty) {
				return v.fail("missing array element type")
			}
			ty = &mir2.ArrayTy{Elem: ty, Len: s.ArrayLen}
		}
		return v.bind(env, s.Name, ty)
	case *AssignStmt:
		if bit, ok := s.Target.(*BitExpr); ok {
			switch bit.X.(type) {
			case *VarRefExpr, *FieldExpr, *IndexExpr, *LoadExpr, *DerefExpr:
			default:
				return v.fail("bit assignment requires an addressable scalar base")
			}
		}
		if vr, ok := s.Target.(*VarRefExpr); ok && v.aliases[vr.Name] != nil {
			return v.fail("reassignment of callable alias %q is unsupported", vr.Name)
		}
		switch s.Target.(type) {
		case *VarRefExpr, *DerefExpr, *FieldExpr, *IndexExpr, *BitExpr:
		default:
			return v.fail("invalid assignment target %T", s.Target)
		}
		// Nanz permits implicit local declaration by assignment. Read the RHS
		// before introducing the binding, so x = x + 1 cannot create itself.
		if vr, ok := s.Target.(*VarRefExpr); ok && env[vr.Name] == nil && v.captureOuter[vr.Name] != nil {
			env[vr.Name] = v.captureOuter[vr.Name]
			v.collected[vr.Name] = env[vr.Name]
		}
		if vr, ok := s.Target.(*VarRefExpr); ok && env[vr.Name] == nil && !v.globals[vr.Name] {
			if err := v.valueAs(s.Val, vr.Ty, env); err != nil {
				return err
			}
			return v.bind(env, vr.Name, vr.Ty)
		}
		if err := v.expr(s.Target, env); err != nil {
			return err
		}
		return v.valueAs(s.Val, s.Target.ExprTy(), env)
	case *ReturnStmt:
		if s.Val != nil && len(s.Vals) > 0 {
			return v.fail("ambiguous return value")
		}
		if len(s.Vals) > 0 {
			if len(s.Vals) != len(v.fn.RetTys) {
				return v.fail("return arity %d, want %d", len(s.Vals), len(v.fn.RetTys))
			}
			return v.exprs(env, s.Vals...)
		}
		if s.Val != nil {
			if f := v.functionValue(s.Val); f != nil && len(f.Captures) > 0 && v.captureOuter == nil {
				return v.fail("capturing callable %s cannot escape through return", f.Name)
			}
			if v.captureOuter != nil {
				return v.expr(s.Val, env)
			}
			return v.valueAs(s.Val, v.fn.RetTy, env)
		}
	case *TupleLetStmt:
		if len(s.Names) != len(s.Tys) {
			return v.fail("tuple names/types length mismatch")
		}
		if err := v.expr(s.Call, env); err != nil {
			return err
		}
		if f := v.funcs[s.Call.Fn]; f != nil && len(f.RetTys) != len(s.Names) {
			return v.fail("tuple call result arity mismatch")
		}
		for i, n := range s.Names {
			if n != "_" {
				if err := v.bind(env, n, s.Tys[i]); err != nil {
					return err
				}
			}
		}
	case *ExprStmt:
		return v.expr(s.Expr, env)
	case *StoreStmt:
		if err := v.expr(s.Val, env); err != nil {
			return err
		}
		return v.pointee(s.Ptr, s.Val.ExprTy(), env)
	case *IfStmt:
		if err := v.condition(s.Cond, env); err != nil {
			return err
		}
		if err := v.block(s.Then, env, loops); err != nil {
			return err
		}
		if s.Else != nil {
			return v.block(s.Else, env, loops)
		}
	case *WhileStmt:
		if err := v.condition(s.Cond, env); err != nil {
			return err
		}
		return v.block(s.Body, env, loops+1)
	case *ForRangeStmt:
		if err := v.exprs(env, s.Start, s.End); err != nil {
			return err
		}
		scope := copyHIRScope(env)
		if err := v.bind(scope, s.Var, s.Start.ExprTy()); err != nil {
			return err
		}
		return v.block(s.Body, scope, loops+1)
	case *ForEachStmt:
		if s.ElemStride < 0 {
			return v.fail("negative element stride")
		}
		if err := v.exprs(env, s.Ptr, s.Start, s.Len); err != nil {
			return err
		}
		scope := copyHIRScope(env)
		ty := s.ElemTy
		if nilHIR(ty) {
			return v.fail("missing element type")
		}
		if s.PtrIter {
			ty = mir2.TyPtr
		}
		if err := v.bind(scope, s.Var, ty); err != nil {
			return err
		}
		return v.block(s.Body, scope, loops+1)
	case *BreakStmt, *ContinueStmt:
		if loops == 0 {
			return v.fail("%T outside loop", s)
		}
	case *LabelStmt:
		if s.Name == "" || v.labels[s.Name] {
			return v.fail("invalid or duplicate label %q", s.Name)
		}
		v.labels[s.Name] = true
	case *GotoStmt:
		v.gotos = append(v.gotos, s.Label)
	case *SwitchStmt:
		if err := v.expr(s.Val, env); err != nil {
			return err
		}
		cases := map[int64]bool{}
		for _, c := range s.Cases {
			if c == nil || cases[c.Val] {
				return v.fail("nil or duplicate switch case")
			}
			cases[c.Val] = true
			if err := v.block(c.Body, env, loops); err != nil {
				return err
			}
		}
		if s.Default != nil {
			return v.block(s.Default, env, loops)
		}
	case *AsmStmt:
		for _, op := range append(append([]AsmOperand(nil), s.Ins...), s.Outs...) {
			if env[op.Name] == nil && z80RegToClassSet(strings.ToUpper(op.Name)) == 0 {
				return v.fail("unknown asm operand %q", op.Name)
			}
		}
	default:
		return v.fail("unsupported statement %T", s)
	}
	return nil
}
func (v *hirVerifier) expr(e Expr, env map[string]mir2.Ty) error {
	if err := v.enter(e); err != nil {
		return err
	}
	defer delete(v.active, e)
	// LetIn.ExprTy delegates to Body, so validate children before asking its type.
	if x, ok := e.(*LetInExpr); ok {
		if err := v.expr(x.Init, env); err != nil {
			return err
		}
		scope := copyHIRScope(env)
		if err := v.bind(scope, x.Name, x.Ty); err != nil {
			return err
		}
		return v.expr(x.Body, scope)
	}
	if nilHIR(e.ExprTy()) {
		return v.fail("missing type on %T", e)
	}
	switch e := e.(type) {
	case *IntLitExpr:
		if e.Ty == mir2.TyVoid {
			return v.fail("void integer literal")
		}
	case *BoolLitExpr:
	case *VarRefExpr:
		if ty := env[e.Name]; ty != nil && mir2.IsPointer(ty) && !rawHIRPointer(ty) && e.Ty.String() != ty.String() {
			return v.fail("variable %s type %s, declared %s", e.Name, e.Ty, ty)
		}
		if env[e.Name] == nil && !v.globals[e.Name] && v.funcs[e.Name] == nil {
			if ty := v.captureOuter[e.Name]; ty != nil {
				v.collected[e.Name] = ty
			} else {
				return v.fail("unknown variable %q", e.Name)
			}
		}
		if f := v.funcs[e.Name]; f != nil {
			return v.checkCaptureUse(f, env)
		}
	case *BinExpr:
		if !strings.Contains(" + - * / % & | ^ << >> == != < <= > >= && || ", " "+e.Op+" ") {
			return v.fail("unknown binary operator %q", e.Op)
		}
		if err := v.exprs(env, e.L, e.R); err != nil {
			return err
		}
		if e.L.ExprTy() == mir2.TyVoid || e.R.ExprTy() == mir2.TyVoid || e.Ty == mir2.TyVoid {
			return v.fail("void binary operand or result")
		}
	case *UnaryExpr:
		if e.Op != "-" && e.Op != "!" && e.Op != "~" && e.Op != "+" {
			return v.fail("unknown unary operator %q", e.Op)
		}
		return v.expr(e.X, env)
	case *CallExpr:
		if e.Fn == "" {
			return v.fail("empty call target")
		}
		if f := v.funcs[e.Fn]; f != nil {
			if len(e.Args) != len(f.Params) {
				return v.fail("call %s arity %d, want %d", e.Fn, len(e.Args), len(f.Params))
			}
			if !assignableHIR(e.Ty, f.RetTy) {
				return v.fail("call %s return type %s, declared %s", e.Fn, e.Ty, f.RetTy)
			}
		}
		if err := v.exprs(env, e.Args...); err != nil {
			return err
		}
		f := v.funcs[e.Fn]
		if f == nil {
			f = v.aliases[e.Fn]
		}
		if f != nil {
			if len(f.Captures) > 0 && v.captureOuter == nil {
				return v.fail("capturing callable %s requires an inlined iterator context", f.Name)
			}
			if err := v.checkCaptureUse(f, env); err != nil {
				return err
			}
			return v.checkSignature(f.Signature(), e.Args, e.Ty, env)
		}
		return nil
	case *CallIndirectExpr:
		if err := v.expr(e.FnPtr, env); err != nil {
			return err
		}
		if err := v.exprs(env, e.Args...); err != nil {
			return err
		}
		sig := e.Signature
		if f := v.functionValue(e.FnPtr); f != nil {
			if len(f.Captures) > 0 && v.captureOuter == nil {
				return v.fail("capturing callable %s requires an inlined iterator context", f.Name)
			}
			resolved := f.Signature()
			if sig != nil && !sameHIRSignature(sig, resolved) {
				return v.fail("indirect call signature disagrees with target %s", f.Name)
			}
			if v.annotateCalls {
				e.Signature = resolved
			}
			sig = resolved
			if err := v.checkCaptureUse(f, env); err != nil {
				return err
			}
		}
		if sig != nil {
			return v.checkSignature(sig, e.Args, e.Ty, env)
		}
		return nil
	case *FieldExpr:
		if e.Offset < 0 {
			return v.fail("negative field offset")
		}
		return v.expr(e.X, env)
	case *BitExpr:
		if err := v.expr(e.X, env); err != nil {
			return err
		}
		if e.Bit < 0 || e.Bit >= e.X.ExprTy().Width() {
			return v.fail("bit index out of range")
		}
	case *AddrOfExpr:
		if !mir2.IsPointer(e.ExprTy()) {
			return v.fail("address-of has non-pointer type")
		}
		if e.X != nil {
			return v.expr(e.X, env)
		}
		if e.Sym == "" {
			return v.fail("empty address symbol")
		}
		if f := v.funcs[e.Sym]; f != nil {
			return v.checkCaptureUse(f, env)
		}
	case *LoadExpr:
		return v.pointee(e.Ptr, e.Ty, env)
	case *DerefExpr:
		return v.pointee(e.Ptr, e.Ty, env)
	case *CastExpr:
		return v.expr(e.X, env)
	case *ConstPtrExpr:
		if nilHIR(e.ElemTy) {
			return v.fail("missing constant pointer element type")
		}
	case *IndexExpr:
		if e.ElemStride < 0 {
			return v.fail("negative index stride")
		}
		if err := v.pointee(e.Base, e.ElemTy, env); err != nil {
			return err
		}
		if err := v.expr(e.Idx, env); err != nil {
			return err
		}
		if !mir2.IsInt(mir2.BaseOf(e.Idx.ExprTy())) {
			return v.fail("non-integer index")
		}
	case *StructLitExpr:
		if e.St == nil {
			return v.fail("missing struct type")
		}
		for _, f := range e.Fields {
			if err := v.expr(f.Val, env); err != nil {
				return err
			}
		}
	case *RangeSourceExpr:
		return v.exprs(env, e.Lo, e.Hi)
	case *CondExpr:
		if err := v.condition(e.Cond, env); err != nil {
			return err
		}
		if err := v.valueAs(e.Then, e.Ty, env); err != nil {
			return err
		}
		return v.valueAs(e.Else, e.Ty, env)
	default:
		return v.fail("unsupported expression %T", e)
	}
	return nil
}

// verifyGraceModule validates HIR before invoking the panic-based lowerer.
func verifyGraceModule(m *Module) error {
	if err := Verify(m); err != nil {
		return err
	}
	return mir2.Verify(LowerModule(m))
}
