package main
import("fmt";"github.com/minz/minzc/pkg/c89";"github.com/minz/minzc/pkg/hir";"github.com/minz/minzc/pkg/mir2")
func main(){cases:=[]struct{name,src string;want int64;reject bool}{
 {"outer_assign_before_shadow","unsigned short f(int c){goto a;int x=99;a:if(c){x=2;int x=3;}else{x=4;}return x;}",2,false},
 {"same_scope_shadow_target","unsigned short f(int c){int x=7;{int x=3;goto b;b:return x;}}",3,false},
 {"nested_label_original","unsigned short f(int c){int x=7;goto a;if(c){a:if(c){x=2;goto b;}else{x=4;goto b;}}b:return x;}",2,false},
 {"nested_skipped_outer","unsigned short f(int c){goto a;int x=99;a:if(c){if(c){int x=2;x=3;goto b;}else{x=4;goto b;}}else{x=5;goto b;}b:return x;}",0,true},
 {"same_scope_target_killed_init","unsigned short f(int c){int x=7;goto a;{int x=99;a:x=3;goto b;b:return x;}}",3,false},
 {"shadow_launders_edge","unsigned short f(int c){goto a;int x=99;a:if(c){int x=1;x=2;goto b;}else{x=3;goto b;}b:return x;}",0,true},
 {"nested_shadow_launders_edge","unsigned short f(int c){goto a;int x=99;a:if(c){{int x=1;x=2;goto b;}}else{x=3;goto b;}b:return x;}",0,true},
 {"dead_assignment_launders_edge","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;x=1;}else{x=3;goto b;}b:return x;}",0,true},
 {"goto_before_local_decl","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;int x=1;x=2;}else{x=3;goto b;}b:return x;}",0,true},
 {"unreachable_assign_after_goto","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;x=1;}else{x=2;}b:return x;}",0,true},
 {"unreachable_assign_after_return","unsigned short f(int c){goto a;int x=99;a:if(c){return 7;x=1;}else{x=2;}b:return x;}",7,false},
 {"local_shadow_kill","unsigned short f(int c){goto a;int x=99;a:{int x=1;x=2;}b:return x;}",0,true},
 {"branches_shadow_kill","unsigned short f(int c){goto a;int x=99;a:if(c){int x=1;x=2;}else{int x=3;x=4;}b:return x;}",0,true},
 {"unreachable_shadow_after_goto","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;int x=1;}else{x=2;}b:return x;}",0,true},
 {"conditional_transitive_jump","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;}else{x=2;goto b;}b:return x;}",0,true},
 {"both_branches_real_assign","unsigned short f(int c){goto a;int x=99;a:if(c){x=1;}else{x=2;}b:return x;}",1,false},
 {"return_or_real_assign","unsigned short f(int c){goto a;int x=99;a:if(c){return 7;}else{x=2;}b:return x;}",7,false},
 {"goto_else_real_assign","unsigned short f(int c){goto a;int x=99;a:if(c){goto b;}else{x=2;}b:x=3;return x;}",3,false},
 {"one_branch_nested_local","unsigned short f(int c){goto a;int x=99;a:if(c){{int x=3;x=4;}}else{x=2;}b:return x;}",0,true},
}
for _,tc:=range cases {for _,c:=range []int64{0,1} {func(){defer func(){if r:=recover();r!=nil {fmt.Println(tc.name,c,"PANIC",r)}}();m,e:=c89.Compile(tc.src,tc.name+".c");if e!=nil{fmt.Println(tc.name,c,"FRONTREFUSE",e);return};if e=hir.Verify(m);e!=nil {fmt.Println(tc.name,c,"HIRREFUSE",e);return};mm:=hir.LowerModule(m);if e=mir2.Verify(mm);e!=nil {fmt.Println(tc.name,c,"MIRREFUSE",e);return};r,e:=mir2.NewVM(mm).Call("f",[]mir2.Value{{I:c}});fmt.Println(tc.name,c,"ACCEPT got",r,"want/reject",tc.want,tc.reject,"error",e)}()}}
}
