package main
import("encoding/json";"fmt";"os";"github.com/minz/minzc/pkg/c89";"github.com/minz/minzc/pkg/hir")
func main(){s,e:=os.ReadFile("../examples/c89/func_ptr.c");if e!=nil{panic(e)};m,e:=c89.Compile(string(s),"func_ptr.c");if e!=nil{panic(e)};fmt.Println("HIRVerify:",hir.Verify(m));f:=m.FuncByName("test_reassign_fp");b,_:=json.MarshalIndent(f,"","  ");fmt.Println(string(b));fmt.Println(m.Dump())}
