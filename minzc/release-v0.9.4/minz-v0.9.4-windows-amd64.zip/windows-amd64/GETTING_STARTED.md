# MinZ v0.9.4 - Metaprogramming Revolution

## Quick Start

### Compile a MinZ program:
```bash
./bin/mz examples/metaprogramming_showcase.minz -o program.a80
```

### Try @minz metafunctions:
```minz
@minz("fun hello_{0}() -> void { @print(\"Hi {0}\!\"); }", "world")
```

### Use iterator chains:
```minz
numbers.map(double).filter(gt_5).forEach(print_u8)
```

### Features:
- ✅ Compile-time metaprogramming with @minz
- ✅ Zero-cost iterator chains with DJNZ optimization  
- ✅ Self-modifying code for maximum performance
- ✅ Modern abstractions, vintage performance

Happy coding on Z80\! 🚀
