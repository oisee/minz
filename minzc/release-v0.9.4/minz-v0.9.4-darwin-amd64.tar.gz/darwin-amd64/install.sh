#\!/bin/bash
echo "Installing MinZ v0.9.4 \"Metaprogramming Revolution\"..."
sudo cp bin/mz /usr/local/bin/
sudo chmod +x /usr/local/bin/mz
echo "MinZ installed successfully\!"
echo "Try: mz examples/metaprogramming_showcase.minz -o demo.a80"
echo "✨ @minz metafunctions and zero-cost iterators ready\!"
