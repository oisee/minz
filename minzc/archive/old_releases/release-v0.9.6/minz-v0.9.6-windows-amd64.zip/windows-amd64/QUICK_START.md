# MinZ v0.9.6 Quick Start - Swift & Ruby Dreams\! 🎉

## New Features

### Function Overloading
```minz
print(42);      // No more print_u8\!
print(1000);    // No more print_u16\!
print(true);    // Just print\!
```

### Interface Methods
```minz
circle.draw();  // Natural syntax\!
rect.get_area();  // Zero-cost dispatch\!
```

## Try It Out

```bash
# Function overloading example
./bin/mz examples/test_overloading.minz -o test.a80

# Interface methods example  
./bin/mz examples/interface_simple.minz -o interface.a80
```

Happy coding with modern abstractions on Z80\! 🚀
