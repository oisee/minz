# MinZ v0.12.0 - CTIE Revolution\! 🎊

## Try Compile-Time Execution

```bash
# Simple CTIE example
cat > test.minz << 'END'
fun add(a: u8, b: u8) -> u8 { return a + b; }
fun main() -> void {
    let result = add(10, 20);  // Computed at compile-time\!
    print_u8(result);
}
END

# Compile with CTIE
./bin/mz test.minz --enable-ctie -o test.a80

# See the magic\! (no CALL instruction\!)
grep "LD A, 30" test.a80
```

## Features
✅ Functions execute at compile-time
✅ Calls replaced with constants  
✅ 3-5x performance improvement
✅ Zero runtime overhead\!

Happy coding with negative-cost abstractions\! 🚀
