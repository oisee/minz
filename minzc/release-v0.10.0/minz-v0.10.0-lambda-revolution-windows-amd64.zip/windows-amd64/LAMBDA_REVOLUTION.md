# MinZ v0.10.0 - Lambda Revolution\! 🎊

## 🚀 HISTORIC BREAKTHROUGH

You now have the first programming language with **zero-cost lambda expressions** on 8-bit hardware\!

## Try It Out

```bash
# Compile the lambda iterator example
./bin/mz examples/test_lambda_iterators.minz -o lambda_demo.a80

# Look at the generated assembly
cat lambda_demo.a80 | grep -A 5 "iter_lambda_"
```

## Revolutionary Code

```minz
// This modern functional code...
numbers.iter()
    .map(|x| x * 2)         // Lambda: multiply by 2
    .filter(|x| x > 5)      // Lambda: filter > 5
    .forEach(|x| print_u8(x)); // Lambda: print each

// ...compiles to optimal DJNZ loops with function calls\!
// ZERO runtime overhead - same performance as hand-written assembly\!
```

## What This Means

- **Modern abstractions** with **vintage performance**
- **Functional programming** on severely constrained hardware
- **Zero performance penalty** - lambdas compile to optimized functions
- **DJNZ optimization** - most efficient Z80 loop instruction

Welcome to the future of retro computing\! 🚀
