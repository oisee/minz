# MinZ v0.13.1 - Installation Guide

## Quick Start

### 1. Install Dependencies (First Time Only)
```bash
./install-dependencies.sh
```

This will install tree-sitter CLI which is required for parsing MinZ source files.

### 2. Install MinZ
```bash
./install.sh
```

### 3. Test Installation
```bash
mz examples/fibonacci.minz -o test.a80
```

## Troubleshooting

If you get "Expected source code but got an atom" error:
- Run `./install-dependencies.sh` to install tree-sitter
- Make sure Node.js and npm are installed
- Try `sudo npm install -g tree-sitter-cli` if the script fails

## Need Help?

Report issues at: https://github.com/oisee/minz/issues

Happy coding with MinZ! 🚀
