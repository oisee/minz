# MinZ v0.9.3 - Iterator Revolution

Zero-cost functional programming for Z80 processors\!

## Installation

Run `./install.sh` (Unix) or copy binaries to your PATH.

## Usage

- `mz program.minz` - Compile MinZ programs
- `mzr` - Interactive REPL

## Examples

See the `examples/` directory for sample programs.
