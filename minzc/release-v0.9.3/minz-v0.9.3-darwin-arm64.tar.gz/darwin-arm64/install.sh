#\!/bin/bash
echo "Installing MinZ v0.9.3..."
sudo cp bin/mz bin/mzr /usr/local/bin/
sudo chmod +x /usr/local/bin/mz /usr/local/bin/mzr
echo "MinZ installed successfully\!"
echo "Run 'mz --help' for compiler"
echo "Run 'mzr' for REPL"
