# MinZ v0.15.0 Quick Start - Pattern Matching Revolution!

## 🎊 What's New

### Pattern Matching (94% Feature Complete!)
```minz
case value {
    0 => "zero",
    1..10 => "small",       // Range patterns!
    State.IDLE => "idle",   // Enum patterns!
    _ => "other"            // Wildcard!
}
```

## Try It Now

```bash
# Simple pattern matching
./bin/mz examples/pattern_matching_demo.minz -o demo.a80

# Classic example
./bin/mz examples/fibonacci.minz -o fib.a80

# Your own code
./bin/mz your_program.minz -o program.a80
```

## Features Working Today

✅ Pattern matching with ranges and enums
✅ Lambda expressions with zero-cost
✅ Function overloading
✅ Structs and enums
✅ Metaprogramming with @minz blocks
✅ Self-modifying code optimization

## Only 2 Known Issues
- Local/nested functions (use regular functions)
- @define macros (use @minz blocks instead)

Happy coding on Z80! 🚀
